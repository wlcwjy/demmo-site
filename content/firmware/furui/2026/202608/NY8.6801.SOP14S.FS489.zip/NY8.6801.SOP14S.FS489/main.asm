﻿; =========================================================================      
; Project:       
; File:          main.asm
; Description:   
;                 
; Author:        
; Version:       
; Date:         
; =========================================================================
;--------------- File Include ---------------------------------------------
;--------------------------------------------------------------------------
#include		NY8A054E.H						; The Header File for NY8A053E
;--------------- Variable Definition --------------------------------------
;--------------------------------------------------------------------------
;		R_Temp		EQU		0x10			; Example
V_BUTTON_IN_DELAY			EQU		0x40
V_SYSTEM_STATUS				EQU		0x41  
V_BUTTON_DELAY				EQU		0x42
V_DELAY_COUNT1				EQU		0x43    
V_DELAY_COUNT2				EQU		0x44   
V_BREATE_AL1				EQU		0x45    
V_BREATE_BL1				EQU		0x46  
V_BREATE_COUNT				EQU		0x47  
V_BREATE_DELAY				EQU		0x48  
V_BREATE_UP_TIME			EQU		0x49  
V_BREATE_DOWN_TIME			EQU		0x4A  
V_BREATE_AL2				EQU		0x4B    
V_BREATE_BL2				EQU		0x4C 
V_BREATE_PERIOD 			EQU		0x4D
V_LED_MODE_NUMBER			EQU		0x4E
V_RUN_LOOP					EQU		0x4F

V_DELAY_T0_COUNT			EQU		0x20  
V_DELAY_T0_NMS				EQU		0x21 
V_DELAY_T0_TEMP				EQU		0x22
V_DELAY_T0_5MS				EQU		0x23 
V_DELAY_T0_25MS				EQU		0x24 
V_DELAY_T0_45MS				EQU		0x25 
V_DELAY_T0_55MS				EQU		0x26 
V_DELAY_T0_50MS				EQU		0x27 

V_I							EQU		0x30 
V_ADDR						EQU		0x31 
V_PERIOD					EQU		0x32
V_LED_MODE_RUN_LOOP			EQU		0x33

V_PORTA0					EQU		0x34
V_PORTA1					EQU		0x35
V_PORTA2					EQU		0x36
V_PORTA3					EQU		0x37
V_PORTB0					EQU		0x38
V_PORTB1					EQU		0x39
V_PORTB2					EQU		0x3A
V_PORTB3					EQU		0x3B

V_RUN_SUB_LOOP				EQU		0x3C
V_HALF_PERIOD				EQU		0x3D
V_BREATE_AL3				EQU		0x3E    
V_BREATE_BL3				EQU		0x3F

;--------------- Constant Definition --------------------------------------
;--------------------------------------------------------------------------
;		C_Temp		EQU		0xFF			; Example

C_OSH_PIN 					EQU 	2
C_BUTTON_PIN				EQU 	3

C_LEDA_ACTRL				EQU 	10011111B

C_LEDB_ACTRL				EQU 	01101111B

C_LEDC_ACTRL				EQU 	11111101B
C_LEDC_BCTRL				EQU 	11111110B

C_LEDD_ACTRL				EQU 	11111110B
C_LEDD_BCTRL				EQU 	11111101B

C_LEDE_BCTRL				EQU 	11011011B

C_ALED_ALL_ON				EQU 	00001100B
C_BLED_ALL_ON				EQU 	00000000B
C_ALED_ALL_OFF				EQU 	11111111B
C_BLED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_IS_BUTTON_CHECK	EQU		1  
C_STATUS_LED_MODE			EQU		2  

C_BUTTON_SHORT_DELAY		EQU		10
C_BREATE_PERIOD				EQU		54

;--------------- Vector Definition ----------------------------------------
;--------------------------------------------------------------------------
		ORG		0x000		
		LGOTO	V_Main                
		
		ORG		0x008
		LGOTO	V_INT
		
;--------------- Code Start -----------------------------------------------
;--------------------------------------------------------------------------
        ORG		0x010         
V_Main:
; Initial GPIO  
    
		; PORTB I/O state
		; PB3 ~ PB2 set input mode and enable pull-low resistor
		; PB1 ~ PB0 set open-drain output mode                  
		MOVIA   0
		IOST    BODCON								; Enable Open-Drain of PB1 & PB0 ,others disable 
		
        MOVIA   11111111B
        MOVAR   ABPLCON								; Enable PB3 Pull-Low Resistor,others disable
			
        MOVIA   11111111B 
	    MOVAR   BPHCON								; Enable PB2 Pull-High Resistor,others disable
								 
		MOVIA   00000000B
		IOST    IOSTB								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTB								; PB1 & PB0 output high
		
		MOVIA   11110011B 
	    IOST    APHCON								; Enable PB2 Pull-High Resistor,others disable
		
		MOVIA   00001100B
		IOST    IOSTA								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTA	
		
		MOVIA	10100011B
        T0MD 
        MOVIA	0
        MOVAR	TMR0
		
		LCALL	F_TIMER_CALIBRATION
		
		CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
F_MAIN_LOOP:                                    
        CLRWDT										; Clear WatchDog
		LCALL 	F_SYSTEM_SLEEP

		MOVIA	0
        BCR     STATUS,C_Status_Z_bit    	; Clear Zero bit of Status Register
		XORAR   V_LED_MODE_NUMBER,C_SaveToAcc                      
		BTRSC	STATUS,C_Status_Z_bit    	; If ACC(C_KEY1_VALUE)==V_KEY1 , then Zero bit=1
		LGOTO	F_MAIN_LOOP_CALL_LED_MODE0
		
        LCALL 	F_LED_MODE1
		CLRR 	V_LED_MODE_NUMBER
		LGOTO   F_MAIN_LOOP
F_MAIN_LOOP_CALL_LED_MODE0:
		LCALL 	F_LED_MODE0
		INCR	V_LED_MODE_NUMBER,C_SaveToReg
		LGOTO   F_MAIN_LOOP

;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- F_DELAY_MS_HCLK ----------------------------------
F_DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
DELAY_MS_HCLK_LOOP2:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		LGOTO	DELAY_MS_HCLK_LOOP2
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		LGOTO	F_DELAY_MS_HCLK
		RET       	
;---------------------------- T0_DELAY ----------------------------------
T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
T0_DELAY_LOOP:
		CLRWDT
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	T0_DELAY_LOOP
		RET
;---------------------------- F_LED_SWITCH_ON--------------------------------
;--------------------------------------------------------------------------  		
F_LED_SWITCH_ON:
        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVIA   C_ALED_ALL_OFF                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVIA   C_ALED_ALL_OFF                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVIA   C_ALED_ALL_OFF                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		
		RET 
;---------------------------- F_LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
F_LED_SWITCH_OFF:
		MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVIA   C_ALED_ALL_OFF                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		
		RET
;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
F_TIMER_CALIBRATION:
        ; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        SFUN    OSCCR                        		; OSCCR: Oscillation Control Register  
        NOP
        NOP
        
		MOVIA	10100011B
		T0MD 
        MOVIA	0
        MOVAR	TMR0
		
;   		BCR   	PORTB,5	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	F_DELAY_MS_HCLK
;        BSR   	PORTB,5

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_5MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_5MS,C_SaveToReg

		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_25MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_25MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_45MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_45MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_50MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_50MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_55MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_55MS,C_SaveToReg

        RET		
;---------------------------- F_BUTTON_CHECK--------------------------------
;--------------------------------------------------------------------------        
F_BUTTON_CHECK:
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		BTRSC	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
        
		MOVIA   0
		MOVAR	V_BUTTON_IN_DELAY
SUB_WAIT_BUTTON_CHECK:
		BTRSC	PORTA,C_BUTTON_PIN					 
		RET					;Button release,goto button check end
		CLRWDT	
		
		MOVIA	C_BUTTON_SHORT_DELAY
        BCR     STATUS,C_Status_C_bit    			; Clear Zero bit of Status Register
		CMPAR   V_BUTTON_IN_DELAY                    
		BTRSC	STATUS,C_Status_C_bit    			; If V_BUTTON_IN_DELAY>C_BUTTON_SHORT_DELAY , then C bit=1
		LGOTO	SUB_BUTTON_CHECK_EFFECT
		INCR    V_BUTTON_IN_DELAY,C_SaveToReg
		LGOTO	SUB_WAIT_BUTTON_CHECK
SUB_BUTTON_CHECK_EFFECT:		
		MOVIA   11111111B
		MOVAR   PORTA								; PA output high
        MOVAR   PORTB								; PB output high
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	SUB_WAIT_BUTTON_CHECK
		RET 
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
F_SYSTEM_SLEEP:
		MOVIA   11111111B
		MOVAR   PORTB								;PORTB output high
		MOVAR   PORTA								;PORTB output high
		LCALL 	F_BUTTON_CHECK
		BTRSS	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	NO_BUTTON0
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	BUTTON_SET_POWER_OFF0
BUTTON_SET_POWER_ON0:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON
		LGOTO 	F_SYSTEM_SLEEP
BUTTON_SET_POWER_OFF0:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
NO_BUTTON0:
		BTRSS	PORTB,C_OSH_PIN						;Wait OSH PIN to be 1
		LGOTO 	F_SYSTEM_SLEEP		
	
ENTRY_SLEEP:
		LCALL	F_TIMER_CALIBRATION
		
		MOVIA   11111111B
		MOVAR	PORTB								; Clear all interrupt flags
		MOVIA   11111111B
		MOVAR	PORTA	
		
		MOVIA   00000000B
		MOVAR	INTF	
		MOVAR	AWUCON
		MOVIA   01000000B
		MOVAR	PCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON		;if is power on enable PB0 wakeup
		BSR		AWUCON,C_OSH_PIN
		BSR		AWUCON,C_BUTTON_PIN 				
			
		MOVIA   00000010B							;Enable PB INT
		MOVAR	INTE
	   	ENI											;Enable INT 	
		MOVR	PORTB,C_SaveToAcc
	 	SLEEP
	 	NOP
        NOP
        MOVIA   11001000B
		MOVAR	PCON
		
		;MOVIA	10100011B
		;T0MD 
       
		DISI;
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
        
		LCALL 	F_BUTTON_CHECK						;If button in is yes,goto sleep,
		BTRSS	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	NO_BUTTON
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	BUTTON_SET_POWER_OFF1
BUTTON_SET_POWER_ON1:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON
		LGOTO 	F_SYSTEM_SLEEP
BUTTON_SET_POWER_OFF1:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
		
NO_BUTTON:		
		BTRSS 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	F_SYSTEM_SLEEP
		
WAIT_OSH:
		CLRWDT
		BTRSS 	PORTB,C_OSH_PIN		;if is power on enable PB0 wakeup
		LGOTO 	WAIT_OSH	
	
		RET
;;============================================================================
;; F_400MS_SEQUENTIAL_FLASHING_ALL_OFF: 通用子函数
;; 功能: 顺序闪烁所有LED灯总时间400ms
;;============================================================================
F_400MS_SEQUENTIAL_FLASHING_ALL_OFF:
        ;;关闭LEDE
        MOVIA	C_LEDE_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDD
        MOVIA	C_LEDD_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg
        MOVIA	C_LEDD_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDC
        MOVIA	C_LEDC_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg
        MOVIA	C_LEDC_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDB
        MOVIA	C_LEDB_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDA
        MOVIA	C_LEDA_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        RET

;;============================================================================
;; F_600MS_SEQUENTIAL_FLASHING_ALL_OFF: 通用子函数
;; 功能: 顺序闪烁所有LED灯总时间400ms
;;============================================================================
F_600MS_SEQUENTIAL_FLASHING_ALL_OFF:
        ;;关闭LEDE
        MOVIA	C_LEDE_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDD
        MOVIA	C_LEDD_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg
        MOVIA	C_LEDD_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDC
        MOVIA	C_LEDC_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg
        MOVIA	C_LEDC_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDB
        MOVIA	C_LEDB_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 关闭LEDA
        MOVIA	C_LEDA_ACTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTA,C_SaveToReg

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

        RET
;;============================================================================
;; F_PHASE_B: 通用子函数
;; 功能: BIT_X 从 50%→100%, BIT_Y 从 0%→50%, MASK 保持常亮
;; 参数: V_MASK_ALWAYS, V_BIT_X, V_BIT_Y (调用前设置)
;;
;; PWM周期分3段:
;;   段1: MASK+X+Y 全亮,  时长=COUNT
;;   段2: MASK+X 亮, Y灭, 时长=HALF
;;   段3: 仅MASK亮,       时长=HALF-COUNT
;;============================================================================
F_PHASE_B:
        CLRR    V_BREATE_COUNT

SUB_PHASE_B_LOOP:
        ;; ======== 段1: MASK+X+Y 全亮, 时长=COUNT ========
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        BTRSC   STATUS,C_Status_Z_Bit
        LGOTO   SUB_SKIP_PHASE_B_SEG1

        MOVAR   V_BREATE_DELAY

        MOVR    V_BREATE_AL1,C_SaveToAcc
        MOVAR   PORTA
		MOVR    V_BREATE_BL1,C_SaveToAcc
        MOVAR   PORTB

SUB_PHASE_B_SEG1_DLY:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PHASE_B_SEG1_DLY
SUB_SKIP_PHASE_B_SEG1:

        ;; ======== 段2: MASK+X 亮, Y灭, 时长=HALF ========
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        MOVAR   V_BREATE_DELAY
		
        MOVR    V_BREATE_AL2,C_SaveToAcc
        MOVAR   PORTA
		MOVR    V_BREATE_BL2,C_SaveToAcc
        MOVAR   PORTB

SUB_PHASE_B_SEG2_DLY:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PHASE_B_SEG2_DLY

        ;; ======== 段3: 仅MASK亮, 时长=HALF-COUNT ========
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        MOVAR   V_BREATE_DELAY
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        SUBAR   V_BREATE_DELAY,C_SaveToReg

        BTRSC   STATUS,C_Status_Z_Bit
        LGOTO   SUB_SKIP_PHASE_B_SEG3

        MOVR    V_BREATE_AL3,C_SaveToAcc
        MOVAR   PORTA
		MOVR    V_BREATE_BL3,C_SaveToAcc
        MOVAR   PORTB

SUB_PHASE_B_SEG3_DLY:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PHASE_B_SEG3_DLY
SUB_SKIP_PHASE_B_SEG3:

        CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        INCR    V_BREATE_COUNT,C_SaveToReg
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        SUBAR   V_BREATE_COUNT,C_SaveToAcc
        BTRSS   STATUS,C_Status_Z_Bit
        LGOTO   SUB_PHASE_B_LOOP

        RET

;;============================================================================
;---------------------------- F_LED_MODE0------------------------------------
;-------------------------------------------------------------------------- 
F_LED_MODE0: 	
		MOVIA	C_BREATE_PERIOD
		;; 预计算半周期
        MOVAR   V_BREATE_PERIOD
        BCR		STATUS,C_Status_C_Bit
        RRR     V_BREATE_PERIOD,C_SaveToAcc
        MOVAR   V_HALF_PERIOD

        ;; 部分A: PB0 从 0% → 50%
SUB_PART_A:
        CLRR    V_BREATE_COUNT

SUB_PART_A_LOOP:
        ;; -- 段1: PB0亮, 时长=COUNT --
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        BTRSC   STATUS,C_Status_Z_Bit               ; COUNT==0 保护
        LGOTO   SUB_SKIP_PART_A_ON

        MOVAR   V_BREATE_DELAY
        MOVIA   C_LEDA_ACTRL                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
SUB_PART_A_DELAY_ON:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PART_A_DELAY_ON
SUB_SKIP_PART_A_ON:

        ;; -- 段2: 全灭, 时长=PERIOD-COUNT --
        MOVR    V_BREATE_PERIOD,C_SaveToAcc
        MOVAR   V_BREATE_DELAY
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        SUBAR   V_BREATE_DELAY,C_SaveToReg

        MOVIA   C_ALED_ALL_OFF                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
SUB_PART_A_DELAY_OFF:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PART_A_DELAY_OFF

        CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; COUNT递增, 直到 HALF
        INCR    V_BREATE_COUNT,C_SaveToReg
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        SUBAR   V_BREATE_COUNT,C_SaveToAcc
        BTRSS   STATUS,C_Status_Z_Bit
        LGOTO   SUB_PART_A_LOOP

        ;;==========================
        ;; 部分B: 调用通用子函数 ×5
        ;;==========================
        ;; B0: PB0(50→100%), PB1(0→50%), 无常亮
		MOVIA	C_ALED_ALL_OFF
		MOVAR	V_BREATE_BL3
		MOVIA	C_BLED_ALL_OFF
		MOVAR	V_BREATE_AL3
		
        MOVIA   C_LEDA_ACTRL  
		MOVAR	V_BREATE_AL2
		MOVIA	C_BLED_ALL_OFF
		MOVAR	V_BREATE_BL2
		
		MOVIA	C_LEDB_ACTRL
		ANDAR	V_BREATE_AL2,C_SaveToAcc
		MOVAR	V_BREATE_AL1
		MOVIA	C_BLED_ALL_OFF
		MOVAR	V_BREATE_BL1
        LCALL   F_PHASE_B
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; B1: PB1(50→100%), PB2(0→50%), PB0常亮
        MOVR    V_BREATE_AL2,C_SaveToAcc
        ANDAR	V_BREATE_AL3,C_SaveToReg
		MOVR    V_BREATE_BL2,C_SaveToAcc
        ANDAR	V_BREATE_BL3,C_SaveToReg
		
        MOVIA   C_LEDB_ACTRL  
		ANDAR	V_BREATE_AL2,C_SaveToReg
		MOVIA	C_BLED_ALL_OFF
		MOVAR	V_BREATE_BL2
		
		MOVIA	C_LEDC_ACTRL
		ANDAR	V_BREATE_AL2,C_SaveToAcc
		MOVAR	V_BREATE_AL1
		MOVIA	C_LEDC_BCTRL
		MOVAR	V_BREATE_BL1
        LCALL   F_PHASE_B
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; B2: PB2(50→100%), PB3(0→50%), PB0~1常亮
        MOVR    V_BREATE_AL2,C_SaveToAcc
        ANDAR	V_BREATE_AL3,C_SaveToReg
		MOVR    V_BREATE_BL2,C_SaveToAcc
        ANDAR	V_BREATE_BL3,C_SaveToReg
		
        MOVIA   C_LEDC_ACTRL  
		ANDAR	V_BREATE_AL2,C_SaveToReg
		MOVIA	C_LEDC_BCTRL
		ANDAR	V_BREATE_BL2,C_SaveToReg
		
		MOVIA	C_LEDD_ACTRL
		ANDAR	V_BREATE_AL2,C_SaveToAcc
		MOVAR	V_BREATE_AL1
		MOVIA	C_LEDD_BCTRL
		ANDAR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		
        LCALL   F_PHASE_B
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; B3: PB3(50→100%), PB4(0→50%), PB0~2常亮
        MOVR    V_BREATE_AL2,C_SaveToAcc
        ANDAR	V_BREATE_AL3,C_SaveToReg
		MOVR    V_BREATE_BL2,C_SaveToAcc
        ANDAR	V_BREATE_BL3,C_SaveToReg
		
        MOVIA   C_LEDD_ACTRL  
		ANDAR	V_BREATE_AL2,C_SaveToReg
		MOVIA	C_LEDD_BCTRL
		ANDAR	V_BREATE_BL2,C_SaveToReg
		
		MOVIA	C_ALED_ALL_OFF
		ANDAR	V_BREATE_AL2,C_SaveToAcc
		MOVIA	C_LEDE_BCTRL
		ANDAR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
        LCALL   F_PHASE_B
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;;==========================
        ;; 部分C: PB0~PB4 全亮, PB5 50%→100%
        ;;==========================
        CLRR    V_BREATE_COUNT
SUB_PART_C_LOOP:
        ;; -- 段1: 全部亮(PB0~PB5), 时长=HALF+COUNT --
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        MOVAR   V_BREATE_DELAY
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        ADDAR   V_BREATE_DELAY,C_SaveToReg  ; DELAY = HALF + COUNT

        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
SUB_PART_C_DELAY_ON:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PART_C_DELAY_ON

        ;; -- 段2: PB0~PB4亮, PB5灭, 时长=HALF-COUNT --
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        MOVAR   V_BREATE_DELAY
        MOVR    V_BREATE_COUNT,C_SaveToAcc
        SUBAR   V_BREATE_DELAY,C_SaveToReg  ; DELAY = HALF - COUNT

        BTRSC   STATUS,C_Status_Z_Bit               ; HALF-COUNT==0 保护
        LGOTO   SUB_SKIP_PART_C_OFF

		MOVIA	C_LEDE_BCTRL
		MOVAR	V_I
		COMR	V_I,C_SaveToAcc
        IORAR   PORTB,C_SaveToReg
SUB_PART_C_DELAY_OFF:
        DECRSZ  V_BREATE_DELAY,C_SaveToReg
        LGOTO   SUB_PART_C_DELAY_OFF
SUB_SKIP_PART_C_OFF:
        CLRWDT
        BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; COUNT递增, 直到 HALF
        INCR    V_BREATE_COUNT,C_SaveToReg
        MOVR    V_HALF_PERIOD,C_SaveToAcc
        SUBAR   V_BREATE_COUNT,C_SaveToAcc
        BTRSS   STATUS,C_Status_Z_Bit
        LGOTO   SUB_PART_C_LOOP

        ;; 全部完成, 6颗LED全亮
        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB
        ;; 延时200ms 1.8s~2s
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
		
		LCALL   F_400MS_SEQUENTIAL_FLASHING_ALL_OFF

		RET
;---------------------------- F_LED_MODE1------------------------------------
;-------------------------------------------------------------------------- 
F_LED_MODE1: 
        ;; 0~0.2s 所有LED常亮
        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 0.2~0.6s 所有E到A顺闪灭掉
        LCALL   F_400MS_SEQUENTIAL_FLASHING_ALL_OFF

        ;; 0.6~0.8s 所有全灭
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 0.8~1.0s 所有全亮
        MOVIA   C_ALED_ALL_ON                       
        MOVAR   PORTA
		MOVIA	C_BLED_ALL_ON
		MOVAR   PORTB

        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET
        MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		CLRWDT
		BTRSS   PORTA,C_BUTTON_PIN
        RET

        ;; 1.0~1.6s 所有E到A顺闪灭掉
        LCALL   F_600MS_SEQUENTIAL_FLASHING_ALL_OFF


        RET
;--------------- Interrupt Service Routine --------------------------------
;--------------------------------------------------------------------------
V_INT:
		; Interrupt Service - User program area
		MOVIA   00000000B
		MOVAR	INTF							; Clear all interrupt flags	
	
		RETIE									; Return from interrupt and enable interrupt globally
end												; End of Code
		