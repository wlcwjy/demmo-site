﻿; =========================================================================      
; Project:       
; File:          main.asm
; Description:   
;                 
; Author:        
; Version:       
; Date:         
; =========================================================================
;--------------- File Include ---------------------------------------------
;--------------------------------------------------------------------------
#include		NY8A051H.H						; The Header File for NY8A053E
;--------------- Variable Definition --------------------------------------
;--------------------------------------------------------------------------
;		R_Temp		EQU		0x10			; Example
V_BUTTON_IN_DELAY			EQU		0x10
V_SYSTEM_STATUS				EQU		0x11  
V_BUTTON_DELAY				EQU		0x12
V_DELAY_COUNT1				EQU		0x13    
V_DELAY_COUNT2				EQU		0x14   
V_BREATE_L1					EQU		0x15    
V_BREATE_L2					EQU		0x16  
V_BREATE_COUNT				EQU		0x17  
V_BREATE_DELAY				EQU		0x18  
V_BREATE_UP_TIME			EQU		0x19  
V_BREATE_DOWN_TIME			EQU		0x1A  
V_BREATE_AL1				EQU		0x1B    
V_PORTB						EQU		0x1C 
V_LED_MODE_ALL_TIME 		EQU		0x1D
V_LED_MODE_NUMBER			EQU		0x1E
V_LOOP_COUNT				EQU		0x1F

V_DELAY_T0_COUNT			EQU		0x20  
V_DELAY_T0_NMS				EQU		0x21 
V_DELAY_T0_TEMP				EQU		0x22
V_DELAY_T0_15MS				EQU		0x23 
V_DELAY_T0_30MS				EQU		0x24 
V_DELAY_T0_55MS				EQU		0x26 
V_DELAY_T0_60MS				EQU		0x27 
V_DELAY_T0_5MS				EQU		0x28
V_DELAY_T0_25MS				EQU		0x29 
V_DELAY_T0_40MS				EQU		0x2A 

V_I							EQU		0x30 
V_WAIT_RELEASE_COUNT		EQU		0x31 

V_LED_MODE_RUN_LOOP			EQU		0x36
;--------------- Constant Definition --------------------------------------
;--------------------------------------------------------------------------
;		C_Temp		EQU		0xFF			; Example
C_OSH_PIN					EQU 	0

C_LED_COLOR1_CTRL			EQU 	11011011B
C_LED_COLOR2_CTRL			EQU 	11101101B
C_LED_COLOR3_CTRL			EQU 	11110111B

C_LED_ALL_ON				EQU 	11000001B
C_LED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_IS_BUTTON_CHECK	EQU		1  
C_STATUS_LED_MODE			EQU		2  

C_BUTTON_SHORT_DELAY		EQU		10
C_BREATE_PERIOD				EQU		17
C_LED1_BREATE_PERIOD		EQU		48
C_MODE1_BREATE_PERIOD		EQU		40

;--------------- Vector Definition ----------------------------------------
;--------------------------------------------------------------------------
		ORG		0x000		
		LGOTO	V_Main                
		
		ORG		0x008
		LGOTO	V_INT
		
;--------------- Code Start -----------------------------------------------
;--------------------------------------------------------------------------
        ORG		0x010         
V_Main:
; Initial GPIO  
    
		; PORTB I/O state
		; PB3 ~ PB2 set input mode and enable pull-low resistor
		; PB1 ~ PB0 set open-drain output mode                  
		MOVIA   0
		IOST    BODCON								; Enable Open-Drain of PB1 & PB0 ,others disable 
		
        MOVIA   11111111B 
	    MOVAR   BPLCON								; Enable PB2 Pull-High Resistor,others disable
		
		MOVIA   11111110B 
	    MOVAR   BPHCON								; Enable PB1,PB3,PB4,PB5 Pull-High Resistor,others disable						 
		
		MOVIA   11000001B
		IOST    IOSTB								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTB								; PB1 & PB0 output high
		
		LCALL 	TIMER_CALIBRATION
		
		CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
F_MAIN_LOOP:                                    
        CLRWDT										; Clear WatchDog
		
		LCALL 	SYSTEM_SLEEP
		
		LCALL	LED_MODE0
		
		LGOTO   F_MAIN_LOOP
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- DELAY_MS_HCLK ----------------------------------
DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
DELAY_MS_HCLK_LOOP2:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		GOTO	DELAY_MS_HCLK_LOOP2
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		GOTO	DELAY_MS_HCLK
		RET       	
;---------------------------- T0_DELAY ----------------------------------
T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
T0_DELAY_LOOP:
		CLRWDT
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	T0_DELAY_LOOP
		RET

;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
TIMER_CALIBRATION:
		; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        SFUN    OSCCR                        		; OSCCR: Oscillation Control Register 
        NOP
	 	NOP
        
		MOVIA	10100011B
		T0MD 
        MOVIA	0
        MOVAR	TMR0
		
;   		BCR   	PORTB,5	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	DELAY_MS_HCLK
;        BSR   	PORTB,5

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_5MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_5MS,C_SaveToReg
		
		MOVAR	V_DELAY_T0_COUNT
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_15MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
		MOVAR	V_DELAY_T0_TEMP
       	SUBAR	V_DELAY_T0_15MS,C_SaveToReg
       	
       	MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_30MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_30MS,C_SaveToReg

        MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
        ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_40MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
       	INCR	V_DELAY_T0_40MS,C_SaveToReg
  
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_55MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_55MS,C_SaveToReg
       	
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_60MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_60MS,C_SaveToReg
		
		RET			
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
SYSTEM_SLEEP:
		LCALL 	TIMER_CALIBRATION
		
		MOVIA   C_LED_ALL_OFF
		MOVAR	PORTB								; Clear all interrupt flags
	
		MOVIA   00000000B
		MOVAR	INTF	
		MOVAR	PCON
		MOVAR	BWUCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON		;if is power on enable PB0 wakeup
		BSR		BWUCON,C_OSH_PIN			
			
		MOVIA   00000010B							;Enable PB INT
		MOVAR	INTE
	   	ENI											;Enable INT 	
		MOVR	PORTB,C_SaveToAcc
	 	SLEEP
	 	NOP
	 	NOP
	 	MOVIA   10001000B
		MOVAR	PCON
		
		;MOVIA	10100011B
		;T0MD 
       
		DISI;
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
	 	NOP
	 	
WAIT_OSH:
		CLRWDT
		BTRSS 	PORTB,C_OSH_PIN		;if is power on enable PB0 wakeup
		LGOTO 	WAIT_OSH	
	
		RET
;;---------------------------- LED_BREATHE--------------------------------
;;--------------------------------------------------------------------------  			
LED_BREATHE:
		MOVIA	C_BREATE_PERIOD
		MOVAR	V_BREATE_COUNT
		DECR	V_BREATE_COUNT,C_SaveToReg	
LED_BREATHE_LOOP:
		MOVR	V_BREATE_COUNT,C_SaveToAcc			;MOVE V_BREATE_COUNT to V_BREATE_DELAY
		MOVAR	V_BREATE_DELAY
		
		MOVR	V_BREATE_L1,C_SaveToAcc
		MOVAR	PORTB
LED_BREATHE_LOOP2:	
		DECRSZ  V_BREATE_DELAY,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP2
	
		MOVIA	C_BREATE_PERIOD
		MOVAR	V_BREATE_DELAY,
		MOVR	V_BREATE_COUNT,C_SaveToAcc			
		SUBAR	V_BREATE_DELAY,C_SaveToReg
		
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	PORTB
LED_BREATHE_LOOP1:
		DECRSZ  V_BREATE_DELAY,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP1
	
		DECRSZ  V_BREATE_COUNT,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP	
		RET
		
;---------------------------- LED_MODE_1--------------------------------
;------------------------------------------------------------------------ 
LED_MODE_1:
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVIA	C_LED_ALL_ON
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR2_CTRL	
		MOVAR	V_BREATE_L2
		MOVIA	C_LED_COLOR3_CTRL	
		ANDAR	V_BREATE_L2,C_SaveToReg
		LCALL 	LED_BREATHE
		
LED_MODE_1_T0_DELAY_LOOP1:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		LGOTO	LED_MODE_1_T0_DELAY_LOOP1
			
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR3_CTRL	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		
LED_MODE_1_T0_DELAY_LOOP2:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_1_T0_DELAY_LOOP2
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_ALL_OFF	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		
LED_MODE_1_T0_DELAY_LOOP3:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_1_T0_DELAY_LOOP3
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVIA	C_LED_ALL_ON
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_L2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_L2,C_SaveToReg
		LCALL 	LED_BREATHE
		
LED_MODE_1_T0_DELAY_LOOP4:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_1_T0_DELAY_LOOP4
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR1_CTRL		
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		
LED_MODE_1_T0_DELAY_LOOP5:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_1_T0_DELAY_LOOP5
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_ALL_OFF	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		RET
;---------------------------- LED_MODE_2--------------------------------
;-------------------------------------------------------------------------- 
LED_MODE_2:
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVIA	C_LED_ALL_OFF
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		
LED_MODE_2_T0_DELAY_LOOP1:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_2_T0_DELAY_LOOP1
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_L2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_L2,C_SaveToReg
		LCALL 	LED_BREATHE
		
LED_MODE_2_T0_DELAY_LOOP2:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_2_T0_DELAY_LOOP2
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVIA	C_LED_ALL_ON
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_L2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_L2,C_SaveToReg
		LCALL 	LED_BREATHE
		
LED_MODE_2_T0_DELAY_LOOP3:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	LED_MODE_2_T0_DELAY_LOOP3
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVIA	C_LED_ALL_ON
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR2_CTRL	
		MOVAR	V_BREATE_L2
		MOVIA	C_LED_COLOR3_CTRL	
		ANDAR	V_BREATE_L2,C_SaveToReg
		LCALL 	LED_BREATHE
		
LED_MODE_2_T0_DELAY_LOOP4:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		LGOTO	LED_MODE_2_T0_DELAY_LOOP4
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_COLOR3_CTRL	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		
LED_MODE_2_T0_DELAY_LOOP5:
		CLRWDT
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		LGOTO	LED_MODE_2_T0_DELAY_LOOP5
		
		MOVR	V_DELAY_T0_60MS,C_SaveToAcc
		MOVAR	V_DELAY_T0_COUNT
		MOVAR	TMR0
		MOVR	V_BREATE_L2,C_SaveToAcc
		MOVAR	V_BREATE_L1
		MOVIA	C_LED_ALL_OFF	
		MOVAR	V_BREATE_L2
		LCALL 	LED_BREATHE
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		RET
;---------------------------- LED_MODE_3--------------------------------
;-------------------------------------------------------------------------- 	
;L1--PB1 L2--PB0 L3--PB2
;L1--PB2 L2--PB1 L3--PB0	
LED_MODE_3:
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	 
		MOVIA   C_LED_COLOR2_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
      	 
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	
		MOVIA   C_LED_COLOR3_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	 
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
      	
		RET 			
;---------------------------- LED_MODE_4--------------------------------
;-------------------------------------------------------------------------- 
LED_MODE_4:
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR2_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
       
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_LED_COLOR2_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR3_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
 
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
    
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR3_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
    
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	

		RET

		
;---------------------------- LED_MODE1--------------------------------
;--------------------------------------------------------------------------  
LED_MODE0:
		LCALL 	LED_MODE_1
		
		LCALL 	LED_MODE_1
		
		LCALL 	LED_MODE_2
		
		LCALL 	LED_MODE_2
		
		LCALL	LED_MODE_3
		
		LCALL	LED_MODE_3
		
		LCALL	LED_MODE_3
	
		LCALL	LED_MODE_3
		
		LCALL	LED_MODE_4
		
		LCALL	LED_MODE_4
		
		LCALL	LED_MODE_4
		
		LCALL	LED_MODE_4	
		RET
;--------------- Interrupt Service Routine --------------------------------
;--------------------------------------------------------------------------
V_INT:
		; Interrupt Service - User program area
		MOVIA   00000000B
		MOVAR	INTF							; Clear all interrupt flags	
	
		RETIE									; Return from interrupt and enable interrupt globally
end												; End of Code
		