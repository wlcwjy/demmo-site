﻿; =========================================================================      
; Project:       
; File:          main.asm
; Description:   
;                 
; Author:        
; Version:       
; Date:         
; =========================================================================
;--------------- File Include ---------------------------------------------
;--------------------------------------------------------------------------
#include		NY8A051H.H							; The Header File for NY8A053E
;--------------- Variable Definition --------------------------------------
;--------------------------------------------------------------------------
;		R_Temp		EQU		0x10			; Example
V_BUTTON_IN_DELAY			EQU		0x10
V_BUTTON_IN_DELAY_H			EQU		0x11
V_SYSTEM_STATUS				EQU		0x12  
V_DELAY_COUNT1				EQU		0x13    
V_DELAY_COUNT2				EQU		0x14   
V_PORTB0				    EQU		0x15    
V_BREATE_BL1				EQU		0x16  
V_BREATE_COUNT				EQU		0x17  
V_BREATE_DELAY				EQU		0x18  
V_BREATE_UP_TIME			EQU		0x19  
V_RANDOM_ADDR				EQU		0x1A  
V_BREATE_AL2				EQU		0x1B    
V_BREATE_BL2				EQU		0x1C 
V_BREATE_PERIOD 			EQU		0x1D
V_LED_MODE_NUMBER			EQU		0x1E
V_RUN_LOOP					EQU		0x1F

V_DELAY_T0_COUNT			EQU		0x20  
V_DELAY_T0_NMS				EQU		0x21 
V_DELAY_T0_TEMP				EQU		0x22
V_DELAY_T0_25MS				EQU		0x23 
V_DELAY_T0_30MS				EQU		0x24 
V_DELAY_T0_40MS				EQU		0x25 
V_DELAY_T0_50MS				EQU		0x26 
V_DELAY_T0_60MS				EQU		0x27 
V_DELAY_T0_8MS				EQU		0x28 

V_I							EQU		0x30 
V_ADDR						EQU		0x31 
V_PORTA						EQU		0x32
V_LED_MODE_RUN_LOOP			EQU		0x36
;--------------- Constant Definition --------------------------------------
;--------------------------------------------------------------------------
;		C_Temp		EQU		0xFF			; Example

C_OSH_PIN 					EQU 	0
C_BUTTON_PIN				EQU 	1
C_LED1_BCTRL				EQU 	11111011B
C_LED2_BCTRL				EQU 	11011111B
C_LED3_BCTRL				EQU 	11101111B
C_LED4_BCTRL				EQU 	11110111B

C_LED_COLOR1_CTRL			EQU 	11101111B
C_LED_COLOR2_CTRL			EQU 	11011111B
C_LED_COLOR3_CTRL			EQU 	11110011B

C_BLED_ALL_ON				EQU 	11000011B
C_BLED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_BUTTON_SHORT_PRESS	EQU		1  
C_STATUS_LED_MODE			EQU		2 
C_STATUS_BUTTON_LONG_PRESS	EQU		3 
C_STATUS_BREATE_BUSY		EQU		4 

C_BUTTON_SHORT_DELAY		EQU		3
C_BREATE_PERIOD				EQU		17
C_BUTTON_LONG_DELAY			EQU		110


C_DELAY_25MS				EQU		54
C_DELAY_31MS				EQU		62
C_DELAY_100MS				EQU		210
;--------------- Vector Definition ----------------------------------------
;--------------------------------------------------------------------------
		ORG		0x000		
		LGOTO	V_Main                
		
		ORG		0x008
		LGOTO	V_INT
;--------------- Code Start -----------------------------------------------
;--------------------------------------------------------------------------
        ORG		0x010         
V_Main:
; Initial GPIO  
    
		; PORTB I/O state
		; PB3 ~ PB2 set input mode and enable pull-low resistor
		; PB1 ~ PB0 set open-drain output mode                  
		MOVIA   0
		IOST    BODCON								; Enable Open-Drain of PB1 & PB0 ,others disable 
			
        MOVIA   11111100B 
	    MOVAR   BPHCON								; Enable PB2 Pull-High Resistor,others disable
								 
		MOVIA   00000011B
		IOST    IOSTB								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTB								; PB1 & PB0 output high
		
		MOVIA	10100011B
        T0MD 
        MOVIA	0
        MOVAR	TMR0
		
		LCALL	F_TIMER_CALIBRATION
		
		CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
F_MAIN_LOOP:                                    
        CLRWDT										; Clear WatchDog
		LCALL 	F_SYSTEM_SLEEP
		
		MOVIA	0
        BCR     STATUS,C_Status_Z_bit    	; Clear Zero bit of Status Register
		XORAR   V_LED_MODE_NUMBER,C_SaveToAcc                      
		BTRSC	STATUS,C_Status_Z_bit    	; If ACC(C_KEY1_VALUE)==V_KEY1 , then Zero bit=1
		LGOTO	SUB_MAIN_LOOP_JUMP_LED_MODE0
		
		MOVIA	1
        BCR     STATUS,C_Status_Z_bit    	; Clear Zero bit of Status Register
		XORAR   V_LED_MODE_NUMBER,C_SaveToAcc                      
		BTRSC	STATUS,C_Status_Z_bit    	; If ACC(C_KEY1_VALUE)==V_KEY1 , then Zero bit=1
		LGOTO	SUB_MAIN_LOOP_JUMP_LED_MODE1


		LCALL	F_LED_MODE2
		CLRR	V_LED_MODE_NUMBER
		LGOTO   F_MAIN_LOOP
SUB_MAIN_LOOP_JUMP_LED_MODE0:
		LCALL	F_LED_MODE0
        INCR	V_LED_MODE_NUMBER,C_SaveToReg
		LGOTO   F_MAIN_LOOP
SUB_MAIN_LOOP_JUMP_LED_MODE1:
		LCALL	F_LED_MODE1
        INCR	V_LED_MODE_NUMBER,C_SaveToReg
		LGOTO   F_MAIN_LOOP

			
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- DELAY_MS_HCLK ----------------------------------
DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
DELAY_MS_HCLK_LOOP2:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		GOTO	DELAY_MS_HCLK_LOOP2
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		GOTO	DELAY_MS_HCLK
		RET       	
;---------------------------- T0_DELAY ----------------------------------
T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
T0_DELAY_LOOP:
		CLRWDT
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	T0_DELAY_LOOP
		RET	
;---------------------------- F_LED_SWITCH_ON--------------------------------
;--------------------------------------------------------------------------  		
F_LED_SWITCH_ON:
		CLRR	V_LED_MODE_NUMBER
        LCALL 	F_LED_SWITCH_OFF
		
		LCALL 	F_LED_SWITCH_OFF	

        LCALL 	F_LED_SWITCH_OFF
		
		RET 
;---------------------------- F_LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
F_LED_SWITCH_OFF:
		MOVIA   C_BLED_ALL_ON
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_50MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
      	
		RET 
;---------------------------- F_BUTTON_CHECK--------------------------------
;--------------------------------------------------------------------------        
F_BUTTON_CHECK:
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		BTRSC	PORTB,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		; Normal mode into Slow mode
        MOVIA   C_FLOSC_Sel                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
	 	NOP
        
		MOVIA   00000000B
		MOVAR	V_BUTTON_IN_DELAY
SUB_BUTTON_CHECK_WAIT:
		BTRSC	PORTB,C_BUTTON_PIN					 
		;GOTO	BUTTON_CHECK_END					;Button release,goto button check end
		RET
		CLRWDT	
        BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
        LGOTO   SUB_BUTTON_CHECK_WAIT
		
		MOVIA	C_BUTTON_SHORT_DELAY
        BCR     STATUS,C_Status_C_bit    			; Clear Zero bit of Status Register
		CMPAR   V_BUTTON_IN_DELAY                    
		BTRSC	STATUS,C_Status_C_bit    			; If V_BUTTON_IN_DELAY>C_BUTTON_SHORT_DELAY , then C bit=1
		LGOTO	SUB_BUTTON_CHECK_EFFECT
		INCR    V_BUTTON_IN_DELAY,C_SaveToReg
		LGOTO	SUB_BUTTON_CHECK_WAIT
SUB_BUTTON_CHECK_EFFECT:				
		MOVIA   11111111B
		MOVAR   PORTB														
		BSR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO	SUB_BUTTON_CHECK_WAIT
		RET
;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
F_TIMER_CALIBRATION:
		; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        SFUN    OSCCR                        		; OSCCR: Oscillation Control Register 
        NOP
        NOP
        
		MOVIA	10100011B
		T0MD 
        MOVIA	0
        MOVAR	TMR0
		
;   		BCR   	PORTB,5	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	DELAY_MS_HCLK
;        BSR   	PORTB,5

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_8MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_8MS,C_SaveToReg
		DECR 	V_DELAY_T0_8MS,C_SaveToReg
		DECR 	V_DELAY_T0_8MS,C_SaveToReg	
		DECR 	V_DELAY_T0_8MS,C_SaveToReg	
		DECR 	V_DELAY_T0_8MS,C_SaveToReg		
		
		MOVAR	V_DELAY_T0_COUNT
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_25MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_25MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_30MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_30MS,C_SaveToReg

		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_40MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_40MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_50MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_50MS,C_SaveToReg
		
		RET		
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
F_SYSTEM_SLEEP:
		MOVIA   11111111B
		MOVAR   PORTB								;PORTB output high
		;LCALL 	F_BUTTON_CHECK
		BTRSS	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO	SUB_NO_BUTTON0
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	SUB_BUTTON_SET_POWER_OFF0
SUB_BUTTON_SET_POWER_ON0:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO 	F_SYSTEM_SLEEP
SUB_BUTTON_SET_POWER_OFF0:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_OFF
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		LGOTO 	F_SYSTEM_SLEEP
SUB_NO_BUTTON0:
		BTRSS	PORTB,C_OSH_PIN						;Wait OSH PIN to be 1
		LGOTO 	F_SYSTEM_SLEEP		
SUB_SYSTEM_SLEEP_ENTRY:
		LCALL   F_TIMER_CALIBRATION
		
		MOVIA   11111111B
		MOVAR	PORTB								; Clear all interrupt flags

		MOVIA   00000000B
		MOVAR	INTF	
		MOVAR	PCON
		MOVAR	BWUCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON		;if is power on enable PB0 wakeup
		BSR		BWUCON,C_OSH_PIN
		BSR		BWUCON,C_BUTTON_PIN 				
			
		
		MOVIA   00000010B							;Enable PB INT
		MOVAR	INTE
	   	ENI											;Enable INT 	
		MOVR	PORTB,C_SaveToAcc
	 	SLEEP
	 	NOP
        NOP
	 	MOVIA   10001000B
		MOVAR	PCON
		
		;MOVIA	10100011B
		;T0MD 
       
		DISI;
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
        
		LCALL 	F_BUTTON_CHECK						;If button in is yes,goto sleep,
        BTRSS	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO	SUB_NO_BUTTON
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	SUB_BUTTON_SET_POWER_OFF1
SUB_BUTTON_SET_POWER_ON1:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO 	F_SYSTEM_SLEEP
SUB_BUTTON_SET_POWER_OFF1:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_OFF
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO 	F_SYSTEM_SLEEP
		
SUB_NO_BUTTON:		
		BTRSS 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	F_SYSTEM_SLEEP
		
SUB_SYSTEM_SLEEP_WAIT_OSH_STOP:
		CLRWDT
		BTRSS 	PORTB,C_OSH_PIN		;if is power on enable PB0 wakeup
		LGOTO 	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP	
	
		RET
;;---------------------------- LED_BREATHE--------------------------------
;;--------------------------------------------------------------------------  			
LED_BREATHE:
		MOVIA	C_BREATE_PERIOD
		MOVAR	V_BREATE_COUNT
		DECR	V_BREATE_COUNT,C_SaveToReg	
LED_BREATHE_LOOP:
		MOVR	V_BREATE_COUNT,C_SaveToAcc			;MOVE V_BREATE_COUNT to V_BREATE_DELAY
		MOVAR	V_BREATE_DELAY
		
		MOVR	V_BREATE_BL1,C_SaveToAcc
		MOVAR	PORTB
LED_BREATHE_LOOP2:	
		DECRSZ  V_BREATE_DELAY,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP2
	
		MOVIA	C_BREATE_PERIOD
		MOVAR	V_BREATE_DELAY,
		MOVR	V_BREATE_COUNT,C_SaveToAcc			
		SUBAR	V_BREATE_DELAY,C_SaveToReg
		
		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	PORTB
LED_BREATHE_LOOP1:
		DECRSZ  V_BREATE_DELAY,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP1
		
		CLRWDT
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
	
		DECRSZ  V_BREATE_COUNT,C_SaveToReg	
		LGOTO 	LED_BREATHE_LOOP	
		RET
		
;---------------------------- LED_MODE_1--------------------------------
;------------------------------------------------------------------------ 
LED_MODE_1:
		MOVIA	C_BLED_ALL_ON
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR2_CTRL	
		MOVAR	V_BREATE_BL2
		MOVIA	C_LED_COLOR3_CTRL	
		ANDAR	V_BREATE_BL2,C_SaveToReg
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		

		
		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR3_CTRL	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		

		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_BLED_ALL_OFF	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVIA	C_BLED_ALL_ON
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_BL2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_BL2,C_SaveToReg
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR1_CTRL		
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_BLED_ALL_OFF	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		RET
;---------------------------- LED_MODE_2--------------------------------
;-------------------------------------------------------------------------- 
LED_MODE_2:
		MOVIA	C_BLED_ALL_OFF
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		

		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_BL2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_BL2,C_SaveToReg
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVIA	C_BLED_ALL_ON
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR1_CTRL	
		MOVAR	V_BREATE_BL2
		MOVIA	C_LED_COLOR2_CTRL	
		ANDAR	V_BREATE_BL2,C_SaveToReg
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVIA	C_BLED_ALL_ON
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR2_CTRL	
		MOVAR	V_BREATE_BL2
		MOVIA	C_LED_COLOR3_CTRL	
		ANDAR	V_BREATE_BL2,C_SaveToReg
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET

		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_LED_COLOR3_CTRL	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVR	V_BREATE_BL2,C_SaveToAcc
		MOVAR	V_BREATE_BL1
		MOVIA	C_BLED_ALL_OFF	
		MOVAR	V_BREATE_BL2
		LCALL 	LED_BREATHE
		RET
;---------------------------- LED_MODE_3--------------------------------
;-------------------------------------------------------------------------- 	
;L1--PB1 L2--PB0 L3--PB2
;L1--PB2 L2--PB1 L3--PB0	
LED_MODE_3:
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	 
		MOVIA   C_LED_COLOR2_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	 
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	
		MOVIA   C_LED_COLOR3_CTRL
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	 
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
      	
		RET 			
;---------------------------- LED_MODE_4--------------------------------
;-------------------------------------------------------------------------- 
LED_MODE_4:
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR2_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
       
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
		MOVIA   C_LED_COLOR2_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR3_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
 
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
    
		MOVIA   C_LED_COLOR1_CTRL
		MOVAR   PORTB	
		MOVIA   C_LED_COLOR3_CTRL
		ANDAR   PORTB,C_SaveToReg
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
		LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
    
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB	
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	

		RET

		
;---------------------------- F_LED_MODE0--------------------------------
;--------------------------------------------------------------------------  
F_LED_MODE0:
		LCALL 	LED_MODE_1
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL 	LED_MODE_1
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL 	LED_MODE_2
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL 	LED_MODE_2
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_3
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_3
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_3
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_3
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_4
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_4
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_4
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		LCALL	LED_MODE_4	
		RET
;---------------------------- F_LED_MODE1--------------------------------
;------------------------------------------------------------------------ 
F_LED_MODE1:
		MOVIA   24
        MOVAR   V_DELAY_COUNT1
SUB_LED_MODE1_DELAY:        
		MOVIA   C_LED4_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
 
		
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
    
		
		MOVIA   C_LED3_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_LED2_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_LED1_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
        LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
        DECRSZ  V_DELAY_COUNT1,C_SaveToReg	
		LGOTO 	SUB_LED_MODE1_DELAY
		RET
		
;---------------------------- F_LED_MODE2--------------------------------
;------------------------------------------------------------------------ 
F_LED_MODE2:
		MOVIA   12
        MOVAR   V_DELAY_COUNT1
SUB_LED_MODE2_DELAY:        
		MOVIA   C_LED4_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		 MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
 
		
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		 MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
    
		
		MOVIA   C_LED3_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_LED2_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		 MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		MOVIA   C_LED1_BCTRL
		MOVAR	PORTB
        MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		 MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
   
		MOVIA   C_BLED_ALL_OFF
		MOVAR	PORTB
        MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
        MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
        LCALL	F_BUTTON_CHECK
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		RET
		
        DECRSZ  V_DELAY_COUNT1,C_SaveToReg	
		LGOTO 	SUB_LED_MODE2_DELAY
		RET
;--------------- Interrupt Service Routine --------------------------------
;--------------------------------------------------------------------------
V_INT:
		; Interrupt Service - User program area
		MOVIA   00000000B
		MOVAR	INTF							; Clear all interrupt flags	
	
		RETIE									; Return from interrupt and enable interrupt globally
end												; End of Code
		