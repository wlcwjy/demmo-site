﻿; =========================================================================      
; Project:       
; File:          main.asm
; Description:   
;                 
; Author:        
; Version:       
; Date:         
; =========================================================================
;--------------- File Include ---------------------------------------------
;--------------------------------------------------------------------------
#include		NY8A054E.H						; The Header File for NY8A053E
;--------------- Variable Definition --------------------------------------
;--------------------------------------------------------------------------
;		R_Temp		EQU		0x10			; Example
V_BUTTON_IN_DELAY			EQU		0x40
V_SYSTEM_STATUS				EQU		0x41  
V_BUTTON_DELAY				EQU		0x42
V_DELAY_COUNT1				EQU		0x43    
V_DELAY_COUNT2				EQU		0x44   
V_BREATE_AL1				EQU		0x45    
V_BREATE_BL1				EQU		0x46  
V_BREATE_COUNT				EQU		0x47  
V_BREATE_DELAY				EQU		0x48  
V_BREATE_UP_TIME			EQU		0x49  
V_BREATE_DOWN_TIME			EQU		0x4A  
V_BREATE_AL2				EQU		0x4B    
V_BREATE_BL2				EQU		0x4C 
V_BREATE_PERIOD 			EQU		0x4D
V_LED_MODE_NUMBER			EQU		0x4E
V_RUN_LOOP					EQU		0x4F

V_DELAY_T0_COUNT			EQU		0x20  
V_DELAY_T0_NMS				EQU		0x21 
V_DELAY_T0_TEMP				EQU		0x22
V_DELAY_T0_25MS				EQU		0x23 
V_DELAY_T0_30MS				EQU		0x24 
V_DELAY_T0_40MS				EQU		0x25 
V_DELAY_T0_55MS				EQU		0x26 
V_DELAY_T0_60MS				EQU		0x27 
V_DELAY_T0_8MS				EQU		0x28 

V_I							EQU		0x30 
V_ADDR						EQU		0x31 
V_PORTA						EQU		0x32
V_LED_MODE_RUN_LOOP			EQU		0x33

V_LED_COLOR1_BCTRL			EQU 	0x34
V_LED_COLOR2_BCTRL			EQU 	0x35
V_LED_COLOR3_BCTRL			EQU 	0x36
V_LED_COLOR1_ACTRL			EQU 	0x37
V_LED_COLOR2_ACTRL			EQU 	0x38
V_LED_COLOR3_ACTRL			EQU 	0x39
V_LED_COLORA_ALL_ON			EQU 	0x3A
V_LED_COLORB_ALL_ON			EQU 	0x3B
V_LED_COLORA_ALL_OFF		EQU 	0x3C
V_LED_COLORB_ALL_OFF		EQU 	0x3D

;--------------- Constant Definition --------------------------------------
;--------------------------------------------------------------------------
;		C_Temp		EQU		0xFF			; Example

C_OSH_PIN 					EQU 	2
C_BUTTON_PIN				EQU 	3
C_LED1_BCTRL				EQU 	11011111B
C_LED2_ACTRL				EQU 	11111110B
C_LED3_ACTRL				EQU 	11111101B
C_LED4_ACTRL				EQU 	01111111B
C_LED5_ACTRL				EQU 	10111111B
C_LED6_ACTRL				EQU 	11101111B

C_ALED_ALL_ON				EQU 	00101100B
C_BLED_ALL_ON				EQU 	00000000B
C_ALED_ALL_OFF				EQU 	11111111B
C_BLED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_IS_BUTTON_CHECK	EQU		1  
C_STATUS_LED_MODE			EQU		2  

C_BUTTON_SHORT_DELAY		EQU		10
C_BREATE_PERIOD				EQU		17
C_LED_MODE0_BREATE_PERIOD	EQU		19
C_MODE1_BREATE_PERIOD		EQU		72
C_MODE2_BREATE_PERIOD		EQU		39

C_DELAY_25MS				EQU		54
C_DELAY_31MS				EQU		62
C_DELAY_100MS				EQU		210
;--------------- Vector Definition ----------------------------------------
;--------------------------------------------------------------------------
		ORG		0x000		
		LGOTO	V_Main                
		
		ORG		0x008
		LGOTO	V_INT
		
;--------------- Code Start -----------------------------------------------
;--------------------------------------------------------------------------
        ORG		0x010         
V_Main:
; Initial GPIO  
    
		; PORTB I/O state
		; PB3 ~ PB2 set input mode and enable pull-low resistor
		; PB1 ~ PB0 set open-drain output mode                  
		MOVIA   0
		IOST    BODCON								; Enable Open-Drain of PB1 & PB0 ,others disable 
		
        MOVIA   11111111B
        MOVAR   ABPLCON								; Enable PB3 Pull-Low Resistor,others disable
			
        MOVIA   11111111B 
	    MOVAR   BPHCON								; Enable PB2 Pull-High Resistor,others disable
								 
		MOVIA   00000000B
		IOST    IOSTB								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTB								; PB1 & PB0 output high
		
		MOVIA   11110011B 
	    IOST    APHCON								; Enable PB2 Pull-High Resistor,others disable
		
		MOVIA   00101100B
		IOST    IOSTA								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTA	
		
		MOVIA	10100011B
        T0MD 
        MOVIA	0
        MOVAR	TMR0
		
		CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
F_MAIN_LOOP:                                    
        CLRWDT										; Clear WatchDog
		LCALL 	F_SYSTEM_SLEEP
		LCALL 	F_LED_MODE0
		LGOTO   F_MAIN_LOOP
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- DELAY_MS_HCLK ----------------------------------
DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
DELAY_MS_HCLK_LOOP2:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		LGOTO	DELAY_MS_HCLK_LOOP2
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		LGOTO	DELAY_MS_HCLK
		RET       	
;---------------------------- T0_DELAY ----------------------------------
T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
T0_DELAY_LOOP:
		CLRWDT
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	T0_DELAY_LOOP
		RET
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- LED_SWITCH_ON--------------------------------
;--------------------------------------------------------------------------  		
LED_SWITCH_ON:
		LCALL	LED_SWITCH_OFF
		
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		
		RET 
;---------------------------- LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
LED_SWITCH_OFF:
		MOVIA   C_BLED_ALL_ON
		MOVAR   PORTB	
		MOVIA   C_ALED_ALL_ON
		MOVAR   PORTA	
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		MOVR	V_DELAY_T0_8MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
	
		MOVIA   C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVAR   PORTA
		RET 		
;---------------------------- BUTTON_CHECK--------------------------------
;--------------------------------------------------------------------------        
BUTTON_CHECK:
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		BTRSC	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
        
		MOVIA   00000000B
		MOVAR	V_BUTTON_IN_DELAY
WAIT_BUTTON_CHECK:
		BTRSC	PORTA,C_BUTTON_PIN					 
		RET					;Button release,goto button check end
		CLRWDT	
		
		MOVIA	C_BUTTON_SHORT_DELAY
        BCR     STATUS,C_Status_C_bit    			; Clear Zero bit of Status Register
		CMPAR   V_BUTTON_IN_DELAY                    
		BTRSC	STATUS,C_Status_C_bit    			; If V_BUTTON_IN_DELAY>C_BUTTON_SHORT_DELAY , then C bit=1
		LGOTO	BUTTON_CHECK_EFFECT
		INCR    V_BUTTON_IN_DELAY,C_SaveToReg
		LGOTO	WAIT_BUTTON_CHECK
BUTTON_CHECK_EFFECT:		
		
		MOVIA   11111111B
		MOVAR   PORTA								; PA output high
        MOVAR   PORTB								; PB output high
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	WAIT_BUTTON_CHECK
		RET 
;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
F_TIMER_CALIBRATION:
		; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        SFUN    OSCCR                        		; OSCCR: Oscillation Control Register  
        NOP
        NOP
        
		MOVIA	10100011B
		T0MD 
        MOVIA	0
        MOVAR	TMR0
		
;   		BCR   	PORTB,5	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	DELAY_MS_HCLK
;        BSR   	PORTB,5

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_8MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_8MS,C_SaveToReg
		DECR	V_DELAY_T0_8MS,C_SaveToReg
		DECR	V_DELAY_T0_8MS,C_SaveToReg
		DECR	V_DELAY_T0_8MS,C_SaveToReg
		

       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_25MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_25MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_30MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_30MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_40MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_40MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_55MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_55MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_60MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_60MS,C_SaveToReg
		
		RET		
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
F_SYSTEM_SLEEP:
		MOVIA   11111111B
		MOVAR   PORTB								;PORTB output high
		MOVAR   PORTA								;PORTB output high
		LCALL 	BUTTON_CHECK
		BTRSS	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	NO_BUTTON0
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	BUTTON_SET_POWER_OFF0
BUTTON_SET_POWER_ON0:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_ON
		LCALL	LED_SWITCH_ON
		LCALL	LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
BUTTON_SET_POWER_OFF0:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
NO_BUTTON0:
		BTRSS	PORTB,C_OSH_PIN						;Wait OSH PIN to be 1
		LGOTO 	F_SYSTEM_SLEEP		
	
ENTRY_SLEEP:
		LCALL	F_TIMER_CALIBRATION
		
		
		MOVIA   11111111B
		MOVAR	PORTB								; Clear all interrupt flags
		MOVIA   11111111B
		MOVAR	PORTA	
		
		MOVIA   00000000B
		MOVAR	INTF	
		MOVAR	AWUCON
		MOVIA   01000000B
		MOVAR	PCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON		;if is power on enable PB0 wakeup
		BSR		AWUCON,C_OSH_PIN
		BSR		AWUCON,C_BUTTON_PIN 				
			
		
		MOVIA   00000010B							;Enable PB INT
		MOVAR	INTE
	   	ENI											;Enable INT 	
		MOVR	PORTB,C_SaveToAcc
	 	SLEEP
	 	NOP
        NOP
        MOVIA   11001000B
		MOVAR	PCON
		
		;MOVIA	10100011B
		;T0MD 
       
		DISI;
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
        
		LCALL 	BUTTON_CHECK						;If button in is yes,goto sleep,
		BTRSS	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	NO_BUTTON
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	BUTTON_SET_POWER_OFF1
BUTTON_SET_POWER_ON1:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_ON
		LCALL	LED_SWITCH_ON
		LCALL	LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
BUTTON_SET_POWER_OFF1:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_OFF
		LGOTO 	F_SYSTEM_SLEEP
		
NO_BUTTON:		
		BTRSS 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	F_SYSTEM_SLEEP
		
WAIT_OSH:
		CLRWDT
		BTRSS 	PORTB,C_OSH_PIN		;if is power on enable PB0 wakeup
		LGOTO 	WAIT_OSH	
	
		RET
		
;---------------------------- LED_MODE0------------------------------------
;-------------------------------------------------------------------------- 
F_LED_MODE0: 	
		MOVIA 	3
		MOVAR	V_RUN_LOOP
SUB_LED_MODE0_LOOP1:
		;1
		MOVIA	C_ALED_ALL_OFF
		MOVAR	PORTA
		MOVIA	C_LED1_BCTRL
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		;2
		MOVIA	C_LED2_ACTRL
		MOVAR	PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		
		;3
		MOVIA	C_LED3_ACTRL
		MOVAR	PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		
		;4
		MOVIA	C_LED4_ACTRL
		MOVAR	PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		
		;5
		MOVIA	C_LED5_ACTRL
		MOVAR	PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		
		;6
		MOVIA	C_LED6_ACTRL
		MOVAR	PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR   PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
		BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 

		MOVIA	C_ALED_ALL_OFF
		MOVAR   PORTA
		MOVIA	C_BLED_ALL_OFF
		MOVAR	PORTB
		MOVR	V_DELAY_T0_30MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
      	BTRSS	PORTA,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		RET 
		
		DECRSZ 	V_RUN_LOOP,C_SaveToReg
		LGOTO	SUB_LED_MODE0_LOOP1

		RET

;--------------- Interrupt Service Routine --------------------------------
;--------------------------------------------------------------------------
V_INT:
		; Interrupt Service - User program area
		MOVIA   00000000B
		MOVAR	INTF							; Clear all interrupt flags	
	
		RETIE									; Return from interrupt and enable interrupt globally
end												; End of Code
		