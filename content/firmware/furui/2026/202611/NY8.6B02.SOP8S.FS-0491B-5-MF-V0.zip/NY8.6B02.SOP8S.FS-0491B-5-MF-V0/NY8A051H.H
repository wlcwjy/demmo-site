;=======================================================================================================================
;=======================================================================================================================
;File:			NY8A051H.h
;Description:	The Header File for NY8A051H
;Author:		JasonLee
;Date:			2021/07/14
;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
;MOVR and MOVAR instrutions for access R-page Register (General Purpose Register)
;-----------------------------------------------------------------------------------------------------------------------
;R-page sregisters				;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-----------------------------------------------------------------------------------------------------------------------	
; 00H --------- Indirect Addressing Register
INDF				EQU		00H
; 01H --------- Timer0 Data Register	
TMR0				EQU		01H
; 02H --------- Low Byte of Program Counter
PCL					EQU		02H
; 03H --------- Status Register (Include SRAM Bank Select)
STATUS				EQU		03H ;	GP7			GP6			GP5			/WDT_TO		/Sleep		Z			Half_C		C	
; 04H --------- File Selection Register 
FSR					EQU		04H ;	BK[1]		BK[0]		FSR[5]		FSR[4]		FSR[3]		FSR[2]		FSR[1]		FSR[0]	        
; 05H --------- Reserved
; 06H --------- PortB Data Register
PORTB				EQU		06H
; 08H --------- Power Control Register (WatchDog,ExtINT,LVD,LVR,CMP Enable Control)
PCON				EQU		08H ;	WDTEn		ExtINTEn	LVDEn		GP4			LVREn		CMPEN		GP1			GP0
; 09H --------- PortB Wakeup Control Register
BWUCON				EQU		09H ;	-			-			PB[5]		PB[4]		PB[3]		PB[2]		PB[1]		PB[0]	
; 0AH --------- High Byte of Program Counter (B'xxxxxxDD')
PCHBUF				EQU		0AH ;	-			-			-			-			-			GP2			PCHBUF[1]	PCHBUF[0]
; 0BH --------- PortB Pull-Low Control Register
BPLCON				EQU		0BH ;	/PB[3]		/PB[2]		/PB[1]		/PB[0]		-			-			-			-			
; 0CH --------- PortB Pull-High Control Register
BPHCON				EQU		0CH ;	-			-			/PB[5]	    /PB[4]		/PB[3]	    /PB[2]		/PB[1]		/PB[0]	
; 0EH --------- Interrupt Enable Register
INTE				EQU		0EH ;	-			WDT			-			LVD			TMR1		ExtINT		PBKey		TMR0	
; 0FH --------- Interrupt Flag	Register (Write '0' to Clear Flag)
INTF				EQU		0FH ;	-			WDT			-			LVD			TMR1		ExtINT		PBKey		TMR0	

;-----------------------------------------------------------------------------------------------------------------------
;T0MD and T0MDR instrutions for access T0MD Register
;-----------------------------------------------------------------------------------------------------------------------
; xxH --------- Timer0 Control Register (Only Accessed by Instruction T0MD / T0MDR)
;T0MD				EQU		xxH	;	LClkSrc		INTEdge		ClkSel		EdgeSel		PS0WDT		PS0Div[2]	PS0Div[1]	PS0Div[0]	

;-----------------------------------------------------------------------------------------------------------------------
;IOST and IOSTR instrution for access F-page Register (IO Configuration Register)
;-----------------------------------------------------------------------------------------------------------------------
;F-page registers				;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-----------------------------------------------------------------------------------------------------------------------	
; 05H --------- Reserved
; 06H --------- PortB Direction(1:Input/0:Output) Control Register
IOSTB				EQU		06H
; 09H --------- Reserved	
; 0AH --------- Prescaler0 Counter Value Register
PS0CV				EQU		0AH
; 0CH --------- PortB Open-Drain Control Register
BODCON				EQU		0CH ;	-			-			PB[5]  		PB[4]		PB[3]  		PB[2]		PB[1]		PB[0]			
; 0EH --------- Comparator voltage select Control Register
CMPCR				EQU		0EH ;	GP7			RBIAS_H 	RBIAS_L		CMPF_INV	PS1			PS0			NS1			NS0	
; 0FH --------- Power Control Register 1
PCON1				EQU		0FH ;	GIE			LVDOUT		LVDS3		LVDS2		LVDS1		LVDS0		GP1			TMR0En	

;-----------------------------------------------------------------------------------------------------------------------
;SFUN and SFUNR instrution for access S-page Register (Special Function Register)
;-----------------------------------------------------------------------------------------------------------------------
;S-page registers				;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-----------------------------------------------------------------------------------------------------------------------											
; 00H --------- Timer1 Data Register	
TMR1				EQU		00H
; 01H --------- Timer1 Control Register	1
T1CR1				EQU		01H ;	PWM1En		PWM1ActB	-			-			-			OneShot		Reload		TMR1En	
; 02H --------- Timer1 Control Register	2
T1CR2				EQU		02H ;	-			-			ClkSel		EdgeSel		/PS1En		PS1Div[2]	PS1Div[1]	PS1Div[0]	
; 03H --------- PWM1 Duty Register
PWM1DUTY			EQU		03H
; 04H --------- Prescaler1 Counter Value Register
PS1CV				EQU		04H
; 05H --------- Buzzer1 Control Register
BZ1CR				EQU		05H ;	BZ1En		-			-			-			FSel[3]		FSel[2]		FSel[1]		FSel[0]	
; 06H --------- IR Control Register
IRCR				EQU		06H ;	-	   		-			-			-			-			PolSel  	IRF57K		IREn	
; 07H --------- Table Access High Byte Address Pointer Register
TBHP				EQU		07H ;	-			-			-			-			-			-			HPoint[1]	HPoint[0]	
; 08H --------- Table Access High Byte Data Register
TBHD				EQU		08H ;	-			-			HData[5]	HData[4]	HData[3]	HData[2]	HData[1]	HData[0]		
; 0FH --------- Oscillation Control Register (Include Switch Working Mode)
OSCCR				EQU		0FH ;	-			CMPOE		-			-			Mode[1]		Mode[0]		HOSC_Stop	HOSC_Sel	

;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
; R-page Special Function Register (General Purpose Register)
;-----------------------------------------------------------------------------------------------------------------------
;------------------------------------------------------------
; INDF (00H)	--------- Indirect Addressing Register
;------------------------------------------------------------
;Bit[7:0] : Indirect Address
	C_Indir_Addr		EQU		FFH

;------------------------------------------------------------
; TMR0 (01H)	--------- Timer0 Data Register	
;------------------------------------------------------------
;Bit[7:0] : Timer0 Data
	C_TMR0_Data			EQU		FFH

;------------------------------------------------------------
; PCL (02H)		--------- Low Byte of Program Counter
;------------------------------------------------------------
;Bit[7:0] : Low Byte of Program Counter
	C_PCLow_Data		EQU		FFH

;------------------------------------------------------------
; STATUS (03H)	--------- Status Register (Include RAM Bank Select)
;------------------------------------------------------------
;Bit[7:5] : Reserved
;Bit[4:0] : System Status
	C_Status_WDT		EQU		10H			; WatchDog Overflow Flag
	C_Status_Slp		EQU		08H			; Sleep (Power Down) Flag
	C_Status_Z			EQU		04H			; Zero Flag
	C_Status_HalfC		EQU		02H			; Half Carry/Half Borrow Flag
	C_Status_C			EQU		01H			; Carry/Borrow Flag
	
	C_Status_WDT_Bit	EQU		4
	C_Status_Slp_Bit	EQU		3
	C_Status_Z_Bit		EQU		2
	C_Status_HalfC_Bit	EQU		1
	C_Status_C_Bit		EQU		0

;------------------------------------------------------------ 
; FSR (04H)		--------- File Selection Register (Include SRAM Bank Select)        
;------------------------------------------------------------
;Bit[7:6] : FSR Bit Define	
	C_SFR_Bank0			EQU		00H			; Select Ram Bank0	
;Bit[5:0] : Select one Register out of 64 registers of specific Bank.
	C_SFR_RAM_Addr		EQU		3FH			; RAM Address Bit[5:0] 

;------------------------------------------------------------
; PORTB (06H)		--------- PortB Data Register
;------------------------------------------------------------	
;Bit[7:6] : Reserved
;Bit[5:0] : PORTB Data Bit Define	
	C_PB_Data			EQU		3FH			; PB Data
	C_PB5_Data			EQU		20H			; PB5 Data
	C_PB4_Data			EQU		10H			; PB4 Data
	C_PB3_Data			EQU		08H			; PB3 Data
	C_PB2_Data			EQU		04H			; PB2 Data
	C_PB1_Data			EQU		02H			; PB1 Data
	C_PB0_Data			EQU		01H			; PB0 Data
	
;------------------------------------------------------------	
; PCON (08H)		--------- (WatchDog,ExtINT,LVD,LVR,CMP Enable Control)
;------------------------------------------------------------
;Bit[7] : WatchDog Eanble
	C_WDT_En			EQU		80H			; WatchDog Enable
;Bit[6] : External INT Eanble
	C_ExtINT_En			EQU		40H			; External INT Enable
;Bit[5] : LVD Eanble
	C_LVD_En			EQU		20H			; LVD Enable	
;Bit[4] : Reserved
;Bit[3] : LVR Enable
	C_LVR_En			EQU		08H			; LVR Enable
;Bit[2] : Enable/disable voltage comparator
	C_CMP_En			EQU		04H			; Enable voltage comparator 
	C_CMP_Dis			EQU		00H			; Disable voltage comparator 	
;Bit[1:0] : Reserved

	C_WDT_En_Bit		EQU		7	
	C_EXINT_En_Bit		EQU		6		
	C_LVD_En_Bit		EQU		5	
	C_LVR_En_Bit		EQU		3
	C_CMP_En_Bit		EQU		2	
	
;------------------------------------------------------------	
; BWUCON (09H)	--------- PortB Wakeup Control Register
;------------------------------------------------------------
;Bit[7:6] : Reserved
;Bit[5:0] : BWUCON Bit Define
	C_PB_Wakeup			EQU		3FH			; PortB Wakeup Enable
	C_PB5_Wakeup		EQU		20H			; PB5 Wakeup Enable
	C_PB4_Wakeup		EQU		10H			; PB4 Wakeup Enable
	C_PB3_Wakeup		EQU		08H			; PB3 Wakeup Enable
	C_PB2_Wakeup		EQU		04H			; PB2 Wakeup Enable 
	C_PB1_Wakeup		EQU		02H			; PB1 Wakeup Enable
	C_PB0_Wakeup		EQU		01H			; PB0 Wakeup Enable

;------------------------------------------------------------	
; PCHBUF (0AH) --------- High Byte of Program Counter
;------------------------------------------------------------
;Bit[7:2] : Reserved
;Bit[1:0] : High Byte of Program Counter
	C_PCHigh_Data			EQU		03H

;------------------------------------------------------------		
; BPLCON (0BH)	--------- PortB Pull-Low Control Register
;------------------------------------------------------------
;Bit[7:4] : PortB Pull-Low Control Register (1:Disable, 0:Pull-High)
    C_PB_PLB			EQU		F0H			; PortB Pull-Low Control bit
    C_PB3_PLB			EQU		80H			; PB3 Pull-Low Control bit
    C_PB2_PLB			EQU		40H			; PB2 Pull-Low Control bit	
    C_PB1_PLB			EQU		20H			; PB1 Pull-Low Control bit 	
    C_PB0_PLB			EQU		10H			; PB0 Pull-Low Control bit
;Bit[3:0] : Reserved
	
;------------------------------------------------------------	
; BPHCON (0CH)	--------- PortB Pull-High Control Register
;------------------------------------------------------------
;Bit[7:6] : Reserved
;Bit[5:0]: PortB Pull-High Control Register (1:Disable, 0:Pull-High)
	C_PB_PHB			EQU		3FH			; PortB Pull-High Control bit   
	C_PB5_PHB			EQU		20H			; PB5 Pull-High Control bit
	C_PB4_PHB			EQU		10H			; PB4 Pull-High Control bit
	C_PB3_PHB			EQU		08H			; PB3 Pull-High Control bit	
	C_PB2_PHB			EQU		04H			; PB2 Pull-High Control bit
	C_PB1_PHB			EQU		02H			; PB1 Pull-High Control bit
	C_PB0_PHB			EQU		01H			; PB0 Pull-High Control bit

;------------------------------------------------------------
; INTE (0EH)		--------- Interrupt Enable Register
; INTF (0FH)		--------- Interrupt Flag Register
;------------------------------------------------------------
;Bit[7:0] : Interrupt Source
	C_INT_WDT			EQU		40H			; WDT timeout interrupt enable bit
	C_INT_LVD			EQU		10H			; LVD interrupt enable bit	
	C_INT_TMR1			EQU		08H			; Timer1 underflow interrupt enable bit
	C_INT_EXT			EQU		04H			; External interrupt enable bit
	C_INT_PBKey			EQU		02H			; PortB input change interrupt enable bit
	C_INT_TMR0			EQU		01H			; Timer0 overflow interrupt enable bit 

	C_INT_WDT_Bit		EQU		6	
	C_INT_LVD_Bit		EQU		4	
	C_INT_TMR1_Bit		EQU		3
	C_INT_EXT_Bit		EQU		2	
	C_INT_PBKey_Bit		EQU		1
	C_INT_TMR0_Bit		EQU		0

;------------------------------------------------------------	
; T0MD (xxH)		--------- T0MD Register
;------------------------------------------------------------
;		C_TMR0_Clk		C_TMR0_LowClk	|	Timer 0 Clock Source
;------------------------------------------------------------
;		0				x				|	From Instruction Clock
;		1				0				|	From External Pin
;		1				1				|	From Low Oscillator Frequency (I_LRC )
;------------------------------------------------------------
;Bit[7:4] : Timer0 Clock Source Selection
	C_TMR0_LowClk		EQU		80H			; Same as LCKTM0
	C_EXINT_Edge		EQU		40H			; External INT Edge Select --- 1:Rising Edge, 0:Falling Edge
	C_TMR0_Clk			EQU		20H			; Same as T0CS
	C_TMR0_ExtClk_Edge	EQU		10H			; Timer0 External Clock Edge Select --- 1:Falling Edge, 0:Rising Edge

;Bit[3] : Watchdog Interrupt Source Selection / Timer0 Prescaler0 Selection
	C_PS0_WDT			EQU		08H			; Prescaler0 is assigned to WDT
	C_PS0_TMR0			EQU		00H			; Prescaler0 is assigned to TMR0
;Bit[2:0] : Prescaler0 Dividing Rate Selection
	C_PS0_Div			EQU		07H			; Prescaler0 Dividing Rate Selection
	C_PS0_Div2			EQU		00H
	C_PS0_Div4			EQU		01H
	C_PS0_Div8			EQU		02H
	C_PS0_Div16			EQU		03H
	C_PS0_Div32			EQU		04H
	C_PS0_Div64			EQU		05H
	C_PS0_Div128		EQU		06H
	C_PS0_Div256		EQU		07H

;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
; F-page Special Function Register (IO Configuration Register)
;-----------------------------------------------------------------------------------------------------------------------	

;------------------------------------------------------------	
; IOSTB (06H)	--------- PortB Direction(Input/Output) Control Register
;------------------------------------------------------------
;Bit[7:6] : Reserved
;Bit[5:0] : Port B Input/Output Mode Selection (1:Input, 0:Output)
	C_PB_Input			EQU		3FH			; Port B Input Mode Control
	C_PB_Output			EQU		00H			; Port B Output Mode Control

	C_PB5_Input			EQU		20H			; PB5 I/O mode Control bit
	C_PB4_Input			EQU		10H			; PB4 I/O mode Control bit
	C_PB3_Input			EQU		08H			; PB3 I/O mode Control bit
	C_PB2_Input			EQU		04H			; PB2 I/O mode Control bit
	C_PB1_Input			EQU		02H			; PB1 I/O mode Control bit
	C_PB0_Input			EQU		01H			; PB0 I/O mode Control bit
	C_PB5_Output		EQU		00H			; PB5 I/O mode Control bit
	C_PB4_Output		EQU		00H			; PB4 I/O mode Control bit
	C_PB3_Output		EQU		00H			; PB3 I/O mode Control bit
	C_PB2_Output		EQU		00H			; PB2 I/O mode Control bit
	C_PB1_Output		EQU		00H			; PB1 I/O mode Control bit
	C_PB0_Output		EQU		00H			; PB0 I/O mode Control bit
	
;------------------------------------------------------------	
; PS0CV (0AH)		--------- Prescaler0 Counter Value Register
;------------------------------------------------------------
;Bit[7:0] : Prescaler0 Counter Value
	C_PS0_Cnt			EQU		FFH			; Read-only	

;------------------------------------------------------------	
; B0DCON (0CH)	--------- PortB Open-Drain Control Register
;------------------------------------------------------------
;Bit[7:6]: Reserved
;Bit[5:0] : PortB Open-Drain Control (1:Open-Drain, 0:Disable)
	C_PB_OD				EQU		3FH			; Port B Open-Drain Control
	C_PB5_OD			EQU		20H			; PB5 Open-Drain Control bit
	C_PB4_OD			EQU		10H			; PB4 Open-Drain Control bit
	C_PB3_OD			EQU		08H			; PB3 Open-Drain Control bit	
	C_PB2_OD			EQU		04H			; PB2 Open-Drain Control bit
	C_PB1_OD			EQU		02H			; PB1 Open-Drain Control bit 
	C_PB0_OD			EQU		01H			; PB0 Open-Drain Control bit

;------------------------------------------------------------	
; CMPCR (0EH)	--------- Comparator voltage select Control Register
;------------------------------------------------------------
;Bit[7] : Reserved
;Bit[6] : VDD_ref bias high enable bit  (1:Enable, 0: Disable) 
	C_RBias_High_Dis 	EQU		00H
	C_RBias_High_En 	EQU		40H	
;Bit[5] : VDD_ref bias low enable bit  (1:Enable, 0: Disable) 
	C_RBias_Low_Dis 	EQU		00H
	C_RBias_Low_En 		EQU		20H
;Bit[4] : Comparator Interrupt  trigger edge control (Comparator output state need polling SFR bit "LVDOUT")
	C_CMPFINV_Dis		EQU		00H			; LVDIF=1 when Vp > Vn
	C_CMPFINV_En		EQU		10H			; LVDIF=1 when Vp < Vn	
	
;Bit[3:2] :	Non-inverting input	pad select
;Bit[1:0] :	Inverting input	pad	select

;Comparator input select
;Bit[3:0]	Non-inverting input		Inverting input
;-------------------------------------------
;0000		PB0						PB1
;0001		PB0						PB5
;0010		PB0						Bandgap
;0011		PB0						VDD_ref
;0100		PB4						PB1
;0101		PB4						PB5
;0110		PB4						Bandgap
;0111		PB4						VDD_ref
;1000		VDD_ref					PB1
;1001		VDD_ref					PB5
;1010		VDD_ref					Bandgap				(only for LVD)
;1011		NA						NA
;11XX		NA						NA

; Bandgap voltage is about 0.6V	

;------------------------------------------------------------	
; PCON1 (0FH)	--------- Power Control Register 1
;------------------------------------------------------------
;Bit[7] : All Interrupt Enable
	C_All_INT_En		EQU		80H			; Enable all unmasked interrupts use instruction "ENI"
;Bit[6] : Low voltage detector output 		( This bit can be Comparator output state when SFR bit "CMPEN=1")
	C_LVDOUT			EQU		40H			; read-only
;Bit[5:2] : Select one of the 16 LVD voltage ( Note: SFR CMPCR[7:0] must be set 00001010b )
	C_LVD_3P75V			EQU		3CH			; LVD Voltage=3.75V	
	C_LVD_3P45V			EQU		38H			; LVD Voltage=3.45V	
	C_LVD_3P2V			EQU		34H			; LVD Voltage=3.2V	
	C_LVD_4P15V			EQU		30H			; LVD Voltage=4.15V	
	C_LVD_2P6V			EQU		2CH			; LVD Voltage=2.6V
	C_LVD_4P05V			EQU		28H			; LVD Voltage=4.05V	
	C_LVD_1P95V			EQU		24H			; LVD Voltage=1.95V	
	C_LVD_3P9V			EQU		20H			; LVD Voltage=3.9V	
	C_LVD_3P6V			EQU		1CH			; LVD Voltage=3.6V	
	C_LVD_3P3V			EQU		18H			; LVD Voltage=3.3V	
	C_LVD_3P0V			EQU		14H			; LVD Voltage=3.0V
	C_LVD_2P9V			EQU		10H			; LVD Voltage=2.9V	
	C_LVD_2P8V			EQU		0CH			; LVD Voltage=2.8V
	C_LVD_2P4V			EQU		08H			; LVD Voltage=2.4V
	C_LVD_2P2V			EQU		04H			; LVD Voltage=2.2V
	C_LVD_2P0V			EQU		00H			; LVD Voltage=2.0V
;Bit[1] : Reserved	
;Bit[0] : Timer0 Enable
	C_TMR0_En			EQU		01H			; Enable Timer0
	C_TMR0_Dis			EQU		00H			; Disable Timer0
		
;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
; S-page Special Function Register (Special Function Register)
;-----------------------------------------------------------------------------------------------------------------------		
;------------------------------------------------------------
; TMR1 (00H)	--------- Timer1 Data Register
;------------------------------------------------------------
;Bit[7:0] : Timer1 Data
	C_TMR1_Data			EQU		FFH	
	
;------------------------------------------------------------	
; T1CR1 (01H)	--------- Timer1 Control Register 1
;------------------------------------------------------------
;Bit[7:6] : PWM1 Control
	C_PWM1_En			EQU		80H 		; PWM1 output will be present on PB2
	C_PWM1_Active		EQU		40H 		; PWM1 output is active
	C_PWM1_Active_Lo	EQU		40H 		; PWM1 output is active low 
	C_PWM1_Active_Hi	EQU		00H 		; PWM1 output is active high 
;Bit[5:3] : Reserved
;Bit[2:0] : Timer1 Control
	C_TMR1_OneShot		EQU		04H 		; One-Shot mode. Timer1 will count once from the initial value to 0x00
	C_TMR1_Reload		EQU		02H 		; Initial value is reloaded from reload register TMR1(T1OS=0)

	C_TMR1_En			EQU		01H 		; Enable Timer1
	C_TMR1_Dis			EQU		00H 		; Disable Timer1

;------------------------------------------------------------	
; T1CR2 (02H)	--------- Timer1 Control Register 2
;------------------------------------------------------------
;Bit[7:6] : Reserved
;Bit[5] : Timer1 Clock Source Select
	C_TMR1_ClkSrc_Ext	EQU		20H			; Timer1 clock source from External Clock Input(EX_CKI:PB2)
	C_TMR1_ClkSrc_Inst	EQU		00H			; Timer1 clock source from Internal Instruction Clock	
;Bit[4] : Timer1 external clock edge selection
    C_TMR1_ExtClk_Edge	EQU		10H			; Timer1 External Clock Edge Select --- 1:Falling Edge, 0:Rising Edge  
	C_TMR1_ExtFalling	EQU		10H			; Timer1 will decrease one while EX_CKI Falling Edge.
	C_TMR1_ExtRising	EQU		00H			; Timer1 will decrease one while EX_CKI Rising Edge.
;Bit[3] :  Disable/enable Prescaler1
    C_PS1_Dis           EQU		08H			; Disable Prescaler1
	C_PS1_EN			EQU		00H			; Enable Prescaler1
;Bit[2:0] : Prescaler 1 Dividing Rate Selection
	C_PS1_Div			EQU		07H			; Prescaler1 Dividing Rate Selection
	C_PS1_Div2			EQU		00H
	C_PS1_Div4			EQU		01H
	C_PS1_Div8			EQU		02H
	C_PS1_Div16			EQU		03H
	C_PS1_Div32			EQU		04H
	C_PS1_Div64			EQU		05H
	C_PS1_Div128		EQU		06H
	C_PS1_Div256		EQU		07H

;------------------------------------------------------------	
; PWM1DUTY (03H)	--------- PWM1 Duty Register
;------------------------------------------------------------
;Bit[7:0] : PWM1 Duty Value
	C_PWM1_Duty			EQU		FFH

;------------------------------------------------------------	
; PS1CV (04H)		--------- Prescaler1 Counter Value Register
;------------------------------------------------------------
;Bit[7:0] : Prescaler1 Counter Value
	C_PS1_Cnt			EQU		FFH			; Read-only

;------------------------------------------------------------	
; BZ1CR (05H)		--------- Buzzer1 Control Register
;------------------------------------------------------------
;Bit[7] : BZ1 Enable
	C_BZ1_En			EQU		80H			; Enable BZ1 output(PB2)
;Bit[6:4] : Reserved
;Bit[3:0] : BZ1 Frequency Selection
	C_BZ1_FSel			EQU		0FH			; BZ1 frequency selection

	C_BZ1_PS1Div2		EQU		00H			; Clock Soruce from Prescaler 1
	C_BZ1_PS1Div4		EQU		01H
	C_BZ1_PS1Div8		EQU		02H
	C_BZ1_PS1Div16		EQU		03H
	C_BZ1_PS1Div32		EQU		04H
	C_BZ1_PS1Div64		EQU		05H
	C_BZ1_PS1Div128		EQU		06H
	C_BZ1_PS1Div256		EQU		07H

	C_BZ1_TMR1B0		EQU		08H			; Clock Source from Timer 1
	C_BZ1_TMR1B1		EQU		09H
	C_BZ1_TMR1B2		EQU		0AH
	C_BZ1_TMR1B3		EQU		0BH
	C_BZ1_TMR1B4		EQU		0CH
	C_BZ1_TMR1B5		EQU		0DH
	C_BZ1_TMR1B6		EQU		0EH
	C_BZ1_TMR1B7		EQU		0FH

;------------------------------------------------------------	
; IRCR (06H)		--------- IR Control Register
;------------------------------------------------------------
;Bit[7:3] : Reserved
;Bit[2] : IR Polarity Selection
	C_IR_Pol_Sel		EQU		04H
;Bit[1] : IR Carrier Frequency Selection (1:57KHz, 0:38KHz)
	C_IR_57K			EQU		02H			; IRCR[1]=1 , IR carrier frequency is 57KHz
	C_IR_38K			EQU		00H			; IRCR[1]=0 , IR carrier frequency is 38KHz
;Bit[0] : IR Enable (PB1/PA3)
	C_IR_En				EQU		01H			; Enable IR carrier output

;------------------------------------------------------------	
; TBHP (07H)	--------- Table Access High Byte Address Pointer Register
;------------------------------------------------------------
;Bit[7:2] : Reserved
;Bit[1:0] : Table Access High Byte Address Pointer
	C_TbHigh_Addr		EQU		03H			; When instruction CALLA, GOTOA or TABLEA is executed TBHP[1:0] is PC[9:8]

;------------------------------------------------------------	
; TBHD (08H)	--------- Table Access High Byte Data Register
;------------------------------------------------------------
;Bit[7:6] : Reserved
;Bit[5:0] : Table Access High Byte Data
	C_TbHigh_Data		EQU		3FH


;------------------------------------------------------------   
; OSCCR (0FH)	--------- Oscillation Control Register (Include Switch Working Mode)
;------------------------------------------------------------
;Bit[7] : Reserved
;Bit[6] : Disable/enable comparator output
	C_CMPO_Dis		EQU		00H			; Disable comparator output to pad PB2
	C_CMPO_En		EQU		40H			; Enable comparator output to pad PB2
;Bit[5:4] : Reserved	
;Bit[3:2] : System Mode Select
	C_Mode				EQU		0CH			; System Operating Mode Selection
	C_Normal_Mode		EQU		00H			; Enter Normal mode
	C_Halt_Mode			EQU		04H			; Enter Halt mode
	C_Standby_Mode		EQU		08H			; Enter Standby mode
;Bit[1] : Stop FHOSC
	C_FHOSC_Stop		EQU		02H			; Disable high-frequency oscillation (FHOSC)
;Bit[0] : FOSC Seletction
	C_FHOSC_Sel			EQU		01H			; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
	C_FLOSC_Sel			EQU		00H			; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)	


;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
;General Constant Define
;-----------------------------------------------------------------------------------------------------------------------
	C_SaveToAcc			EQU		00H	
	C_SaveToReg			EQU		01H	

	C_Bit0				EQU		01H
	C_Bit1				EQU		02H
	C_Bit2				EQU		04H
	C_Bit3				EQU		08H
	C_Bit4				EQU		10H
	C_Bit5				EQU		20H
	C_Bit6				EQU		40H
	C_Bit7				EQU		80H

	C_Num0				EQU		0
	C_Num1				EQU		1
	C_Num2				EQU		2
	C_Num3				EQU		3
	C_Num4				EQU		4
	C_Num5				EQU		5
	C_Num6				EQU		6
	C_Num7				EQU		7