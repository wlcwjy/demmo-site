﻿; =========================================================================      
; Project:       
; File:          main.asm
; Description:   
;                 
; Author:        
; Version:       
; Date:         
; =========================================================================
;--------------- File Include ---------------------------------------------
;--------------------------------------------------------------------------
#include		NY8A051H.H						; The Header File for NY8A053E
;--------------- Variable Definition --------------------------------------
;--------------------------------------------------------------------------
;		R_Temp		EQU		0x10			; Example
V_BUTTON_IN_DELAY			EQU		0x10
V_SYSTEM_STATUS				EQU		0x11  
V_BUTTON_DELAY				EQU		0x12
V_DELAY_COUNT1				EQU		0x13    
V_DELAY_COUNT2				EQU		0x14   
V_BREATE_L1					EQU		0x15    
V_BREATE_L2					EQU		0x16  
V_BREATE_COUNT				EQU		0x17  
V_BREATE_DELAY				EQU		0x18  
V_BREATE_UP_TIME			EQU		0x19  
V_BREATE_DOWN_TIME			EQU		0x1A  
V_BREATE_AL1				EQU		0x1B    
V_PORTB						EQU		0x1C 
V_LED_MODE_ALL_TIME 		EQU		0x1D
V_LED_MODE_NUMBER			EQU		0x1E
V_LOOP_COUNT				EQU		0x1F

V_DELAY_T0_COUNT			EQU		0x20  
V_DELAY_T0_NMS				EQU		0x21 
V_DELAY_T0_TEMP				EQU		0x22
V_DELAY_T0_15MS				EQU		0x23 
V_DELAY_T0_30MS				EQU		0x24 
V_DELAY_T0_55MS				EQU		0x26 
V_DELAY_T0_60MS				EQU		0x27 
V_DELAY_T0_5MS				EQU		0x28
V_DELAY_T0_25MS				EQU		0x29 
V_DELAY_T0_40MS				EQU		0x2A 

V_I							EQU		0x30 
V_WAIT_RELEASE_COUNT		EQU		0x31 
V_HALF_PERIOD				EQU		0x33
V_ACC						EQU		0x34
V_STATUS					EQU		0x35
V_LED_MODE_RUN_LOOP			EQU		0x36
;--------------- Constant Definition --------------------------------------
;--------------------------------------------------------------------------
;		C_Temp		EQU		0xFF			; Example
C_OSH_PIN					EQU 	3
C_BUTTON_PIN				EQU 	4

C_LED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_IS_BUTTON_CHECK	EQU		1  
C_STATUS_LED_MODE			EQU		2  

C_BUTTON_SHORT_DELAY		EQU		2
C_BREATE_PERIOD				EQU		17
C_LED_RUN_TIME      		EQU		16
C_MODE1_BREATE_PERIOD		EQU		40

;--------------- Vector Definition ----------------------------------------
;--------------------------------------------------------------------------
		ORG		0x000		
		LGOTO	V_Main                
		
		ORG		0x008
		LGOTO	V_INT
		
;--------------- Code Start -----------------------------------------------
;--------------------------------------------------------------------------
        ORG		0x010         
V_Main:
; Initial GPIO  
    
		; PORTB I/O state
		; PB3 ~ PB2 set input mode and enable pull-low resistor
		; PB1 ~ PB0 set open-drain output mode                  
		MOVIA   0
		IOST    BODCON								; Enable Open-Drain of PB1 & PB0 ,others disable 
		
        MOVIA   11111111B 
	    MOVAR   BPLCON								; Enable PB2 Pull-High Resistor,others disable
		
		MOVIA   11100111B 
	    MOVAR   BPHCON								; Enable PB1,PB3,PB4,PB5 Pull-High Resistor,others disable						 
		
		MOVIA   11011000B
		IOST    IOSTB								; 1 Input,0 Output
		
		MOVIA   11111111B
		MOVAR   PORTB								; PB1 & PB0 output high
		
		MOVIA   0									;Enable PB INT
		SFUN	T1CR2
		MOVIA   0
		SFUN    T1CR1
		MOVIA   0xFF
		SFUN    TMR1
		
		LCALL 	TIMER_CALIBRATION
		
		CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK
		CLRR	V_BUTTON_IN_DELAY
F_MAIN_LOOP:                                    
        CLRWDT										; Clear WatchDog
		
		LCALL 	F_SYSTEM_SLEEP
		
		LCALL	LED_MODE0
		
		LGOTO   F_MAIN_LOOP
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- DELAY_MS_HCLK ----------------------------------
DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
DELAY_MS_HCLK_LOOP2:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		GOTO	DELAY_MS_HCLK_LOOP2
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		GOTO	DELAY_MS_HCLK
		RET       	
;---------------------------- T0_DELAY ----------------------------------
T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
T0_DELAY_LOOP:
		CLRWDT
		CMPAR	TMR0
		BTRSC	STATUS,C_Status_C_Bit
		GOTO	T0_DELAY_LOOP
		RET
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
LED_SWITCH_OFF:	
        MOVIA   11
        MOVAR   V_LOOP_COUNT
LED_SWITCH_OFF_LOOP:
		LCALL 	F_LED1_ON
		LCALL 	F_LED2_ON
		LCALL 	F_LED3_ON
		LCALL 	F_LED4_ON
		LCALL 	F_LED5_ON
		LCALL 	F_LED6_ON
	
        DECRSZ  V_LOOP_COUNT,C_SaveToReg
		LGOTO	LED_SWITCH_OFF_LOOP
		
        LCALL 	F_LED_ALL_OFF
		RET 	
;---------------------------- LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
LED_SWITCH_ON:
		LCALL 	LED_SWITCH_OFF
		
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
	
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	

        MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY

        MOVR	V_DELAY_T0_15MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY	
      	
		LCALL 	LED_SWITCH_OFF
		RET 		
;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
TIMER_CALIBRATION:
		DISI
		; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        SFUN    OSCCR                        		; OSCCR: Oscillation Control Register 
        NOP
	 	NOP
        
		MOVIA	10100011B
		T0MD 
        MOVIA	0
        MOVAR	TMR0
		
;   		BCR   	PORTB,5	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	DELAY_MS_HCLK
;        BSR   	PORTB,5

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_5MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_5MS,C_SaveToReg
		
		MOVAR	V_DELAY_T0_COUNT
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_15MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
		MOVAR	V_DELAY_T0_TEMP
       	SUBAR	V_DELAY_T0_15MS,C_SaveToReg
       	
       	MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_30MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_30MS,C_SaveToReg

        MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
        ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_40MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_40MS,C_SaveToReg
      
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
       	MOVAR  	V_DELAY_T0_55MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_55MS,C_SaveToReg
       	
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_60MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_60MS,C_SaveToReg
        ENI
		
		RET			
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
F_SYSTEM_SLEEP:
		MOVIA   C_LED_ALL_OFF
		MOVAR   PORTB								;PORTB output high
		BTRSS	PORTB,C_BUTTON_PIN	
		LGOTO	SUB_WAIT_BUTTON_RELEASE
		
		
		BTRSS	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	NO_BUTTON0
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	BUTTON_SET_POWER_OFF0
BUTTON_SET_POWER_ON0:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_ON
		CLRR	V_LED_MODE_NUMBER
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO 	F_SYSTEM_SLEEP
BUTTON_SET_POWER_OFF0:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	LED_SWITCH_OFF
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO 	F_SYSTEM_SLEEP
NO_BUTTON0:
		BTRSS	PORTB,C_OSH_PIN						;Wait OSH PIN to be 1
		LGOTO 	F_SYSTEM_SLEEP		
	
ENTRY_SLEEP:
		LCALL 	TIMER_CALIBRATION
		
        MOVIA   11011000B
		IOST    IOSTB		
		MOVIA   11111111B
		MOVAR	PORTB								; Clear all interrupt flags
	
		MOVIA   0
		MOVAR	INTF	
		MOVAR	PCON
		MOVAR	BWUCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON		;if is power on enable PB0 wakeup
		BSR		BWUCON,C_OSH_PIN
		BSR		BWUCON,C_BUTTON_PIN 				
			
		MOVIA   0
		SFUN    T1CR1
		MOVIA   00000010B							;Enable PB INT
		MOVAR	INTE
	   	ENI											;Enable INT 	
		MOVR	PORTB,C_SaveToAcc
		MOVAR	V_PORTB
	 	SLEEP
	 	NOP
	 	NOP
		MOVR	PORTB,C_SaveToAcc
		XORAR	V_PORTB,C_SaveToReg
	 	
		MOVIA   10001000B
		MOVAR	PCON
		
		;MOVIA	10100011B
		;T0MD 
       
		DISI;
		; Normal mode into Slow mode
        MOVIA   C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        SFUN    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
	 	NOP
		
		MOVIA   00000011B
		SFUN    T1CR1
		
		MOVIA   00001000B							;Enable PB INT
		MOVAR	INTE
	   	ENI		
	 	
		BTRSC 	PORTB,C_BUTTON_PIN
		LGOTO	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP
		
SUB_WAIT_BUTTON_RELEASE:
		BTRSS	PORTB,C_OSH_PIN
		LGOTO	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP
		CLRWDT
		BTRSS	PORTB,C_BUTTON_PIN	
		LGOTO	SUB_WAIT_BUTTON_RELEASE
		MOVR    V_BUTTON_IN_DELAY,C_SaveToAcc       	; 把 V_COUNT 读进 ACC
        BTRSS   STATUS,C_Status_Z_Bit            			 	; 若 ACC!=0，则继续循环
        LGOTO	SUB_WAIT_BUTTON_RELEASE                				; ACC!=0 时执行这里
        LGOTO	F_SYSTEM_SLEEP
		
SUB_SYSTEM_SLEEP_WAIT_OSH_STOP:
		CLRWDT
		BTRSS 	PORTB,C_OSH_PIN		;if is power on enable PB0 wakeup
		LGOTO 	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP	
		BTRSS	PORTB,C_BUTTON_PIN
		RET
		BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		LGOTO	F_SYSTEM_SLEEP
	
		RET

;;----------------------------- LED1 ON----------------------------------   
F_LED1_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111001B
		IOST    IOSTB								
		MOVIA	11111101B
		MOVAR	PORTB
		RET

;;----------------------------- LED2 ON----------------------------------   
F_LED2_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111001B
		IOST    IOSTB								
		MOVIA	11111011B
		MOVAR	PORTB
		RET

;;----------------------------- LED3 ON----------------------------------   
F_LED3_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111100B
		IOST    IOSTB								
		MOVIA	11111110B
		MOVAR	PORTB
		RET

;;----------------------------- LED4 ON----------------------------------   
F_LED4_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111100B
		IOST    IOSTB								
		MOVIA	11111101B
		MOVAR	PORTB
		RET

;;----------------------------- LED5 ON----------------------------------
F_LED5_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111010B
		IOST    IOSTB								
		MOVIA	11111110B
		MOVAR	PORTB
		RET

;;----------------------------- LED6 ON----------------------------------
F_LED6_ON:
        ; MOVIA	11111111B
		; MOVAR	PORTB
		MOVIA   11111010B
		IOST    IOSTB								
		MOVIA	11111011B
		MOVAR	PORTB
		RET

F_LED_ALL_OFF:
        MOVIA	11111111B
		MOVAR	PORTB
		MOVIA   11111000B
		IOST    IOSTB								
		RET

;---------------------------- LED_MODE0_LED6_LED1--------------------------------
;--------------------------------------------------------------------------------  
LED_MODE0_LED6_LED1:
        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED6_LOOP:
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED6_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED6_LED5_LOOP:
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED6_LED5_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED6_LED5_LED4_LOOP:
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED6_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED6_LED5_LED4_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED5_LED4_LED3_LOOP:
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED5_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED5_LED4_LED3_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED4_LED3_LED2_LOOP:
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED4_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED4_LED3_LED2_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED3_LED2_LED1_LOOP:
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED3_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED3_LED2_LED1_LOOP
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
        
        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED2_LED1_LOOP:
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED2_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED2_LED1_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED1_LOOP:
        LCALL   F_LED1_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED1_LOOP

        RET
;---------------------------- LED_MODE0_LED1_LED6--------------------------------
;--------------------------------------------------------------------------------  
LED_MODE0_LED1_LED6:

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED1UP_LOOP:
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED1UP_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
        RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED1_LED2_LOOP:
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED1_ON
        LCALL   F_LED1_ON
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED1_LED2_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED1_LED2_LED3_LOOP:
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED2_ON
        LCALL   F_LED2_ON
        LCALL   F_LED1_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED1_LED2_LED3_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED2_LED3_LED4_LOOP:
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED3_ON
        LCALL   F_LED3_ON
        LCALL   F_LED2_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED2_LED3_LED4_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED3_LED4_LED5_LOOP:
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED4_ON
        LCALL   F_LED4_ON
        LCALL   F_LED3_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED3_LED4_LED5_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED4_LED5_LED6_LOOP:
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED5_ON
        LCALL   F_LED5_ON
        LCALL   F_LED4_ON
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED4_LED5_LED6_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED5_LED6_LOOP:
        LCALL   F_LED6_ON
        LCALL   F_LED6_ON
        LCALL   F_LED5_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED5_LED6_LOOP

        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET

        MOVIA   C_LED_RUN_TIME
        MOVAR   V_LOOP_COUNT
LED_MODE0_LED6UP_LOOP:
        LCALL   F_LED6_ON
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        LCALL   F_LED_ALL_OFF
        DECRSZ 	V_LOOP_COUNT,C_SaveToReg
		LGOTO   LED_MODE0_LED6UP_LOOP

        RET
;---------------------------- LED_MODE0--------------------------------
;--------------------------------------------------------------------------  
LED_MODE0:
        LCALL   LED_MODE0_LED6_LED1
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
        MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        LCALL   LED_MODE0_LED1_LED6
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
        LCALL   LED_MODE0_LED6_LED1
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
        MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
		MOVR	V_DELAY_T0_40MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	T0_DELAY
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 

        LCALL   LED_MODE0_LED1_LED6
        BTRSC	V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK				;if(BUTTON_IN!=0) return NO;
		RET 
        LCALL   LED_MODE0_LED6_LED1
		RET
;----------------------- FINT_BUTTON_CHECK --------------------------------
;--------------------------------------------------------------------------		
F_INT_BUTTON_CHECK:
		BTRSC	PORTB,C_BUTTON_PIN					;if(BUTTON_IN!=0) return NO;
		LGOTO   SUB_INT_NO_BUTTON
		
		INCR    V_BUTTON_IN_DELAY,C_SaveToReg
		MOVIA   00011111B
		ANDAR   V_BUTTON_IN_DELAY,C_SaveToReg
		RET
SUB_INT_NO_BUTTON:
		MOVIA	C_BUTTON_SHORT_DELAY
        BCR     STATUS,C_Status_C_bit    			; Clear Zero bit of Status Register
		CMPAR   V_BUTTON_IN_DELAY                    
		BTRSC	STATUS,C_Status_C_bit    			; If V_BUTTON_IN_DELAY>C_BUTTON_SHORT_DELAY , then C bit=1
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_BUTTON_CHECK 
		CLRR	V_BUTTON_IN_DELAY
		RET
;--------------- Interrupt Service Routine --------------------------------
;--------------------------------------------------------------------------
V_INT:
		MOVAR	V_ACC							; Store ACC value                  
		SWAPR	V_ACC,C_SaveToReg
		MOVR	STATUS,C_SaveToAcc
		MOVAR	V_STATUS						; Stor
		
		BTRSS	INTF,C_INT_TMR1_Bit 			; If PBIF is 1, then skip next instruction  
		LGOTO	SUB_INT_EXIT  
		
        CLRWDT
		LCALL   F_INT_BUTTON_CHECK
	
SUB_INT_EXIT:		
		CLRR	INTF							; Clear all interrupt flags	
		
		MOVR	V_STATUS,C_SaveToAcc
		MOVAR	STATUS  
		SWAPR	V_ACC,C_SaveToAcc		
		RETIE		

end		; End of Code
		