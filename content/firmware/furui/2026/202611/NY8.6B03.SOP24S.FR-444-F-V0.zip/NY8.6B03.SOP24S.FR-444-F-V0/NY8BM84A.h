﻿IFNDEF NY8BM84A_HEADER_FILE
#define NY8BM84A_HEADER_FILE
;=======================================================================================================================
;=======================================================================================================================
;File:			NY8BM84A.h
;Description:	The Header File for NY8BM84A
;Author:		laurent
;Date:			2024/11/22
;=======================================================================================================================
;=======================================================================================================================
;-----------------------------------------------------------------------------------------------------------------------
;-----------------------------------------------------------------------------------------------------------------------
;-----------------------------------------------------------------------------------------------------------------------	
; Bank 0 Special Function Register
;-----------------------------------------------------------------------------------------------------------------------
; SFR_Name					Address	;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-----------------------------------------------------------------------------------------------------------------------	
; 0x00 --------- Indirect Addressing Register
#define INDF				0x00	;	INDF[7]		INDF[6]		INDF[5]		INDF[4]		INDF[3]		INDF[2]		INDF[1]		INDF[0]
#define P_INDF				0x00
; 0x01 --------- Timer0 Data Register	
#define TMR0				0x01	;	TMR0_DATA7	TMR0_DATA6	TMR0_DATA5	TMR0_DATA4	TMR0_DATA3	TMR0_DATA2	TMR0_DATA1	TMR0_DATA0
#define P_TMR0				0x01
; 0x02 --------- Low Byte of Program Counter
#define PCL					0x02	;	PCL[7]		PCL[6]		PCL[5]		PCL[4]		PCL[3]		PCL[2]		PCL[1]		PCL[0]
#define P_PCL					0x02
; 0x03 --------- Status Register
#define STATUS				0x03 	;	IRP			BK[1]		BK[0]		/TO			/PD			Z			DC			C	
#define P_STATUS			0x03
; 0x04 --------- File Selection Register (Include SRAM Bank Select)
#define FSR					0x04	;	GP[7]		FSR[6]		FSR[5]		FSR[4]		FSR[3]		FSR[2]		FSR[1]		FSR[0]	 
#define P_FSR				0x04
; 0x05 --------- PortA Data Register
#define PORTA				0x05	;	PA[7]		PA[6]		PA[5]		PA[4]		PA[3]		PA[2]		PA[1]		PA[0]
#define P_PORTA				0x05
; 0x06 --------- PortB Data Register
#define PORTB				0x06	;	PB[7]		PB[6]		PB[5]		PB[4]		PB[3]		PB[2]		PB[1]		PB[0]	
#define P_PORTB				0x06
; 0x07 --------- PortC Data Register
#define PORTC				0x07	;	-			-			PC[5]		PC[4]		PC[3]		PC[2]		PC[1]		PC[0]
#define P_PORTC				0x07
; 0x08 --------- Reserved
; 0x09 --------- Oscillation Control Register (Include Switch Working Mode)
#define OSCCR				0x09	;	-			-			-			XTL_BKUP	Mode[1]		Mode[0]		HOSC_Stop	HOSC_Sel
#define P_OSCCR				0x09
; 0x0A --------- High Byte of Program Counter (B'xxxxxDDD')
#define PCHBUF				0x0A 	;	-			-			-			-			PCHBUF[3]	PCHBUF[2]	PCHBUF[1]	PCHBUF[0]
#define P_PCHBUF			0x0A
; 0x0B --------- Interrupt Control Register
#define INTCON				0x0B 	;	GIE			PEIE		T0IE		INT0IE		PABCIE		T0IF		INT0IF		PABCIF
#define P_INTCON			0x0B
; 0x0C --------- Interrupt Flag Register 1
#define PIR1				0x0C	;	INT2IF		INT1IF		WDTIF		-			-			T5IF/CCPIF	T4IF		T1IF
#define P_PIR1				0x0C
; 0x0D --------- Interrupt Flag Register 2
#define PIR2				0x0D	;	ADIF		LVDIF		CMPIF		-			SIMIF		LSRIF		TXIF		RXIF
#define P_PIR2				0x0D
; 0x0E --------- Reserved
; 0x0F --------- Timer low byte Register
#define TMRxL 				0x0F	;	TMRx[7]		TMRx[6]		TMRx[5]		TMRx[4]		TMRx[3]		TMRx[2]		TMRx[1]		TMRx[0]
#define P_TMRxL 			0x0F
; 0x10 --------- Timer low byte Register
#define TMRxH 				0x10	;	-			-			-			-			-			-			TMRx[9]		TMRx[8]
#define P_TMRxH 			0x10
; 0x11 --------- Timex Control Register 1
#define TxCR1				0x11	;	-			-			TMxOE		-			-			OneShot		Reload		TxEn	
#define P_TxCR1				0x11
; 0x12 --------- Timex Control Register 2
#define TxCR2				0x12	;	-			-			ClkSel		EdgeSel		/PSxEn		PSxDiv[2]	PSxDiv[1]	PSxDiv[0]
#define P_TxCR2				0x12
; 0x13 --------- Buzzer1 Control Register
#define BZ1CR				0x13	;	BZ1En		-			-			-			FSel[3]		FSel[2]		FSel[1]		FSel[0]	
#define P_BZ1CR				0x13
; 0x14 --------- PortA Wakeup Control Register
#define AWUCON				0x14	;	WUPA[7]		WUPA[6]		WUPA[5]		WUPA[4]		WUPA[3]		WUPA[2]		WUPA[1]		WUPA[0]
#define P_AWUCON			0x14
; 0x15 --------- PortB/C/D Wakeup Control Register
#define BCDWUCON			0x15 	;	WUPBCD[7]	WUPBCD[6]	WUPBCD[5]	WUPBCD[4]	WUPBCD[3]	WUPBCD[2]	WUPBCD[1]	WUPBCD[0]
#define P_BCDWUCON			0x15
; 0x16 --------- Port attribute Control Register
#define PORTACON30			0x16	;	PA3CON1		PA3CON0		PA2CON1		PA2CON0		PA1CON1		PA1CON0		PA0CON1		PA0CON0
#define P_PORTACON30		0x16
; 0x17 --------- Port attribute Control Register
#define PORTACON74			0x17	;	PA7CON1		PA7CON0		PA6CON1		PA6CON0		PA5CON1		PA5CON0		PA4CON1		PA4CON0
#define P_PORTACON74		0x17
; 0x18 --------- Port attribute Control Register
#define PORTBCON30			0x18
#define P_PORTBCON30		0x18
; 0x19 --------- Port attribute Control Register
#define PORTBCON74			0x19
#define P_PORTBCON74		0x19
; 0x1A --------- Port attribute Control Register
#define PORTCCON30			0x1A
#define P_PORTCCON30		0x1A
; 0x1B --------- Port attribute Control Register
#define PORTCCON74			0x1B
#define P_PORTCCON74		0x1B
; 0x1C --------- Reserved
; 0x1D --------- Select Control Register(for Timer PWM)
#define SELCON 				0x1D	;	CCPSEL		-			-			BCDWUSEL1	BCDWUSEL0	TPSEL2		TPSEL1		TPSEL0
#define P_SELCON 			0x1D
; 0x1E --------- Reserved
; 0x1F --------- PWM Control Register
#define PWMxCON 			0x1F	;	-			-			-			-			-			-			PWMxEn		PWMxActB
#define P_PWMxCON 			0x1F
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 1 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
; SFR_Name					Address	;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-------------------------------------------------------------------------------------------------------------------------------------
; 0x80 --------- INDF
; 0x81 --------- Timer0 Control Register
#define T0MD				0x81	;	LCKTM0		T0EN		T0CS		T0CE		PS0WDT		PS0SEL2		PS0SEL1		PS0SEL0
#define P_T0MD				0x81
; 0x82 --------- PCL
; 0x83 --------- STATUS
; 0x84 --------- FSR
; 0x85 --------- PortA I/O Control Register
#define IOSTA				0x85	;	PA[7]		PA[6]		PA[5]		PA[4]		PA[3]		PA[2]		PA[1]		PA[0]
#define P_IOSTA				0x85
; 0x86 --------- PortB I/O Control Register
#define IOSTB				0x86	;	PB[7]		PB[6]		PB[5]		PB[4]		PB[3]		PB[2]		PB[1]		PB[0]
#define P_IOSTB				0x86
; 0x87 --------- PortC I/O Control Register
#define IOSTC				0x87	;	-			-			PC[5]		PC[4]		PC[3]		PC[2]		PC[1]		PC[0]
#define P_IOSTC				0x87
; 0x88 --------- Reserved
; 0x89 --------- LVD Control Register
#define LVDCON				0x89	;	-			LVDOUT		-			-			LVDS3		LVDS2		LVDS1		LVDS0
#define P_LVDCON			0x89
; 0x8A --------- PCBUFH
; 0x8B --------- INTCON
; 0x8C --------- Interrupt Enable Register
#define PIE1				0x8C	;	INT2IE		INT1IE		WDTIE		-			-			T5IE/CCPIE	T4IE		T1IE
#define P_PIE1				0x8C
; 0x8D --------- Interrupt Enable Register 2
#define PIE2				0x8D	;	ADIE		LVDIE		CMPIE		-			SIMIE		LSRIE		TXIE		RXIE
#define P_PIE2				0x8D
; 0x8E --------- Reserved
; 0x8F --------- Power Control Regsiter
#define PCON				0x8F	;	WDTEN		-			LVDEN		-			LVREN		-			-			-
#define P_PCON				0x8F
; 0x90 --------- IR Control Register
#define IRCR				0x90	;	IROSC358M	-			-			-			-			IRCSEL		IRF57K		IREN
#define P_IRCR				0x90
; 0x91 --------- PWM1 Duty Register
#define PWM1DUTY			0x91	;	PWM1_DUTY7	PWM1_DUTY6	PWM1_DUTY5	PWM1_DUTY4	PWM1_DUTY3	PWM1_DUTY2	PWM1_DUTY1	PWM1_DUTY0
#define PWM1DUTYL			0x91
#define P_PWM1DUTY			0x91
#define P_PWM1DUTYL			0x91
; 0x92 --------- PWM1 Duty Register
#define PWM1DUTYH			0x92	;	-			-			-			-			-			-			PWM1_DUTY9	PWM1_DUTY8
#define P_PWM1DUTYH			0x92
; 0x93 --------- PWM2 Duty Register
#define PWM2DUTY			0x93	;	PWM2_DUTY7	PWM2_DUTY6	PWM2_DUTY5	PWM2_DUTY4	PWM2_DUTY3	PWM2_DUTY2	PWM2_DUTY1	PWM2_DUTY0
#define PWM2DUTYL			0x93
#define P_PWM2DUTY			0x93
#define P_PWM2DUTYL			0x93
; 0x94 --------- PWM2 Duty Register
#define PWM2DUTYH			0x94	;	-			-			-			-			-			-			PWM2_DUTY9	PWM2_DUTY8
#define P_PWM2DUTYH			0x94
; 0x95 --------- PWM3 Duty Register
#define PWM3DUTY			0x95	;	PWM3_DUTY7	PWM3_DUTY6	PWM3_DUTY5	PWM3_DUTY4	PWM3_DUTY3	PWM3_DUTY2	PWM3_DUTY1	PWM3_DUTY0
#define PWM3DUTYL			0x95
#define P_PWM3DUTY			0x95
#define P_PWM3DUTYL			0x95
; 0x96 --------- PWM3 Duty Register
#define PWM3DUTYH			0x96	;	-			-			-			-			-			-			PWM3_DUTY9	PWM3_DUTY8
#define P_PWM3DUTYH			0x96
; 0x97 --------- PWM4 Duty Register
#define PWM4DUTY			0x97	;	PWM4_DUTY7	PWM4_DUTY6	PWM4_DUTY5	PWM4_DUTY4	PWM4_DUTY3	PWM4_DUTY2	PWM4_DUTY1	PWM4_DUTY0
#define PWM4DUTYL			0x97
#define P_PWM4DUTY			0x97
#define P_PWM4DUTYL			0x97
; 0x98 --------- PWM4 Duty Register
#define PWM4DUTYH			0x98	;	-			-			-			-			-			-			PWM4_DUTY9	PWM4_DUTY8
#define P_PWM4DUTYH			0x98
; 0x99 --------- PWM5 Duty Register
#define PWM5DUTY			0x99	;	PWM5_DUTY7	PWM5_DUTY6	PWM5_DUTY5	PWM5_DUTY4	PWM5_DUTY3	PWM5_DUTY2	PWM5_DUTY1	PWM5_DUTY0
#define PWM5DUTYL			0x99
#define P_PWM5DUTY			0x99
#define P_PWM5DUTYL			0x99
; 0x9A --------- PWM5 Duty Register
#define PWM5DUTYH			0x9A	;	-			-			-			-			-			-			PWM5_DUTY9	PWM5_DUTY8
#define P_PWM5DUTYH			0x9A
; 0x9B --------- Interrupt Edge Register
#define INTEDG				0x9B	;	INT2DEG		EIS2		EIS1		EIS0		INT1G1		INT1G0		INT0G1		INT0G0
#define P_INTEDG			0x9B
; 0x9C --------- Comparator Control Register
#define CMPCON				0x9C	;	CMPEN		BIASEN		-			-			-			-			CMPOUT		CMPOE
#define P_CMPCON			0x9C
; 0x9D --------- Comparator voltage select Control Register
#define CMPCR				0x9D	;	-			RBIAS_H		RBIAS_L		CMP_INV		PS1			PS0			NS1			NS0
#define P_CMPCR				0x9D
; 0x9E --------- Table Access High Byte Address Pointer Register
#define TBHP				0x9E	;	-			-			-			TBHP4		TBHP3		TBHP2		TBHP1		TBHP0
#define P_TBHP				0x9E
; 0x9F --------- Table Access High Byte Data Register
#define TBHD				0x9F	;	TBHD7		TBHD6		TBHD5		TBHD4		TBHD3		TBHD2		TBHD1		TBHD0
#define P_TBHD				0x9F
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 2 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
; SFR_Name					Address	;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-------------------------------------------------------------------------------------------------------------------------------------
; 0x100 ~ 0x108 --------- INDF~PORTC
; 0x109 --------- ADC mode Register
#define ADMD				0x109	;	ADEN		START		GCHS		CHS4		CHS3		CHS2		CHS1		CHS0
#define P_ADMD				0x109
; 0x10A --------- PCBUFH
; 0x10B --------- INTCON
; 0x10C --------- ADC Low Byte Conversion Result Register
#define ADDL				0x10C	;	ADDL7		ADDL6		ADDL5		ADDL4		ADDL3		ADDL2		ADDL1		ADDL0
#define P_ADDL				0x10C
; 0x10D --------- ADC High Byte Conversion Result Register
#define ADDH				0x10D	;	ADDH7		ADDH6		ADDH5		ADDH4		ADDH3		ADDH2		ADDH1		ADDH0
#define P_ADDH				0x10D
; 0x10E --------- ADC Control Register 1
#define ADCON1 				0x10E	;	EVHENB		-			EOC			ADFM		ADCK1		ADCK0		VHS1		VHS0
#define P_ADCON1 			0x10E
; 0x10F --------- ADC Analog Pin Register
#define ADJMD 				0x10F	;	-			-			ADJ_SIGN	ADJ4		ADJ3		ADJ2		ADJ1		ADJ0
#define P_ADJMD 			0x10F
; 0x110 --------- Port Analog Pin Control Register
#define PxCON 				0x110	;	PxCON7		PxCON6		PxCON5		PxCON4		PxCON3		PxCON2		PxCON1		PxCON0
#define P_PxCON 			0x110
; 0x111 --------- Sampling pulse and ADC bit Register
#define ADCR  				0x111	;	PxSEL1		PxSEL0		-			-			SHCK1		SHCK0		ADCR1		ADCR0
#define P_ADCR  			0x111
; 0x112 --------- Serial Interface Mode Data Register(IIC and SPI)
#define SIMDR  				0x112	;	SIMD7 		SIMD6		SIMD5		SIMD4		SIMD3		SIMD2		SIMD1		SIMD0
#define P_SIMDR  			0x112
; 0x113 --------- Serial Interface Mode Control Register(IIC and SPI)
#define SIMCR  				0x113	;	SIMC1(SPI)	SIMC0(IIC)	MSTA		SSB_PAD		RX_PADEN	TX_PADEN	RCLK_PADEN	UREN
#define P_SIMCR  			0x113
; 0x114 --------- SPI Mode Control Register
#define SPCR  				0x114	;	 SPIF 		WCOL 		-			MODF		CPOL		CKEG		SPR1		SPR0
#define P_SPCR  			0x114
; 0x115 --------- IIC Mode Address Register
#define MADR   				0x115	;	MAD7		MAD6		MAD5		MAD4	 	MAD3		MAD2		MAD1		 -
#define P_MADR   			0x115
; 0x116 --------- IIC Mode Frequency Register
#define MFDR   				0x116	;	-			-			-			FD4			FD3			FD2			FD1			FD0
#define P_MFDR   			0x116
; 0x117 --------- IIC Mode Control Register
#define MCR  				0x117	;	-			-			-			MTX			TXAK		-			-			-
#define P_MCR  				0x117
; 0x118 --------- IIC Mode Status Register
#define MSR  				0x118	;	MCF 		MAAS		MBB			MAL 		-			SRW			MIF 		RXAK
#define P_MSR  				0x118
; 0x119 --------- Baud Rate Divisor Latch LSB Registe
#define DLL  				0x119	;	DLL7		DLL6		DLL5		DLL4		DLL3		DLL2		DLL1		DLL0
#define P_DLL  				0x119
; 0x11A --------- Baud Rate Divisor Latch MSB Registe
#define DLH  				0x11A	;	DLH7		DLH6		DLH5		DLH4		DLH3		DLH2		DLH1		DLH0
#define P_DLH  				0x11A
; 0x11B --------- Line Control Register
#define LCR  				0x11B	;	LOOP		SBRK		PSTUCK		PEVEN		PREN		STPS		WL1			WL0
#define P_LCR  				0x11B
; 0x11C --------- Line Status Register
#define LSR  				0x11C	;	-			TSRE		THRE  		BKINT		FERR		PERR		OERR		READY
#define P_LSR  				0x11C
; 0x11D --------- UART Transmit/Receive Buffer Register	
#define THR  				0x11D	;	URD7		URD6		URD5		URD4		URD3		URD2		URD1		URD0
#define P_THR  				0x11D
; 0x11E --------- PWM Delay Count for CCP Half-Bridge Output Mode
#define PWMDBx  			0x11E	;	DB7			DB6			DB5			DB4			DB3			DB2			DB1			DB0
#define P_PWMDBx  			0x11E
; 0x11F --------- Baud Rate Divisor Latch LSB Registe
#define CCPxCON  			0x11F	;	PWMxM1		PWMxM0		FBCH1		FBCH0		CCPxM3		CCPxM2		CCPxM1		CCPxM0
#define P_CCPxCON  			0x11F
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 3 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
; SFR_Name					Address	;	bit7	|	bit6	|	bit5	|	bit4	|	bit3	|	bit2	|	bit1	|	bit0
;-------------------------------------------------------------------------------------------------------------------------------------
; 0x189 --------- Resistance to Frequency Converter (RFC) function	
#define RFC  				0x189	;	RFCEN		-			-			-			PSEL3		PSEL2		PSEL1		PSEL0
#define P_RFC  				0x189
; 0x18A --------- Reserved
; 0x18B --------- Reserved
; 0x18C --------- LCD Control Register 0
#define LCDCON0  			0x18C	;	LCDEN		-			-			-			-			-			LCDRS1		LCDRS0
#define P_LCDCON0  			0x18C
; 0x18D --------- LCD Control Register 1
#define LCDCON1  			0x18D	;	P7COM		P6COM		P5COM		P4COM		P3COM		P2COM		P1COM		P0COM
#define P_LCDCON1  			0x18D
;-------------------------------------------------------------------------------------------------------------------------------------
;-------------------------------------------------------------------------------------------------------------------------------------
;General Constant Define
;-------------------------------------------------------------------------------------------------------------------------------------
#define	C_SaveToAcc			0x00	
#define	toacc				0x00
#define	ACC					0x00
#define	C_SaveToReg			0x01	
#define	toreg				0x01
#define	REG					0x01
			
#define	C_Bit0				0x01
#define	C_Bit1				0x02
#define	C_Bit2				0x04
#define	C_Bit3				0x08
#define	C_Bit4				0x10
#define	C_Bit5				0x20
#define	C_Bit6				0x40
#define	C_Bit7				0x80
;----------------------------------------			
#define	Bit0				0
#define	Bit1				1
#define	Bit2				2
#define	Bit3				3
#define	Bit4				4
#define	Bit5				5
#define	Bit6				6
#define	Bit7				7
;=============== REGISTER DEFINATION ==============================================
;============================================================ 
; INDF	 		0x00 --------- Indirect Addressing Register
;------------------------------------------------------------  
;Bit[7:0] : indirect addressing mode Data[7:0]
;============================================================
;============================================================ 
; TMR0	 		0x01 --------- Timer0 Data Register	
;------------------------------------------------------------ 
;Bit[7:0] : Timer0 Data
#define	C_TMR0_Data			0xFF	
;============================================================
;============================================================
; PCL			0x02 --------- Low Byte of Program Counter
;------------------------------------------------------------  
;Bit[7:0] : Program Counter Low Byte
;============================================================
;============================================================
; STATUS		0x03 --------- Status Register
;------------------------------------------------------------  
#define	C_RAM_Bank0			0x00			; RAM bank0 
#define	C_RAM_Bank1			0x20			; RAM bank1
#define	C_RAM_Bank2			0x40			; RAM bank2
#define	C_RAM_Bank3			0x60			; RAM bank3
;--------------------------------------------	
#define	IRP_Bit				7				; Bank select bits, indirect addressing mode, IRP & FSR[7] is used to select banks , IRP & FSR[7] 00 bank0, 01 bank1, 10 bank2, 11bank3
#define	BK1_Bit				6				; Bank select bits, direct addressing mode, BK1, BK0=00, bank 0 is selected. BK1, BK0=01, bank 1 is selected.(14bit Compile Use Only)
#define	BK0_Bit				5				; Bank select bits, direct addressing mode, BK1, BK0=10, bank 2 is selected. BK1, BK0=01, bank 3 is selected.(14bit Compile Use Only)
#define	TO_Bit				4				; Time overflow flag bit
#define	PD_Bit				3				; Power down flag bit
#define	Z_Bit				2				; Zero bit
#define	DC_Bit				1				; Half Carry/half Borrow bit
#define	C_Bit				0				; Carry/Borrow bit
;============================================================
;============================================================
; FSR			0x04 --------- File Selection Register (Include SRAM Bank Select)	
;------------------------------------------------------------  
;Bit[7]: Bank select bit 0 in indirect addressing mode.
;Bit[6:0] : Select one Register out of 128 registers of specific Bank.
#define	C_SFR_RAM_Addr		0x7F			; RAM Address Bit[6:0]
;--------------------------------------------
#define	C_FSR7				0x80			; Bank select bits
#define	FSR7_Bit			7				; Bank select bits, indirect addressing mode, IRP & FSR[7] is used to select banks
;============================================================
;============================================================
; PORTA			0x05 --------- PortA Data Register
;------------------------------------------------------------
;Bit[7:0] : PORTA Data Bit Define	
#define	C_PA_Data			0xFF			; PA Data
;============================================================
;============================================================
; PORTB			0x06 --------- PortB Data Register	
;------------------------------------------------------------ 
;Bit[7:0] : PORTB Data Bit Define	
#define	C_PB_Data			0xFF			; PB Data
;============================================================
;============================================================
; PORTC			0x07 --------- PortC Data Register
;------------------------------------------------------------ 
;Bit[5:0] : PORTC Data Bit Define	
#define	C_PC_Data			0x3F			; PC Data
;============================================================
;============================================================
; OSCCR			0x09 --------- Oscillation Control Register (Include Switch Working Mode)
;------------------------------------------------------------  
;[7:5] Reserve
#define	C_Normal_Mode		0x00			; Enter Normal mode											;Bit[3:2] : OPMD
#define	C_Halt_Mode			0x04			; Enter Halt mode
#define	C_Standby_Mode		0x08			; Enter Standby mode
#define	C_FHOSC_Stop		0x02			; Disable high-frequency oscillation (FHOSC) 				;Bit[1] : Stop HOSC
#define	C_Stop_HCK			0x02			; Disable high-frequency oscillation (FHOSC)
#define	C_FHOSC_Sel			0x01			; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)   ;Bit[0] : OSC Seletction
#define	C_FLOSC_Sel			0x00			; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
#define	C_IHRC				0x01			; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
#define	C_ILRC				0x00			; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
;--------------------------------------------
#define	XTL_BKUP_Bit			4        		; Write 1 to stop crystal 32.768K speed-up function, write-only.
#define	STPHOSC_Bit			1				; Stop high-frequency oscillation (FHOSC) Bit
#define	SELHOSC_Bit			0				; OSCCR[0]=1, FOSC is high-frequency oscillation (FHOSC)
;============================================================
; PCHBUF		0x0A --------- High Byte of Program Counter (B'xxxxDDDD')
;------------------------------------------------------------ 
;Bit[3:0] : Program Counter High Byte
;============================================================
;============================================================
; INTCON		0x0B --------- Interrupt Control Register
;------------------------------------------------------------ 
#define	C_INTE_GIE			0x80			; Global Interrupt enable 
#define	C_INTE_PEIE			0x40			; Peripheral Interrupt enable 
#define	C_INTE_T0IE			0x20			; Timer0 Overflow Interrupt enable 
#define	C_INTE_INT0IE		0x10			; External 0 Interrupt enable 
#define	C_INTE_PABCIE		0x08			; PortA/PortB/PortC change Interrupt enable
#define	C_INTF_T0IF			0x04			; Timer0 Overflow Interrupt flag bit
#define	C_INTF_INT0IF		0x02			; External 0 Interrupt flag bit
#define	C_INTF_PABCIF		0x01			; PortA/PortB/PortC change Interrupt flag bit
;--------------------------------------------
#define	GIE_Bit				7				; Global Interrupt enable bit
#define	PEIE_Bit			6				; Peripheral Interrupt enable bit
#define	T0IE_Bit			5				; Timer0 Overflow Interrupt enable bit
#define	INT0IE_Bit			4				; External 0 Interrupt enable bit
#define	PADIE_Bit			3				; PortA/PortB/PortC change Interrupt enable bit
#define	T0IF_Bit			2				; Timer0 Overflow Interrupt flag bit
#define	INT0IF_Bit			1				; External 0 Interrupt flag bit
#define	PABCIF_Bit			0				; PortA/PortB/PortC change Interrupt flag bit
;============================================================
;============================================================
; PIR1			0x0C --------- Interrupt Flag Register 1
;------------------------------------------------------------ 
;Bit[4:3] : Reserved
#define	C_INTF_INT2IF		0x80			; External interrupt 2 flag
#define	C_INTF_INT1IF		0x40			; External interrupt 1 flag
#define	C_INTF_WDTIF		0x20			; WDT timeout interrupt flag
#define	C_INTF_T5IF			0x04			; Timer5/CCP underflow interrupt flag
#define	C_INTF_CCPIF		0x04			; Timer5/CCP underflow interrupt flag
#define	C_INTF_T4IF			0x02			; Timer4 underflow interrupt flag
#define	C_INTF_T1IF			0x01			; Timer1 underflow interrupt flag
;--------------------------------------------
#define	INT2IF_Bit			7				; External interrupt 2 flag bit
#define	INT1IF_Bit			6				; External interrupt 1 flag bit
#define	WDTIF_Bit			5				; WDT timeout interrupt flag bit
#define	T5IF_Bit			2				; Timer5/CCP underflow interrupt flag bit
#define	CCPIF_Bit			2				; Timer5/CCP underflow interrupt flag bit
#define	T4IF_Bit			1				; Timer4 underflow interrupt flag bit
#define	T1IF_Bit			0				; Timer1 underflow interrupt flag bit
;============================================================
;============================================================
; PIR2			0x0D --------- Interrupt Flag Register 2
;============================================================  
;Bit[4] : Reserved
#define	C_INTF_ADIF			0x80			; ADC end of conversion interrupt flag 
#define	C_INTF_LVDIF		0x40			; LVD interrupt flag
#define	C_INTF_CMPIF		0x20			; Comparator interrupt flag
#define	C_INTF_SIMIF		0x08			; Serial port interrupt flag
#define	C_INTF_LSRIF		0x04			; LSR interrupt flag
#define	C_INTF_TXIF			0x02			; Transmitt holding register (THR) empty interrupt flag
#define	C_INTF_RXIF			0x01			; Receive one byte completely interrupt flag
;--------------------------------------------
#define	ADIF_Bit			7				; ADC end of conversion interrupt flag bit
#define	LVDIF_Bit			6				; LVD interrupt flag bit
#define	CMPIF_Bit			5				; Comparator interrupt flag bit
#define	SIMIF_Bit			3				; Serial port interrupt flag bit
#define	LSRIF_Bit			2				; LSR interrupt flag bit
#define	TXIF_Bit			1				; Transmitt holding register (THR) empty interrupt flag bit
#define	RXIF_Bit			0				; Receive one byte completely interrupt flag bit
;============================================================
;============================================================
; TMRxL 		0x0F --------- Timer low byte Register
;------------------------------------------------------------  
;Bit[7:0] : Timex Data ;SFR TMRxL, according to TPSEL[2:0] current value, point to  TMR1L, TMR4L or TMR5L.
#define	C_TMRx_Data			0xFF			; Full of TMRxL
;============================================================
;============================================================
; TMRxH 		0x10 --------- Timer low byte Register 
;------------------------------------------------------------ 
;Bit[1:0] : Timerx Data Value [9:8] ;SFR TMRxH, according to TPSEL[2:0] current value, point to  TMR1H, TMR4H or TMR5H.
#define	C_TMRx_Data_b9		0x02			; TMRx.bit9 = 1
#define	C_TMRx_Data_b8		0x01			; TMRx.bit8 = 1
;--------------------------------------------
#define	C_TMRx_Data_b9_Bit	1				; TMRx.9 bit
#define	C_TMRx_Data_b8_Bit	0				; TMRx.8 bit
;============================================================
;============================================================ 
; TxCR1			0x11 --------- Timex Control Register 1
;------------------------------------------------------------  
;Bit[7:6] : Reserved ;Bit[5] : Timex Match Output
;Bit[4:3] : TReserved  ;Bit[2:0] : Timex Control
#define	C_TMRx_Output_En	0x20			; Enable TxOUT output to PB5
#define	C_TMRx_Output_Dis	0x00			; Enable TxOUT output to PB5
#define C_TMRx_HRC_En		0x08			; Timerx and related PWM clock source is High Oscillator clock
#define C_TMRx_HRC_Dis		0x00			; Timerx and related PWM clock source selection depends on T1CS register bit
#define	C_TMRx_OneShot		0x04 			; One-Shot mode. Timerx will count once from the initial value to 0x00
#define	C_TMRx_Reload		0x02 			; Initial value is reloaded from reload register TMRx(TxOS=0)
#define	C_TMRx_En			0x01 			; Enable Timerx
#define	C_TMRx_Dis			0x00 			; Disable Timerx
;--------------------------------------------
#define	TMxOE_Bit			5				; Enable TxOUT output Bit
#define	TxOS_Bit			2 				; One-Shot mode Bit. Timerx will count once from the initial value to 0x00 
#define	TxRL_Bit			1 				; Initial value is reloaded from reload register TMRx(TxOS=0), reloaded Bit
#define	TxEN_Bit			0 				; Enable Timerx Bit
;============================================================
;============================================================
; TxCR2			0x12 --------- Timex Control Register 2
;------------------------------------------------------------  
;Bit[7:6] : Reserved ;Bit[5] : Timex Clock Source Select ;Bit[4] : Timex external clock edge selection
;Bit[3] :  Disable/enable Prescaler1 ;Bit[2:0] : Prescaler Dividing Rate Selection
#define	C_TMRx_ClkSrc_Ext	0x20			; Timex clock source from External Clock Input
#define	C_TMRx_ClkSrc_Inst	0x00			; Timex clock source from Internal Instruction Clock
#define	C_TMRx_ExtClk_Edge	0x10			; Timex External Clock Edge Select --- 1:Falling Edge, 0:Rising Edge  
#define	C_TMRx_ExtFalling	0x10			; Timex will decrease one while EX_CKI Falling Edge.
#define	C_TMRx_ExtRising	0x00			; Timex will decrease one while EX_CKI Rising Edge.
#define	C_PSx_Dis           0x08			; Enable Prescaler
#define	C_PSx_En			0x00			; Disable Prescaler
#define C_PSx_Div			0x07			; Prescaler1 Dividing Rate Selection
#define C_PSx_Div2			0x00
#define C_PSx_Div4			0x01
#define C_PSx_Div8			0x02
#define C_PSx_Div16			0x03
#define C_PSx_Div32			0x04
#define C_PSx_Div64			0x05
#define C_PSx_Div128		0x06
#define C_PSx_Div256		0x07
;--------------------------------------------
#define	TxCS_Bit			5				; Timex clock source from External Clock Input Edge Select Bit, 1: EXCKIx, 0:IRC
#define	TxCE_Bit			4				; Timex External Clock Edge Select Bit --- 1:Falling Edge, 0:Rising Edge  
#define	PSxEn_Bit           3				; Prescaler Enable Bit. 0 = Enable Prescaler, 1= Disable Prescaler
;============================================================
;============================================================ 
; BZ1CR			0x13 --------- Buzzer1 Control Register	
;------------------------------------------------------------ 
;Bit[7] : BZ1 Enable ;;Bit[6:4] : Reserved
;Bit[3:0] : BZ1 Frequency Selection
#define C_BZ1_En			0x80			; Enable BZ1 output
#define C_BZ1_Dis			0x00			; Disable BZ1 output
#define	C_BZ1_FSel			0x0F			; BZ1 frequency selection
#define	C_BZ1_PS1Div2		0x00			; Clock Soruce from Prescaler /2
#define	C_BZ1_PS1Div4		0x01			; Clock Soruce from Prescaler /4
#define	C_BZ1_PS1Div8		0x02			; Clock Soruce from Prescaler /8
#define	C_BZ1_PS1Div16		0x03			; Clock Soruce from Prescaler /16
#define	C_BZ1_PS1Div32		0x04			; Clock Soruce from Prescaler /32
#define	C_BZ1_PS1Div64		0x05			; Clock Soruce from Prescaler /64
#define	C_BZ1_PS1Div128		0x06			; Clock Soruce from Prescaler /128
#define	C_BZ1_PS1Div256		0x07			; Clock Soruce from Prescaler /256
#define	C_BZ1_TMR1B0		0x08			; Clock Source from Timer bit0
#define	C_BZ1_TMR1B1		0x09			; Clock Source from Timer bit1
#define	C_BZ1_TMR1B2		0x0A			; Clock Source from Timer bit2
#define	C_BZ1_TMR1B3		0x0B			; Clock Source from Timer bit3
#define	C_BZ1_TMR1B4		0x0C			; Clock Source from Timer bit4
#define	C_BZ1_TMR1B5		0x0D			; Clock Source from Timer bit5
#define	C_BZ1_TMR1B6		0x0E			; Clock Source from Timer bit6
#define	C_BZ1_TMR1B7		0x0F			; Clock Source from Timer bit7
;--------------------------------------------
#define C_BZ1_En_Bit		7				; Enable BZ1 output Bit
;============================================================
;============================================================
; AWUCON		0x14 --------- PortA Wakeup Control Register
;------------------------------------------------------------  
;Bit[7:0] : AWUCON Bit Define
#define	C_PA_Wakeup			0xFF			; Port A Wakeup Enable		
#define	C_PA7_Wakeup		0x80			; PA7 Wakeup Enable
#define	C_PA6_Wakeup		0x40			; PA6 Wakeup Enable 
#define	C_PA5_Wakeup		0x20			; PA5 Wakeup Enable
#define	C_PA4_Wakeup		0x10			; PA4 Wakeup Enable	
#define	C_PA3_Wakeup		0x08			; PA3 Wakeup Enable
#define	C_PA2_Wakeup		0x04			; PA2 Wakeup Enable 
#define	C_PA1_Wakeup		0x02			; PA1 Wakeup Enable
#define	C_PA0_Wakeup		0x01			; PA0 Wakeup Enable
;--------------------------------------------
#define WUPA7_Bit			7				; PA7 Wakeup Enable Bit
#define WUPA6_Bit			6				; PA6 Wakeup Enable Bit
#define WUPA5_Bit			5				; PA5 Wakeup Enable Bit
#define WUPA4_Bit			4				; PA4 Wakeup Enable Bit
#define WUPA3_Bit			3				; PA3 Wakeup Enable Bit
#define WUPA2_Bit			2				; PA2 Wakeup Enable Bit
#define WUPA1_Bit			1				; PA1 Wakeup Enable Bit
#define WUPA0_Bit			0				; PA0 Wakeup Enable Bit
;============================================================
;============================================================
; BCDWUCON 		0x15 --------- PortB/C/D Wakeup Control Register Select by SELCON[1:0] 00:PB, 01:PC 
;------------------------------------------------------------  
;Bit[7:0] : PortB PortC WUCON Bit Define
#define	C_PB_Wakeup			0xFF			; Port B Wakeup Enable		
#define	C_PB7_Wakeup		0x80			; PB7 Wakeup Enable
#define	C_PB6_Wakeup		0x40			; PB6 Wakeup Enable 
#define	C_PB5_Wakeup		0x20			; PB5 Wakeup Enable
#define	C_PB4_Wakeup		0x10			; PB4 Wakeup Enable	
#define	C_PB3_Wakeup		0x08			; PB3 Wakeup Enable
#define	C_PB2_Wakeup		0x04			; PB2 Wakeup Enable 
#define	C_PB1_Wakeup		0x02			; PB1 Wakeup Enable
#define	C_PB0_Wakeup		0x01			; PB0 Wakeup Enable

#define	C_PC_Wakeup			0x3F			; Port C Wakeup Enable		 
#define	C_PC5_Wakeup		0x20			; PC5 Wakeup Enable
#define	C_PC4_Wakeup		0x10			; PC4 Wakeup Enable	
#define	C_PC3_Wakeup		0x08			; PC3 Wakeup Enable
#define	C_PC2_Wakeup		0x04			; PC2 Wakeup Enable 
#define	C_PC1_Wakeup		0x02			; PC1 Wakeup Enable
#define	C_PC0_Wakeup		0x01			; PC0 Wakeup Enable
;--------------------------------------------
#define	WUPBCD7_Bit			7				; Px7 Wakeup Enable Bit
#define	WUPBCD6_Bit			6				; Px6 Wakeup Enable Bit
#define	WUPBCD5_Bit			5				; Px5 Wakeup Enable Bit
#define	WUPBCD4_Bit			4				; Px4 Wakeup Enable	Bit
#define	WUPBCD3_Bit			3				; Px3 Wakeup Enable Bit
#define	WUPBCD2_Bit			2				; Px2 Wakeup Enable Bit
#define	WUPBCD1_Bit			1				; Px1 Wakeup Enable Bit
#define	WUPBCD0_Bit			0				; Px0 Wakeup Enable Bit
;============================================================
;============================================================ 
; PORTACON30	0x16 --------- Port attribute Control Register
;------------------------------------------------------------ 
;Bit[7:6] : PortA.3 attribute setting	
;Bit[5:4] : PortA.2 attribute setting
;Bit[3:2] : PortA.1 attribute setting	
;Bit[1:0] : PortA.0 attribute setting
#define	C_Portx_PH			0xAA			; PortxCon all Input Pull-High
#define	C_Portx_PL			0x55			; PortxCon all Input Pull-Low
#define	C_Portx_FLO			0x00			; PortxCon all Input Floating
#define	C_Portx_PP			0x00			; PortxCon all Output Push Pull
#define	C_Portx_PP			0xAA			; PortxCon all Output Open Drain

#define	C_Portx3_PHPL		0xC0			; Px3 Input Pull-High + Pull-Low
#define	C_Portx3_PH			0x80			; Px3 Input Pull-High
#define	C_Portx3_PL			0x40			; Px3 Input Pull-Low
#define	C_Portx3_FLO		0x00			; Px3 Input Floating
#define	C_Portx3_PP			0x00			; Px3 Output Push Pull
#define	C_Portx3_OD			0x80			; Px3 Output Open Drain

#define	C_Portx2_PHPL		0x30			; Px2 Input Pull-High + Pull-Low
#define	C_Portx2_PH			0x20			; Px2 Input Pull-High
#define	C_Portx2_PL			0x10			; Px2 Input Pull-Low
#define	C_Portx2_FLO		0x00			; Px2 Input Floating
#define	C_Portx2_PP			0x00			; Px2 Output Push Pull
#define	C_Portx2_OD			0x20			; Px2 Output Open Drain

#define	C_Portx1_PHPL		0x0C			; Px1 Input Pull-High + Pull-Low
#define	C_Portx1_PH			0x08			; Px1 Input Pull-High
#define	C_Portx1_PL			0x04			; Px1 Input Pull-Low
#define	C_Portx1_FLO		0x00			; Px1 Input Floating
#define	C_Portx1_PP			0x00			; Px1 Output Push Pull
#define	C_Portx1_OD			0x08			; Px1 Output Open Drain

#define	C_Portx0_PHPL		0x03			; Px0 Input Pull-High + Pull-Low
#define	C_Portx0_PH			0x02			; Px0 Input Pull-High
#define	C_Portx0_PL			0x01			; Px0 Input Pull-Low
#define	C_Portx0_FLO		0x00			; Px0 Input Floating
#define	C_Portx0_PP			0x00			; Px0 Output Push Pull
#define	C_Portx0_OD			0x02			; Px0 Output Open Drain
;============================================================
;============================================================  
; PORTACON74	0x17 --------- Port attribute Control Register
;------------------------------------------------------------ 
;Bit[7:6] : PortA.7 attribute setting	
;Bit[5:4] : PortA.6 attribute setting		
;Bit[3:2] : PortA.5 attribute setting	
;Bit[1:0] : PortA.4 attribute setting
#define	C_Portx7_PHPL		0xC0			; Px7 Input Pull-High + Pull-Low
#define	C_Portx7_PH			0x80			; Px7 Input Pull-High
#define	C_Portx7_PL			0x40			; Px7 Input Pull-Low
#define	C_Portx7_FLO		0x00			; Px7 Input Floating
#define	C_Portx7_PP			0x00			; Px7 Output Push Pull
#define	C_Portx7_OD			0x80			; Px7 Output Open Drain
                                
#define	C_Portx6_PHPL		0x30			; Px6 Input Pull-High + Pull-Low
#define	C_Portx6_PH			0x20			; Px6 Input Pull-High
#define	C_Portx6_PL			0x10			; Px6 Input Pull-Low
#define	C_Portx6_FLO		0x00			; Px6 Input Floating
#define	C_Portx6_PP			0x00			; Px6 Output Push Pull
#define	C_Portx6_OD			0x20			; Px6 Output Open Drain
                                
#define	C_Portx5_PHPL		0x0C			; Px5 Input Pull-High + Pull-Low
#define	C_Portx5_PH			0x08			; Px5 Input Pull-High
#define	C_Portx5_PL			0x04			; Px5 Input Pull-Low
#define	C_Portx5_FLO		0x00			; Px5 Input Floating
#define	C_Portx5_PP			0x00			; Px5 Output Push Pull
#define	C_Portx5_OD			0x08			; Px5 Output Open Drain
                                
#define	C_Portx4_PHPL		0x03			; Px4 Input Pull-High + Pull-Low
#define	C_Portx4_PH			0x02			; Px4 Input Pull-High
#define	C_Portx4_PL			0x01			; Px4 Input Pull-Low
#define	C_Portx4_FLO		0x00			; Px4 Input Floating
#define	C_Portx4_PP			0x00			; Px4 Output Push Pull
#define	C_Portx4_OD			0x02			; Px4 Output Open Drain
;============================================================
;============================================================   
; PORTBCON30	0x18 --------- Port attribute Control Register
;------------------------------------------------------------  
;Bit[7:6] : PortB.3 attribute setting		
;Bit[5:4] : PortB.2 attribute setting
;Bit[3:2] : PortB.1 attribute setting
;Bit[1:0] : PortB.0 attribute setting
;============================================================
;============================================================  
; PORTBCON74	0x19 --------- Port attribute Control Register
;------------------------------------------------------------  
;Bit[7:6] : PortB.7 attribute setting	
;Bit[5:4] : PortB.6 attribute setting		
;Bit[3:2] : PortB.5 attribute setting	
;Bit[1:0] : PortB.4 attribute setting
;============================================================
;============================================================  
; PORTCCON30	0x1A --------- Port attribute Control Register
;------------------------------------------------------------  
;Bit[7:6] : PortC.3 attribute setting		
;Bit[5:4] : PortC.2 attribute setting
;Bit[3:2] : PortC.1 attribute setting
;Bit[1:0] : PortC.0 attribute setting
;============================================================
;============================================================ 
; PORTCCON74	0x1B --------- Port attribute Control Register
;------------------------------------------------------------ 
;Bit[7:4] : Reserve		
;Bit[3:2] : PortC.5 attribute setting
;Bit[1:0] : PortC.4 attribute setting
;============================================================
;============================================================  
; SELCON 		0x1D --------- Select Control Register(for Timer PWM)
;------------------------------------------------------------  
;Bit[7] : Virtual SFR CCPxCON and PWMDBx mapping
;Bit[6:5]: Reserve
;Bit[4:3] : Virtual SFR BCDWUCON mapping
;Bit[2:0] : Virtual SFR TMRxL/TMRxH/TxCR1/TxCR2/PWMxCON mapping.
#define	C_CCP2_SEL			0x80			; CCPxCON and PWMDBx map to CCP2CON and PWMDB1
#define	C_CCP1_SEL			0x00			; CCPxCON and PWMDBx map to CCP1CON and PWMDB0
#define	C_PCWUCON_SEL		0x08			; Select PortC Wake-up Control Register
#define	C_PBWUCON_SEL		0x00			; Select PortB Wake-up Control Register
#define	C_Timer1_SEL		0x01			; Select Timer1 Control Register
#define	C_Timer4_SEL		0x04			; Select Timer4 Control Register
#define	C_Timer5_SEL		0x05			; Select Timer5 Control Register
#define	C_PWM1_SEL			0x01			; Select PWM1 Control Register
#define	C_PWM2_SEL			0x02			; Select PWM2 Control Register
#define	C_PWM3_SEL			0x03			; Select PWM3 Control Register
#define	C_PWM4_SEL			0x04			; Select PWM4 Control Register
#define	C_PWM5_SEL			0x05			; Select PWM5 Control Register
;--------------------------------------------
#define	CCPSEL_Bit				7			; Virtual SFR CCPxCON and PWMDBx mapping Bit Select
;============================================================
;============================================================ 
; PWMxCON 		0x1F --------- PWM Control Register
;------------------------------------------------------------  
;Bit[7:2]: Reserve
#define	C_PWMx_En			0x02			; PWMx output will be present on PAD
#define	C_PWMx_Active		0x01 			; PWMx output is active low.
#define	C_PWMx_Active_Lo	0x01 			; PWMx output is active low 
#define	C_PWMx_Active_Hi	0x00 			; PWMx output is active high 
;--------------------------------------------
#define	PWMxOEN_Bit			1				; PWMx output Eanble Bit, 1:Enable, 0:Disable
#define	PWMxOAL_Bit			0				; PWMx output active state, 1:Active Low. 0:Active High.
;============================================================ 
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 1 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
;============================================================
;============================================================ 
; T0MD			0x81 --------- Timer0 Control Register
;------------------------------------------------------------  
;Bit[7&5&4] : Timer0 Clock Source Selection
;Bit[6] : Timer0 Enable
;Bit[3] : Watchdog Interrupt Source Selection / Timer0 Prescaler0 Selection
;Bit[2:0] : Prescaler0 Dividing Rate Selection
#define	C_TMR0_LowClk		0x80			; Same as LCKTM0
#define	C_TMR0_En			0x40			; Enable TMR0
#define C_TMR0_Dis			0x00			; Disable TMR0
#define	C_TMR0_Clk			0x20			; Same as T0CS
#define	C_TMR0_ExtFalling	0x10			; Timer0 External Clock Edge Select --- 1:Falling Edge, 0:Rising Edge
#define	C_TMR0_ExtRising	0x00			; Timer0 External Clock Edge Select --- 1:Falling Edge, 0:Rising Edge
#define	C_PS0_WDT			0x08			; Prescaler0 is assigned to WDT
#define	C_PS0_TMR0			0x00			; Prescaler0 is assigned to TMR0
#define	C_PS0_Div			0x07			; Prescaler0 Dividing Rate Selection
#define	C_PS0_Div2			0x00			; Prescaler0 Dividing Rate 1/2		
#define	C_PS0_Div4			0x01			; Prescaler0 Dividing Rate 1/4
#define	C_PS0_Div8			0x02			; Prescaler0 Dividing Rate 1/8
#define	C_PS0_Div16			0x03			; Prescaler0 Dividing Rate 1/16
#define	C_PS0_Div32			0x04			; Prescaler0 Dividing Rate 1/32
#define	C_PS0_Div64			0x05			; Prescaler0 Dividing Rate 1/64
#define	C_PS0_Div128		0x06			; Prescaler0 Dividing Rate 1/128
#define	C_PS0_Div256		0x07			; Prescaler0 Dividing Rate 1/256
;--------------------------------------------
#define	LCKTM0_Bit			7				; When T0CS=1, CPU Clock Select Bit. 1:EXCKI0 selected, 0: ILC/E_LXT selected
#define	T0EN_Bit 			6				; Timer0 Enable Bit
#define	T0CS_Bit 			5				; Timer0 clock source selection Bit
#define	T0CE_Bit			4				; Timer0 external clock edge selection Bit
#define	PS0WDT_Bit			3				; Prescaler0 assignment Bit
;============================================================
;============================================================  
; IOSTA			0x85 --------- PortA I/O Control Register
;------------------------------------------------------------ 
;Bit[7:0] : Port A Input/Output Mode Selection (1:Input, 0:Output)
#define	C_PA_Input			0xFF			; Port A all Input Mode Control
#define	C_PA_Output			0x00			; Port A all Output Mode Control                   
#define	C_PA7_Input			0x80			; PA7 Set as Input
#define	C_PA6_Input			0x40			; PA6 Set as Input
#define	C_PA5_Input			0x20			; PA5 Set as Input
#define	C_PA4_Input			0x10			; PA4 Set as Input 
#define	C_PA3_Input			0x08			; PA3 Set as Input
#define	C_PA2_Input			0x04			; PA2 Set as Input
#define	C_PA1_Input			0x02			; PA1 Set as Input
#define	C_PA0_Input			0x01			; PA0 Set as Input 
#define	C_PA7_Output		0x00			; PA7 Set as Output
#define	C_PA6_Output		0x00			; PA6 Set as Output
#define	C_PA5_Output		0x00			; PA5 Set as Output
#define	C_PA4_Output		0x00			; PA4 Set as Output 	
#define	C_PA3_Output		0x00			; PA3 Set as Output
#define	C_PA2_Output		0x00			; PA2 Set as Output
#define	C_PA1_Output		0x00			; PA1 Set as Output
#define	C_PA0_Output		0x00			; PA0 Set as Output 
;--------------------------------------------
#define	PA7_Bit				7				; PA7 I/O mode Control bit
#define	PA6_Bit				6				; PA6 I/O mode Control bit
#define	PA5_Bit				5				; PA5 I/O mode Control bit
#define	PA4_Bit				4				; PA4 I/O mode Control bit 	
#define	PA3_Bit				3				; PA3 I/O mode Control bit
#define	PA2_Bit				2				; PA2 I/O mode Control bit
#define	PA1_Bit				1				; PA1 I/O mode Control bit
#define	PA0_Bit				0				; PA0 I/O mode Control bit 
;============================================================
;============================================================ 
; IOSTB			0x86 --------- PortB I/O Control Register
;------------------------------------------------------------  
;Bit[7:0] : Port B Input/Output Mode Selection (1:Input, 0:Output)
#define	C_PB_Input			0XFF			; Port B Input Mode Control
#define	C_PB_Output			0x00			; Port B Output Mode Control
#define	C_PB7_Input			0X80			; PB7 Set as Input
#define	C_PB6_Input			0X40			; PB6 Set as Input	
#define	C_PB5_Input			0x20			; PB5 Set as Input
#define	C_PB4_Input			0x10			; PB4 Set as Input 
#define	C_PB3_Input			0x08			; PB3 Set as Input
#define	C_PB2_Input			0x04			; PB2 Set as Input
#define	C_PB1_Input			0x02			; PB1 Set as Input
#define	C_PB0_Input			0x01			; PB0 Set as Input 
#define	C_PB7_Output		0X00			; PB7 Set as Output
#define	C_PB6_Output		0X00			; PB6 Set as Output	
#define	C_PB5_Output		0x00			; PB5 Set as Output
#define	C_PB4_Output		0x00			; PB4 Set as Output
#define	C_PB3_Output		0x00			; PB3 Set as Output
#define	C_PB2_Output		0x00			; PB2 Set as Output
#define	C_PB1_Output		0x00			; PB1 Set as Output
#define	C_PB0_Output		0x00			; PB0 Set as Output
;--------------------------------------------
#define	PB7_Bit				7				; PB7 I/O mode Control bit
#define	PB6_Bit				6				; PB6 I/O mode Control bit
#define	PB5_Bit				5				; PB5 I/O mode Control bit
#define	PB4_Bit				4				; PB4 I/O mode Control bit 	
#define	PB3_Bit				3				; PB3 I/O mode Control bit
#define	PB2_Bit				2				; PB2 I/O mode Control bit
#define	PB1_Bit				1				; PB1 I/O mode Control bit
#define	PB0_Bit				0				; PB0 I/O mode Control bit 
;============================================================
;============================================================  
; IOSTC			0x87 --------- PortC I/O Control Register
;------------------------------------------------------------  
;Bit[5:0] : Port C Input/Output Mode Selection (1:Input, 0:Output)
#define	C_PC_Input			0x3F			; PC5~PC0 Input Mode Control
#define	C_PC_Output			0x00			; PC5~PC0 Output Mode Control
#define	C_PC5_Input			0x20			; PC5 Set as Input
#define	C_PC4_Input			0x10			; PC4 Set as Input
#define	C_PC3_Input			0x08			; PC3 Set as Input
#define	C_PC2_Input			0x04			; PC2 Set as Input
#define	C_PC1_Input			0x02			; PC1 Set as Input
#define	C_PC0_Input			0x01			; PC0 Set as Input	
#define	C_PC5_Output		0x00			; PC5 Set as Output
#define	C_PC4_Output		0x00			; PC4 Set as Output
#define	C_PC3_Output		0x00			; PC3 Set as Output
#define	C_PC2_Output		0x00			; PC2 Set as Output
#define	C_PC1_Output		0x00			; PC1 Set as Output
#define	C_PC0_Output		0x00			; PC0 Set as Output
;--------------------------------------------
#define	PC5_Bit				5				; PC5 I/O mode Control bit
#define	PC4_Bit				4				; PC4 I/O mode Control bit 	
#define	PC3_Bit				3				; PC3 I/O mode Control bit
#define	PC2_Bit				2				; PC2 I/O mode Control bit
#define	PC1_Bit				1				; PC1 I/O mode Control bit
#define	PC0_Bit				0				; PC0 I/O mode Control bit 
;============================================================
;============================================================  
; LVDCON		0x89 --------- LVD Control Register
;------------------------------------------------------------  
;Bit[7,5,4] Reserve
;Bit[6] Low voltage detector output;Bit[3:0] Select LVD voltage
#define	C_LVDOUT			0x40			; Low voltage detector output, read-only
#define	C_LVD_4P15V			0x0F			; LVD Voltage=4.15V
#define	C_LVD_4P05V			0x0E			; LVD Voltage=4.05V	
#define	C_LVD_3P9V			0x0D			; LVD Voltage=3.9V	
#define	C_LVD_3P75V			0x0C			; LVD Voltage=3.75V	
#define	C_LVD_3P6V			0x0B			; LVD Voltage=3.6V
#define	C_LVD_3P45V			0x0A			; LVD Voltage=3.45V	
#define	C_LVD_3P3V			0x09			; LVD Voltage=3.3V	
#define	C_LVD_3P15V			0x08			; LVD Voltage=3.15V	
#define	C_LVD_3P0V			0x07			; LVD Voltage=3.0V	
#define	C_LVD_2P9V			0x06			; LVD Voltage=2.9V	
#define	C_LVD_2P8V			0x05			; LVD Voltage=2.8V
#define	C_LVD_2P6V			0x04			; LVD Voltage=2.6V	
#define	C_LVD_2P4V			0x03			; LVD Voltage=2.4V
#define	C_LVD_2P2V			0x02			; LVD Voltage=2.2V
#define	C_LVD_2P0V			0x01			; LVD Voltage=2.0V
#define	C_LVD_1P9V			0x00			; LVD Voltage=1.9V
;--------------------------------------------
#define	LVDOUT_Bit			6				; Low voltage detector output, read-only
;============================================================
;============================================================  
; PIE1			0x8C --------- Interrupt Enable Register
;------------------------------------------------------------  
;Bit[4:3] Reserve
#define	C_INTE_INT2IE		0x80			;External interrupt 2 enable
#define	C_INTE_INT1IE		0x40			;External interrupt 1 enable
#define	C_INTE_WDTIE		0x20			;WDT timeout interrupt enable
#define	C_INTE_T5IE			0x04			;Timer5/CCP underflow interrupt enable
#define	C_INTE_CCPIE		0x04			;Timer5/CCP underflow interrupt enable
#define	C_INTE_T4IE			0x02			;Timer4 underflow interrupt enable
#define	C_INTE_T1IE			0x01			;Timer1 underflow interrupt enable
;--------------------------------------------
#define	INT2IE_Bit			7				;External interrupt 2 enable bit
#define	INT1IE_Bit			6				;External interrupt 1 enable bit
#define	WDTIE_Bit			5				;WDT timeout interrupt enable bit
#define	T5IE_Bit			2				;Timer5/CCP underflow interrupt enable bit
#define	CCPIE_Bit			2				;Timer5/CCP underflow interrupt enable bit
#define	T4IE_Bit			1				;Timer4 underflow interrupt enable bit
#define	T1IE_Bit			0				;Timer1 underflow interrupt enable bit
;============================================================
;============================================================  
; PIE2			0x8D --------- Interrupt Enable Register 2
;------------------------------------------------------------ 
 ;Bit[4] Reserve
#define	C_INTE_ADIE			0x80			;ADC end of conversion interrupt enable
#define	C_INTE_LVDIE		0x40			;LVD interrupt enable 
#define	C_INTE_CMPIE		0x20			;Comparator interrupt enable 
#define	C_INTE_SIMIE		0x08			;Serial port interrupt enable 
#define	C_INTE_LSRIE		0x04			;LSR interrupt enable 
#define	C_INTE_TXIE			0x02			;Transmitt holding register (THR) empty interrupt enable 
#define	C_INTE_RXIE			0x01			;Receive one byte completely interrupt enable
;--------------------------------------------
#define	ADIE_Bit			7				;ADC end of conversion interrupt enable bit
#define	LVDIE_Bit			6				;LVD interrupt enable bit
#define	CMPIE_Bit			5				;Comparator interrupt enable bit
#define	SIMIE_Bit			3				;Serial port interrupt enable bit
#define	LSRIE_Bit			2				;LSR interrupt enable bit
#define	TXIE_Bit			1				;Transmitt holding register (THR) empty interrupt enable bit
#define	RXIE_Bit			0				;Receive one byte completely interrupt enable bit
;============================================================
;============================================================  
; PCON			0x8F --------- Power Control Regsiter
;------------------------------------------------------------  
;Bit[6,4,2,1,0] Reserve
#define	C_WDT_En			0x80			; WDT Enable
#define	C_WDT_Dis			0x00			; WDT Disable
#define	C_LVD_En			0x20			; LVD Enable
#define	C_LVD_Dis			0x00			; LVD Disable
#define	C_LVR_En			0x08			; LVR Enable
#define	C_LVR_Dis			0x00			; LVR Disable
;--------------------------------------------
#define	WDTEN_Bit			7				; WatchDog Timer Enable Bit
#define	LVDEN_Bit			5	            ; Low voltage Detector Enable Bit
#define	LVREN_Bit			3               ; Low Voltage Reset Enable Bit
;============================================================
;============================================================  
; IRCR			0x90 --------- IR Control Register
;------------------------------------------------------------  
;Bit[6:3] : Reserved
#define	C_IR_OSC358M		0x80			; IRCR[7]=1 , external crystal is 3.58MHz (This bit is ignored if internal high frequency oscillation is used)
#define	C_IR_OSC455K		0x00			; IRCR[7]=0 , external crystal is 455KHz
#define	C_IR_Low_Carrier	0x04			; Polarity selection of IR carrier Output Low carry. 
#define	C_IR_High_Carrier	0x00			; Polarity selection of IR carrier Output High carry 
#define	C_IR_57K			0x02			; IRCR[1]=1 , IR carrier frequency is 57KHz
#define	C_IR_38K			0x00			; IRCR[1]=0 , IR carrier frequency is 38KHz
#define	C_IR_En				0x01			; Enable IR carrier output
#define	C_IR_Dis			0x00			; Disable IR carrier output
;--------------------------------------------
#define	IROSC358M_Bit		7				; External crystal set bit, 1:3.58MHz, 0:455KHz
#define	IRCSEL_Bit			2				; Polarity selection of IR carrier. 1, Output Low carry,  0, Output High carry 
#define	IRF57K_Bit			1				; IR carrier frequency selection Bit. 1:57k, 038k
#define	IREN_Bit			0				; IR carrier Enable Bit.
;============================================================
;============================================================  
; PWM1DUTY		0x91 --------- PWM1 Duty Register
;------------------------------------------------------------  
;Bit[7:0] : PWM1 Duty Value
#define	C_PWM1_Duty			0xFF			; Full of PWM1_Duty
;============================================================
;============================================================  
; PWM1DUTYH		0x92 --------- PWM1 Duty Register
;------------------------------------------------------------  
;Bit[1:0] : PWM1 Duty Value [9:8]
#define	C_PWM1_Duty_b9		0x02            ; PWM1_Duty.bit9 = 1
#define	C_PWM1_Duty_b8		0x01            ; PWM1_Duty.bit8 = 1
;--------------------------------------------
#define	C_PWM1_Duty_b9_Bit	1               ; PWM1_Duty.9 bit
#define	C_PWM1_Duty_b8_Bit	0               ; PWM1_Duty.8 bit
;============================================================
;============================================================ 
; PWM2DUTY		0x93 --------- PWM2 Duty Register
;------------------------------------------------------------  
;Bit[7:0] : PWM2 Duty Value
#define	C_PWM2_Duty			0xFF	        ; Full of PWM2_Duty
;============================================================
;============================================================    
; PWM2DUTYH		0x94 --------- PWM2 Duty Register
;------------------------------------------------------------   
;Bit[1:0] : PWM2 Duty Value [9:8]           
#define	C_PWM2_Duty_b9		0x02            ; PWM2_Duty.bit9 = 1
#define	C_PWM2_Duty_b8		0x01            ; PWM2_Duty.bit8 = 1
;--------------------------------------------
#define	C_PWM2_Duty_b9_Bit	1               ; PWM2_Duty.9 bit
#define	C_PWM2_Duty_b8_Bit	0               ; PWM2_Duty.8 bit
;============================================================
;============================================================ 
; PWM3DUTY		0x95 --------- PWM3 Duty Register
;------------------------------------------------------------  
;Bit[7:0] : PWM3 Duty Value
#define	C_PWM3_Duty			0xFF	        ; Full of PWM3_Duty
;============================================================
;============================================================  
; PWM3DUTYH		0x96 --------- PWM3 Duty Register
;------------------------------------------------------------  
;Bit[1:0] : PWM3 Duty Value [9:8]           
#define	C_PWM3_Duty_b9		0x02            ; PWM3_Duty.bit9 = 1
#define	C_PWM3_Duty_b8		0x01            ; PWM3_Duty.bit8 = 1
;--------------------------------------------    
#define	C_PWM3_Duty_b9_Bit	1               ; PWM3_Duty.9 bit
#define	C_PWM3_Duty_b8_Bit	0               ; PWM3_Duty.8 bit
;===========================================
;============================================================  
; PWM4DUTY		0x97 --------- PWM4 Duty Register
;------------------------------------------------------------  
;Bit[7:0] : PWM4 Duty Value
#define	C_PWM4_Duty			0xFF	        ; Full of PWM4_Duty
;============================================================
;============================================================   
; PWM4DUTYH		0x98 --------- PWM4 Duty Register
;------------------------------------------------------------   
;Bit[1:0] : PWM4 Duty Value [9:8]           
#define	C_PWM4_Duty_b9		0x02            ; PWM4_Duty.bit9 = 1
#define	C_PWM4_Duty_b8		0x01            ; PWM4_Duty.bit8 = 1
;--------------------------------------------    
#define	C_PWM4_Duty_b9_Bit	1               ; PWM4_Duty.9 bit
#define	C_PWM4_Duty_b8_Bit	0               ; PWM4_Duty.8 bit
;============================================================
;============================================================ 
; PWM5DUTY		0x99 --------- PWM5 Duty Register
;------------------------------------------------------------  
;Bit[7:0] : PWM5 Duty Value
#define	C_PWM5_Duty			0xFF	        ; Full of PWM5_Duty
;============================================================
;============================================================   
; PWM5DUTYH		0x9A --------- PWM5 Duty Register
;------------------------------------------------------------   
;Bit[1:0] : PWM5 Duty Value [9:8]           
#define	C_PWM5_Duty_b9		0x02            ; PWM5_Duty.bit9 = 1
#define	C_PWM5_Duty_b8		0x01            ; PWM5_Duty.bit8 = 1
;--------------------------------------------    
#define	C_PWM5_Duty_b9_Bit	1               ; PWM5_Duty.9 bit
#define	C_PWM5_Duty_b8_Bit	0               ; PWM5_Duty.8 bit
;============================================================
;============================================================  
; INTEDG		0x9B --------- Interrupt Edge Register
;------------------------------------------------------------  
;Bit[7] : INT2 edge trigger select 
;Bit[6] : External interrupt 2 select bit
;Bit[5] : External interrupt 1 select bit
;Bit[4] : External interrupt 0 select bit
;Bit[3:2] : INT1 edge trigger select 
;Bit[1:0] : INT0 edge trigger select 
#define C_INT2_Falling		0x00			; Falling edge trigger	
#define C_INT2_Rising		0x80			; Rising edge trigger	
#define C_INT2_En			0x40			; PA5 set as INT2 input
#define C_INT2_Dis			0x00			; PA5 set as GPIO
#define C_INT1_En			0x20			; PB1(PA3) set as INT1 input
#define C_INT1_Dis			0x00			; PB1(PA3) set as GPIO
#define C_INT0_En			0x10			; PB4(PA4) set as INT0 input
#define C_INT0_Dis			0x00			; PB4(PA4) set as GPIO
#define C_INT1_Edge			0x0C			; INT1 trigger edge  --- 11b: Rising & Falling Edge, 10b:Falling Edge, 01b:Rising Edge    
#define C_INT1_TwoEdge		0x0C			; Rising & Falling edge trigger
#define C_INT1_Falling		0x08			; Falling edge trigger	
#define C_INT1_Rising		0x04			; Rising edge trigger			
#define C_INT0_Edge			0x03			; INT0 trigger edge  --- 11b: Rising & Falling Edge, 10b:Falling Edge, 01b:Rising Edge  
#define C_INT0_TwoEdge		0x03			; Rising & Falling edge trigger
#define C_INT0_Falling		0x02			; Falling edge trigger	
#define C_INT0_Rising		0x01			; Rising edge trigger	
;--------------------------------------------
#define INT2DEG_Bit			7				; Bit of INT2 Trigger Edge, 1: Rising, 0:Falling
#define EIS2_Bit			6				; Exernal Interrupt 2 Enable Bit
#define EIS1_Bit			5				; Exernal Interrupt 1 Enable Bit
#define EIS0_Bit			4				; Exernal Interrupt 0 Enable Bit 
;============================================================ 
;============================================================ 
; CMPCON		0x9C --------- Comparator Control Register
;------------------------------------------------------------
;Bit[7] : Comparator Enable 
;Bit[6] : Comparator Bias Enable
;Bit[5:2]: Reserve
;Bit[0] : Comparator Output to Pad PB3
#define C_CMP_En 			0x80			; Comparator Enable	
#define C_CMP_Dis			0x00            ; Comparator Disable
#define C_Bias_En 			0x40            ; Comparator module bias Enable
#define C_Bias_Dis			0x00            ; Comparator module bias Disable
#define C_CMPO_En 			0x01            ; Comparator Output Status to PB3 Enable
#define C_CMPO_Dis			0x00            ; Comparator Output Status to PB3 Disable
;--------------------------------------------
#define CMPEN_Bit			7				; Comparator Enable Bit
#define BIASEN_Bit			6				; Comparator / LVD module bias enable Bit
#define CMPOUT_Bit			1				; Comparator output status Bit, read-only
#define CMPOE_Bit			0				; Comparator output to pad PB3 Enalbe Bit
;============================================================
;============================================================ 
; CMPCR			0x9D --------- Comparator voltage select Control Register
;------------------------------------------------------------  
;Bit[7] : Reserved
;Bit[6] : VDD_ref bias high enable bit  (1:Enable, 0: Disable)
;Bit[5] : VDD_ref bias low enable bit  (1:Enable, 0: Disable) 
;Bit[4] : Comparator output inverse control bit
#define C_RBias_High_En 	0x40			; VDD_ref Set Corresponding Voltage Reference levels High Bit Enable
#define C_RBias_High_Dis 	0x00            ; VDD_ref Set Corresponding Voltage Reference levels High Bit Disable
#define C_RBias_Low_En 		0x20            ; VDD_ref Set Corresponding Voltage Reference levels Low Bit Enable
#define C_RBias_Low_Dis 	0x00            ; VDD_ref Set Corresponding Voltage Reference levels Low Bit Disable
#define C_CMPFINV_En		0x10			; CMPOUT_Bit=1 when Vp < Vn	
#define C_CMPFINV_Dis		0x00			; CMPOUT_Bit=1 when Vp > Vn
;--------------------------------------------
#define RBias_H_Bit 		6				; VDD_ref Set Corresponding Voltage Reference levels High Bit
#define RBias_L_Bit 		5               ; VDD_ref Set Corresponding Voltage Reference levels Low Bit
#define CMPFINV_Bit 		4               ; Comparator output inverse control bit
;Comparator input select
;Bit[3:0]	Non-inverting input		Inverting input
;--------------------------------------------
;0000		PA0/PA4(P0)				PA1/PB3(N0)
;0001		PA0/PA4					PA3
;0010		PA0/PA4					Bandgap(0.6v)
;0011		PA0/PA4					VDD_ref
;0100		PA2(P1)					PA1/PB3(N0)
;0101		PA2						PA3
;0110		PA2						Bandgap
;0111		PA2						VDD_ref
;1000		VDD_ref					PA1/PB3(N0)
;1001		VDD_ref					PA3
;1010		VDD_ref					Bandgap				(only for LVD)
;1011		NA						NA
;11XX		NA						NA
;============================================================
;============================================================ 
; TBHP			0x9E --------- Table Access High Byte Address Pointer Register
;------------------------------------------------------------  
;Bit[7:4] : Reserved
;Bit[3:0] : Table Access High Byte Address Pointer
#define	C_TbHigh_Addr		0x0F			; When instruction TABLEA is executed TBHP[3:0] is ROM Address High Byte, ACC is Low Byte.
;============================================================
;============================================================  
; TBHD			0x9F --------- Table Access High Byte Data Register
;------------------------------------------------------------  
;Bit[7:0] : Table Access High Byte Data (Read Only)
;#define	C_TbHigh_Data		0xFF			; When instruction TABLEA is executed TBHD[7:0] is ROM Data High Byte, ACC is Low Byte.
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 2 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
;============================================================
;============================================================ 
; ADMD			0x109 --------- ADC mode Register
;------------------------------------------------------------  
;Bit[7] : Enable/Disable ADC bit
;Bit[6] : Start a ADC conversion session 
;Bit[5] : Globe Enable/Disable  ADC input channel bit
;Bit[4:0] : Select ADC input channel
#define	C_ADC_En			0x80			; Enable ADC
#define	C_ADC_Dis			0x00			; Disable ADC	
#define	C_ADC_Start			0x40			; Write 1 to this bit, start ADC converting
#define	C_ADC_CH_En			0x20			; Enable all ADC input channel
#define	C_ADC_CH_Dis		0x00			; Disable all ADC input channel
#define	C_ADC_VSS			0x1D			; VSS pad as ADC input channel
#define	C_Quarter_VDD		0x1C			; 1/4 VDD as ADC input channel	
#define	C_ADC_PC5			0x15			; PC5 pad as ADC input channel	
#define	C_ADC_PC4			0x14			; PC4 pad as ADC input channel	
#define	C_ADC_PC3			0x13  			; PC3 pad as ADC input channel	
#define	C_ADC_PC2			0x12			; PC2 pad as ADC input channel		
#define	C_ADC_PC1			0x11			; PC1 pad as ADC input channel
#define	C_ADC_PC0			0x10			; PC0 pad as ADC input channel
#define	C_ADC_PB7			0x0F			; PB7 pad as ADC input channel		
#define	C_ADC_PB6			0x0E			; PB6 pad as ADC input channel		
#define	C_ADC_PB5			0x0D			; PB5 pad as ADC input channel	
#define	C_ADC_PB4			0x0C			; PB4 pad as ADC input channel	
#define	C_ADC_PB3			0x0B  			; PB3 pad as ADC input channel	
#define	C_ADC_PB2			0x0A			; PB2 pad as ADC input channel		
#define	C_ADC_PB1			0x09			; PB1 pad as ADC input channel
#define	C_ADC_PB0			0x08			; PB0 pad as ADC input channel
#define	C_ADC_PA7			0x07			; PA7 pad as ADC input channel		
#define	C_ADC_PA6			0x06			; PA6 pad as ADC input channel		
#define	C_ADC_PA4			0x04			; PA4 pad as ADC input channel	
#define	C_ADC_PA3			0x03			; PA3 pad as ADC input channel	
#define	C_ADC_PA2			0x02			; PA2 pad as ADC input channel	
#define	C_ADC_PA1			0x01			; PA1 pad as ADC input channel		
#define	C_ADC_PA0			0x00			; PA0 pad as ADC input channel
;--------------------------------------------
#define	ADEN_Bit			7				; ADC enable bit.
#define	START_Bit			6				; ADC conversion Start bit.
#define	GCHS_Bit			5				; ADC global channel select bit.
;============================================================
;============================================================ 
; ADDL			0x10C --------- ADC Low Byte Conversion Result Register
;------------------------------------------------------------  
; ADDL[7:0]: Low-byte ADC data buffer. Read-only
;============================================================
;============================================================ 
; ADDH			0x10D --------- ADC High Byte Conversion Result Register
;------------------------------------------------------------  
; ADDH[7:0]: High-byte ADC data buffer. Read-only
;============================================================
;============================================================   
; ADCON1 		0x10E --------- ADC Control Register 1	
;------------------------------------------------------------ 
;Bit[7] : ADC reference high voltage (VREFH) select control bit
;Bit[6] : Reserved	
;Bit[5] : ADC is end-of-convert
;Bit[4] : ADC Result format select bit
;Bit[3:2] : Select one of the 4 ADC clock
;Bit[1:0] : VHS[1:0] Select ADC internal high reference voltage
#define C_Vrefh_External	0x80			; ADC reference high voltage is supplied by external pin PA0
#define C_Vrefh_Internal	0x00			; ADC reference high voltage is internal generated, the voltage selected depends on VHS1~0.
#define	C_ADC_Finish		0x20			; (1:ADC is Finish, 0:ADC is in procession) Read-only
#define	C_ADFM_Right		0x10			; (0: MSB in ADDH, 1: MSB Right 4 bits) 
#define	C_ADFM_Left			0x00			; (0: MSB in ADDH, Normal Format) 
#define C_ADC_CLK_Div2		0x0C			; ADC clock is Fcpu/2
#define C_ADC_CLK_Div1		0x08			; ADC clock is Fcpu/1	
#define C_ADC_CLK_Div8		0x04			; ADC clock is Fcpu/8
#define C_ADC_CLK_Div16		0x00			; ADC clock is Fcpu/16
#define C_Vrefh_VDD			0x03			; ADC reference high voltage is VDD
#define C_Vrefh_4V			0x02			; ADC reference high voltage is 4V	
#define C_Vrefh_3V			0x01			; ADC reference high voltage is 3V	
#define C_Vrefh_2V			0x00			; ADC reference high voltage is 2V
;--------------------------------------------
#define	EVHENB_Bit 			7				; ADC reference high voltage (VREFH) select control bit.
#define	EOC_Bit				5	        	; ADC status bit, read-only. 1:Finish ADC
#define	ADFM_Bit			4           	; ADC Result format Select bit.
#define	ADCK1_Bit			3           	; ADC clock select bit1.
#define	ADCK0_Bit			2           	; ADC clock select bit0.
#define	VHS1_Bit			1           	; ADC internal reference high voltage select bit1
#define	VHS0_Bit			0           	; ADC internal reference high voltage select bit0
;============================================================
;============================================================  
; ADJMD 		0x10F --------- ADC Adjust Offset		
;------------------------------------------------------------  
#define C_ADC_INC_11mV		0X3F			; ADC Offset 11mV
#define C_ADC_DCE_11mV		0X1F			; ADC Offset -11mV
;--------------------------------------------
#define	ADJ_SIGN_Bit 		5				; ADC adjust sign bit.  1: INCREASE, 0:DECREASE
;============================================================ 
;============================================================   
; PxCON 		0x110 --------- Port Analog Pin Control Register		
;------------------------------------------------------------  
;Bit[7:0] Px pure analog pin Enable ; 1 = pure analog pin for power saving. ; 0 = can be analog or digital pin.
;Select PA,PB,PC by ADCR[7:6]
#define	C_PxCON7			0x80			; Px7 is selected as pure analog pin	
#define	C_PxCON6			0x40			; Px6 is selected as pure analog pin
#define	C_PxCON5			0x20		    ; Px5 is selected as pure analog pin
#define	C_PxCON4			0x10		    ; Px4 is selected as pure analog pin
#define	C_PxCON3			0x08			; Px3 is selected as pure analog pin
#define	C_PxCON2			0x04	        ; Px2 is selected as pure analog pin
#define	C_PxCON1			0x02		    ; Px1 is selected as pure analog pin
#define	C_PxCON0			0x01		    ; Px0 is selected as pure analog pin
#define	C_PxCON				0xFF			; Portx all pin is selected as pure analog
;--------------------------------------------
#define	PxCON7_Bit			7			    ; Px7 pure analog pin select bit
#define	PxCON6_Bit			6			    ; Px6 pure analog pin select bit
#define	PxCON5_Bit			5		        ; Px5 pure analog pin select bit
#define	PxCON4_Bit			4		        ; Px4 pure analog pin select bit
#define	PxCON3_Bit			3			    ; Px3 pure analog pin select bit
#define	PxCON2_Bit			2	            ; Px2 pure analog pin select bit
#define	PxCON1_Bit			1		        ; Px1 pure analog pin select bit
#define	PxCON0_Bit			0               ; Px0 pure analog pin select bit
;============================================================
;============================================================ 
; ADCR  		0x111 --------- Sampling pulse and ADC bit Register
;------------------------------------------------------------  
;Bit[7:6] : Select bits for mapping of virtual SFR PxCON
;Bit[5:0] : Reserved
;Bit[3:2] : Select ADC sampling pulse width
;Bit[1:0] : Select ADC conversion bit numbers 
#define C_Select_PACON		0x00			; Port A analog pin setting (PACON)
#define C_Select_PBCON 		0x40			; Port B analog pin setting (PBCON)
#define C_Select_PCCON 		0x80			; Port C analog pin setting (PCCON)
#define C_Sample_8Clk		0x0C			; ADC Sampling pulse width is 8 ADC clock
#define C_Sample_4Clk		0x08			; ADC Sampling pulse width is 4 ADC clock
#define C_Sample_2Clk		0x04			; ADC Sampling pulse width is 2 ADC clock
#define C_Sample_1Clk		0x00			; ADC Sampling pulse width is 1 ADC clock
#define C_12Bit				0x03			; 12-bit ADC
#define C_10Bit				0x01			; 10-bit ADC
#define C_8Bit				0x00			;  8-bit ADC
#define C_ADC_12_Bit		0x03			; 12-bit ADC
#define C_ADC_10_Bit		0x01			; 10-bit ADC
#define C_ADC_8_Bit			0x00			;  8-bit ADC
;--------------------------------------------
#define	PxSEL1_Bit			7			    ; Virtual SFR PxCON register select bit1
#define	PxSEL0_Bit			6			    ; Virtual SFR PxCON register select bit0
#define	SHCK1_Bit			3			    ; Sampling pulse width select bit1
#define	SHCK0_Bit			2	            ; Sampling pulse width select bit0
#define	ADCR1_Bit			1		        ; ADC conversion bit no. select bit1
#define	ADCR0_Bit			0               ; ADC conversion bit no. select bit0
;============================================================
;============================================================ 
; SIMDR  		0x112 --------- Serial Interface Mode Data Register(IIC and SPI)
;------------------------------------------------------------  
;Bit[7:0] : Serial interface mode data register
#define	C_SIMDR				0xFF			; SPI/IIC Data Register
;============================================================
;============================================================ 
; SIMCR  		0x113 --------- Serial Interface Mode Control Register(IIC and SPI)
;------------------------------------------------------------  
;Bit[7] : Enable/disable SPI function
;Bit[6] : Enable/disable IIC function
;Bit[5] : Select master / slave mode (include SPI / IIC)
;Bit[4] : Enable / disable SSB pin (used at SPI mode)
#define C_SPI_En			0x80			; Enable SPI function
#define C_SPI_Dis			0x00			; Disable SPI function	
#define C_IIC_En			0x40			; Enable IIC function
#define C_IIC_Dis			0x00			; Disable IIC function
#define	C_Master_En			0x20			; Select master mode
#define	C_Slave_En			0x00			; Select slave mode
#define	C_SSB_En			0x10			; Enable SSB (PB5)
#define	C_SSB_Dis			0x00			; Disable SSB
;Bit[3] : Enable / disable UART RX PAD
;Bit[2] : Enable / disable UART TX PAD
;Bit[1] : Enable / disable UART RCLK
;Bit[0] : Enable / disable UART BAUDOZ
#define	C_RX_En				0x08			; Enable UART RX (PB7)
#define	C_RX_Dis			0x00			; Disable UART RX, PB7 is GPIO
#define	C_TX_En				0x04			; Enable UART TX (PB6)
#define	C_TX_Dis			0x00			; Disable UART TX, PB6 is GPIO
#define	C_RCLK_En			0x02			; Enable UART RCLK (PB5)
#define	C_RCLK_Dis			0x00			; Disable UART RCLK, PB5 is GPIO
#define	C_UART_En			0x01			; Enable UART Function
#define	C_UART_Dis			0x00			; Disable UART Function
;--------------------------------------------
#define SIMC1_Bit			7				; SPI mode enable bit
#define SIMC0_Bit			6               ; IIC mode enable bit
#define MSTA_Bit			5               ; Master mode /slave mode select bit
#define SSB_PAD_Bit			4               ; SPI CS pin function enable select bit
#define RX_PADEN_Bit		3               ; UART interface RXPAD enable bit. PB7/PB0
#define TX_PADEN_Bit		2               ; UART interface TXPAD enable bit. PB6/PB1
#define RCLK_PADEN_Bit		1               ; UART interface RCLK_PAD enable bit. PB4
#define UREN_Bit			0               ; UART interface enable bit. 
;============================================================
;============================================================  
; SPCR  		0x114 --------- SPI Mode Control Register	
;------------------------------------------------------------  
;Bit[7] : SPI Data Transfer Complete
;Bit[6] : Write Collision   Bit[5]: Reserve 
;Bit[4] : Mode Fault
#define	C_SPIF				0x80			; (1:Transmission complete , 0:Transmission not complete)
#define	C_WCOL				0x40			; (1:Invalid write to SIMDR , 0:No invalid write to SIMDR)
#define	C_MODF				0x10			; (1:SSB pulled low while master mode , 0:SSB not pulled low while master mode)
;Bit[3] : Clock Polarity
;Bit[2] : SPI SCK Active Edge Type Selection
;Bit[1:0] : SPI Clock Rate
#define	C_SCK_High			0x08			; SCK pin at logic 1 between transmissions, idle high
#define	C_SCK_Low			0x00			; SCK pin at logic 0 between transmissions, idle low
#define	C_SCK_Rising		0x04			; CPOL=1: Capture at SCK falling edge, CPOL=0: Capture at SCK rising edge
#define	C_SCK_Falling		0x00			; CPOL=1: Capture at SCK rising edge, CPOL=0: Capture at SCK falling edge
#define C_SPI_Clk_DIV32		0x03			; System clock/32
#define C_SPI_Clk_DIV16		0x02			; System clock/16
#define C_SPI_Clk_DIV4		0x01			; System clock/4
#define C_SPI_Clk_DIV2		0x00			; System clock/2
;--------------------------------------------
#define	SPIF_Bit			7               ; SPI Flag bit
#define	WCOL_Bit			6               ; Write Collision bit
#define	MODF_Bit			4               ; Mode Fault bit
#define	CPOL_Bit			3               ; Clock Polarity bit
#define	CKEG_Bit			2               ; SPI SCK clock active edge type selection bit
#define	SPR1_Bit			1               ; SPI Clock Rate bit1
#define	SPR0_Bit			0               ; SPI Clock Rate bit0
;============================================================
;============================================================   
; MADR   		0x115 --------- IIC Mode Address Register	
;------------------------------------------------------------  
;Bit[7:1] : IIC mode address register
#define	C_MADR				0xFE			; IIC mode slave address register
;Bit[0] : Reserved
;--------------------------------------------
#define	MAD7_Bit			7				; IIC mode slave address bit7
#define	MAD6_Bit			6				; IIC mode slave address bit6
#define	MAD5_Bit			5				; IIC mode slave address bit5
#define	MAD4_Bit			4				; IIC mode slave address bit4
#define	MAD3_Bit			3				; IIC mode slave address bit3
#define	MAD2_Bit			2				; IIC mode slave address bit2
#define	MAD1_Bit			1				; IIC mode slave address bit1
;============================================================
;============================================================  
; MFDR   		0x116 --------- IIC Mode Frequency Register	
;------------------------------------------------------------  
;Bit[7:5] : Reserved
;Bit[4:0] : IIC Mode Frequency Dividing Rate Selection
#define C_FD_Div			0x1F			; IIC Mode Frequency Dividing Rate Selection
#define C_FD_Div22			0x00
#define C_FD_Div24			0x01
#define C_FD_Div28			0x02
#define C_FD_Div34			0x03
#define C_FD_Div44			0x04
#define C_FD_Div48			0x05
#define C_FD_Div56			0x06
#define C_FD_Div68			0x07
#define C_FD_Div88			0x08
#define C_FD_Div96			0x09
#define C_FD_Div112			0x0A
#define C_FD_Div136			0x0B
#define C_FD_Div176			0x0C
#define C_FD_Div192			0x0D
#define C_FD_Div224			0x0E
#define C_FD_Div272			0x0F
#define C_FD_Div352			0x10
#define C_FD_Div384			0x11
#define C_FD_Div448			0x12
#define C_FD_Div544			0x13
#define C_FD_Div704			0x14
#define C_FD_Div768			0x15
#define C_FD_Div896			0x16
#define C_FD_Div1088		0x17
#define C_FD_Div1408		0x18
#define C_FD_Div1536		0x19
#define C_FD_Div1792		0x1A
#define C_FD_Div2176		0x1B
#define C_FD_Div2816		0x1C
#define C_FD_Div3072		0x1D
#define C_FD_Div3584		0x1E
#define C_FD_Div4352		0x1F
;============================================================
;============================================================  
; MCR  			0x117 --------- IIC Mode Control Register	
;------------------------------------------------------------  
;Bit[7:5] : Reserved ;Bit[2:0] : Reserved 
;Bit[4] : IIC mode transmit/receive mode Select
;Bit[3] : IIC mode acknowledge enable
#define	C_IIC_TX			0x10			; IIC mode transmit mode
#define	C_IIC_RX			0x00			; IIC mode receive mode
#define	C_NACK				0x08			; Do not send acknowledge signal
#define	C_ACK				0x00			; Send acknowledge at 9th lock bit
;--------------------------------------------
#define	MTX_Bit				4				; IIC mode TX/RX select bit 
#define	TXAK_Bit			3				; IIC mode ACK Enable Bit
;============================================================
;============================================================  
; MSR  			0x118 --------- IIC Mode Status Register		
;------------------------------------------------------------  
;Bit[7] : IIC Data Transfer Complete
;Bit[6] : IIC Address Check as Slave mode
;Bit[5] : IIC Bus Busy 
;Bit[4] : IIC Arbitration Lost in Master Mode
#define	C_MCF				0x80			; (1:A byte has been completed , 0:A byte is being transfer) Read-only
#define	C_MAAS				0x40			; (1:Currently addressed , 0:not currently addressed) Read-only
#define	C_MBB				0x20			; (1:bus busy, 0:bus idle) Read-only
#define	C_MAL				0x10			; (1:Lost arbitration, 0:No arbitration lost)
;Bit[3] : Reserved
;Bit[2] : IIC Read / Write selection as Slave mode
;Bit[1] : IIC Interrupt Flag
;Bit[0] : Receive Acknowledge
#define	C_SRW				0x04			; (1:Read from slave, from calling master, 0:Write to slave from calling master) Read-only
#define	C_MIF				0x02			; (1:IIC interrupt has occurred, 0:IIC interrupt has not occurred)
#define	C_RXAK				0x01			; (1:NACK, 0:ACK) Read-only
;--------------------------------------------
#define MCF_Bit			7				; IIC mode Tx Complete bit 
#define MAAS_Bit			6				; IIC mode Currently addressed bit
#define MBB_Bit			5				; IIC mode Bus Busy bit 
#define MAL_Bit			4				; IIC mode Arbitration Lost bit
#define SRW_Bit			2				; IIC mode Slave R/W select bit 1:Read 0:Write
#define MIF_Bit			1				; IIC mode IIC INT Flag
#define RXAK_Bit			0				; IIC mode Receive Acknowledge bit
;============================================================
;============================================================  
; DLL  			0x119 --------- Baud Rate Divisor Latch LSB Registe
;------------------------------------------------------------
;Bit[7:0] : Baud rate divider LSB bit
#define	DLL7_Bit			7				;UART Baud rate divider LSB bit7
#define	DLL6_Bit			6				;UART Baud rate divider LSB bit6
#define	DLL5_Bit			5				;UART Baud rate divider LSB bit5
#define	DLL4_Bit			4				;UART Baud rate divider LSB bit4
#define	DLL3_Bit			3				;UART Baud rate divider LSB bit3
#define	DLL2_Bit			2				;UART Baud rate divider LSB bit2
#define	DLL1_Bit			1				;UART Baud rate divider LSB bit1
#define	DLL0_Bit			0				;UART Baud rate divider LSB bit0
;============================================================
;============================================================ 
; DLH  			0x11A --------- Baud Rate Divisor Latch MSB Registe	
;------------------------------------------------------------
;Bit[7:0] : Baud rate divider MSB bit
#define	DLH7_Bit			7				;UART Baud rate divider MSB bit7
#define	DLH6_Bit			6				;UART Baud rate divider MSB bit6
#define	DLH5_Bit			5				;UART Baud rate divider MSB bit5
#define	DLH4_Bit			4				;UART Baud rate divider MSB bit4
#define	DLH3_Bit			3				;UART Baud rate divider MSB bit3
#define	DLH2_Bit			2				;UART Baud rate divider MSB bit2
#define	DLH1_Bit			1				;UART Baud rate divider MSB bit1
#define	DLH0_Bit			0				;UART Baud rate divider MSB bit0
;============================================================
;============================================================  
; LCR  			0x11B --------- Line Control Register		
;------------------------------------------------------------  
;Bit[7] : Loop Back Test Enable
;Bit[6] : Set Break
;Bit[5] : Stuck Parity Enable
;Bit[4] : Even Parity Select
#define	C_LOOP_En			0x80			; Enable loop back test
#define	C_LOOP_Dis			0x00			; Disable loop back test
#define	C_SBRK_En			0x40			; Enable set break
#define	C_SBRK_Dis			0x00			; Disable set break
#define	C_PSTUCK_En			0x20			; Enable stuck parity
#define	C_PSTUCK_Dis		0x00			; Disable stuck parity
#define	C_Even_Parity		0x10			; Select even parity
#define	C_Odd_Parity		0x00			; Select odd parity
;Bit[3] : Parity Enable
;Bit[2] : STOP Bit Number
;Bit[1:0] : Word Length Bits
#define	C_Parity_En			0x08			; Enable parity
#define	C_Parity_Dis		0x00			; Disable parity
#define	C_STOP_2			0x04			; Select 2 stop bit
#define	C_STOP_1P5			0x04			; Select 1.5 stop bit
#define	C_STOP_1			0x00			; Select 1 stop bit
#define	C_WL_8				0x03			; Select word length 8 bit
#define	C_WL_7				0x02			; Select word length 7 bit
#define	C_WL_6				0x01			; Select word length 6 bit
#define	C_WL_5				0x00			; Select word length 5 bit
;--------------------------------------------
#define	LOOP_Bit			7				; Loop back test enable bit
#define	SBRK_Bit			6				; Set Break bit
#define	PSTUCK_Bit		5				; Stuck Parity bit
#define	PEVEN_Bit			4				; Even parity select bit
#define	PREN_Bit			3				; Parity Enable bit
#define	STPS_Bit			2				; Number of STOP bits
#define	WL1_Bit			1				; Word length select bit1
#define	WL0_Bit			0				; Word length select bit0
;============================================================
;============================================================   
; LSR  			0x11C --------- Line Status Register	
;------------------------------------------------------------  
;Bit[7] : Reserved
;Bit[6] : Transmitter shift register(TSR) empty
;Bit[5] : Transmitter holding register (THR) empty flag
;Bit[4] : Break interrupt flag
#define	C_TSRE				0x40			; Transmitter shift register(TSR) empty flag
#define	C_THRE  			0x20			; Transmitter holding flag
#define	C_BKINT				0x10			; Break interrupt flag
;Bit[3] : Frame error flag
;Bit[2] : Parity error flag
;Bit[1] : Over run error flag
;Bit[0] : Data ready flag
#define	C_FERR				0x08			; Frame error flag
#define	C_PERR				0x04			; Parity error flag
#define	C_OVERR				0x02			; Over run error flag
#define	C_READY				0x01			; Data ready flag 
;--------------------------------------------
#define	TSRE_Bit			6				; Transmitter shift register(TSR) empty flag
#define	THRE_Bit  			5				; Transmitter holding flag
#define	BKINT_Bit			4				; Break interrupt flag
#define	FERR_Bit			3				; Frame error flag
#define	PERR_Bit			2				; Parity error flag
#define	OVERR_Bit			1				; Over run error flag
#define	READY_Bit			0				; Data ready flag 
;============================================================
;============================================================   
; THR  			0x11D --------- UART Transmit/Receive Buffer Register	
;------------------------------------------------------------  
;Bit[7:0] : Transmit holding register /Receive Buffer Register
#define	C_UART_DATA			0xFF			; UART DATA TX 0XFF
;============================================================
;============================================================ 
; PWMDBx  		0x11E --------- PWM Delay Register (Half-bridge output. P1A,P1B modulated with deadband control.)
;--------------------------------------------------------------------------------------------------	
;Bit[7:0] : PWM Delay Count for Half-Bridge Output Mode  ( Unit:1 CPU Cycle/Bit)
#define	C_CCP_PWM_Delay		0xFF			; Number of Instruction clock cycles between the P1A(PB2) transition and the P1B(PA5) transition.
;============================================================
;============================================================   
; CCPxCON  		0x11F --------- Baud Rate Divisor Latch LSB Registe
;------------------------------------------------------------  
;Bit[7:6] : CCP1_PWM Output Configuration   
;Bit[5:4] : Full-bridge change direction gap(deadband)
#define C_CCP_SingOut		0x00			; 00 : Single output. P1A(PB2) modulated. P1B(PA5), P1C(PA2), P1D(PA4) assigned as GPIO pins.
#define C_CCP_Forward		0x40			; 01 : Full-bridge output forward. P1D(PA4) modulated. P1A(PB2) active. P1B(PA5), P1C(PA2) inactive.
#define C_CCP_HalfOut		0x80			; 10 : Half-bridge output. P1A(PB2), P1B(PA5) modulated with deadband control. P1C(PA2), P1D(PA4) assigned as GPIO pins.
#define C_CCP_Reverse		0xC0			; 11 : Full-bridge output reverse. P1B(PA5) modulated. P1C(PA2) active. P1A(PB2), P1D(PA4) inactive.							
#define	C_FBDel_1CPU		0x00			; 1  CPU Cycle
#define	C_FBDel_4CPU		0x10			; 4  CPU Cycle
#define	C_FBDel_16CPU		0x20			; 16 CPU Cycle
;Bit[3:0] : CCP Mode Select bits
#define	C_CCP_Reset				0x00		; 0000 = Capture/Compare/PWM off (resets ECCP modules)
											; 0001 = Unused (reserved)
#define	C_CCP_Comp_Toggle		0x02		; 0010 = Compare mode, toggle P1A(PB2) output on match (CCP1IF bit is set)
											; 0011 = Unused (reserved)
#define	C_CCP_Capt_Falling	 	0x04		; 0100 = Capture mode, every falling edge
#define	C_CCP_Capt_Rising		0x05		; 0101 = Capture mode, every rising edge
#define	C_CCP_Capt_4timeRise	0x06		; 0110 = Capture mode, every 4th rising edge
#define	C_CCP_Capt_16timeRise	0x07		; 0111 = Capture mode, every 16th rising edge
#define	C_CCP_Comp_High			0x08		; 1000 = Compare mode, set P1A(PB2) output on match (CCP1IF bit is set)
#define	C_CCP_Comp_Low			0x09		; 1001 = Compare mode, clear P1A(PB2) output on match (CCP1IF bit is set)
#define	C_CCP_Comp_INT			0x0A		; 1010 = Compare mode, generate interrupt flag on match (CCP1IF bit is set, P1A pin is unaffected)
#define	C_CCP_Comp_Event		0x0B		; 1011 = Compare mode, trigger special event event. (CCP1IF bit is set; ECCP reload TMR1, and starts an A/D conversion, if the A/D module is enabled)
#define	C_CCP_PWM_All_ActHigh	0x0C		; 1100 = PWM mode. P1A(PB2), P1C(PA2) active high. P1D(PA4), P1B(PA5) active high.
#define	C_CCP_PWM_P1AC_ActHigh	0x0D		; 1101 = PWM mode. P1A(PB2), P1C(PA2) active high. P1D(PA4), P1B(PA5) active low.
#define	C_CCP_PWM_P1BD_ActHigh	0x0E		; 1110 = PWM mode. P1A(PB2), P1C(PA2) active low.  P1D(PA4), P1B(PA5) active high.
#define	C_CCP_PWM_All_ActLow	0x0F		; 1111 = PWM mode. P1A(PB2), P1C(PA2) active low.  P1D(PA4), P1B(PA5) active low.

;For CCP2 Select
;Bit[7:6] : CCP1_PWM Output Configuration
#define C_CCP_HalfOut		0x80			; 10 : Half-bridge output. P2A(PC2), P2B(PC5) modulated with deadband control.
;Bit[3:0] : CCP Mode Select bits
#define	C_CCP_PWM_All_ActHigh	0x0C		; 1100 = PWM mode. P2A(PC2) active high. P2B(PC5) active high.
#define	C_CCP_PWM_P1AC_ActHigh	0x0D		; 1101 = PWM mode. P2A(PC2) active high. P2B(PC5) active low.
#define	C_CCP_PWM_P1BD_ActHigh	0x0E		; 1110 = PWM mode. P2A(PC2) active low.  P2B(PC5) active high.
#define	C_CCP_PWM_All_ActLow	0x0F		; 1111 = PWM mode. P2A(PC2) active low.  P2B(PC5) active low.
;--------------------------------------------
#define	PWMxM1_Bit			7				; PWM mode select bit1
#define	PWMxM0_Bit			6				; PWM mode select bit0
#define	FBCH1_Bit			5				; Full band change direction gap bit1
#define	FBCH0_Bit			4				; Full band change direction gap bit0
#define	CCPxM3_Bit			3				; CCP Mode Select bit3
#define	CCPxM2_Bit			2				; CCP Mode Select bit2
#define	CCPxM1_Bit			1				; CCP Mode Select bit1
#define	CCPxM0_Bit			0				; CCP Mode Select bit0
;-------------------------------------------------------------------------------------------------------------------------------------	
; Bank 3 Special Function Register
;-------------------------------------------------------------------------------------------------------------------------------------
;============================================================
;============================================================  
; RFC  			0x189 --------- Resistance to Frequency Converter (RFC) function	
;------------------------------------------------------------ 
;Bit[7] : RFC Enable
#define C_RFC_En			0x80			; Enable RFC Function
#define C_RFC_Dis			0x00			; Disable RFC Function
;Bit[3:0] : RFC Pin Select
#define C_RFC_PA0			0x00			; PA0 select as RFC Function pin, when PA0 delect low, timer1 counting
#define C_RFC_PA1			0x01            ; PA1 select as RFC Function pin, when PA1 delect low, timer1 counting
#define C_RFC_PA2			0x02            ; PA2 select as RFC Function pin, when PA2 delect low, timer1 counting
#define C_RFC_PA3			0x03            ; PA3 select as RFC Function pin, when PA3 delect low, timer1 counting
#define C_RFC_PA4			0x04            ; PA4 select as RFC Function pin, when PA4 delect low, timer1 counting
#define C_RFC_PA5			0x05            ; PA5 select as RFC Function pin, when PA5 delect low, timer1 counting
#define C_RFC_PA6			0x06            ; PA6 select as RFC Function pin, when PA6 delect low, timer1 counting
#define C_RFC_PA7			0x07            ; PA7 select as RFC Function pin, when PA7 delect low, timer1 counting
#define C_RFC_PB0			0x08            ; PB0 select as RFC Function pin, when PB0 delect low, timer1 counting
#define C_RFC_PB1			0x09            ; PB1 select as RFC Function pin, when PB1 delect low, timer1 counting
#define C_RFC_PB2			0x0A            ; PB2 select as RFC Function pin, when PB2 delect low, timer1 counting
#define C_RFC_PB3			0x0B            ; PB3 select as RFC Function pin, when PB3 delect low, timer1 counting
#define C_RFC_PB4			0x0C            ; PB4 select as RFC Function pin, when PB4 delect low, timer1 counting
#define C_RFC_PB5			0x0D            ; PB5 select as RFC Function pin, when PB5 delect low, timer1 counting
#define C_RFC_PB6			0x0E            ; PB6 select as RFC Function pin, when PB6 delect low, timer1 counting
#define C_RFC_PB7			0x0F            ; PB7 select as RFC Function pin, when PB7 delect low, timer1 counting
;--------------------------------------------
#define RFCEN_Bit			7				; RFC Function Enable bit
#define PSEL3_Bit			3				; RFC Pin select bit3
#define PSEL2_Bit			2				; RFC Pin select bit2
#define PSEL1_Bit			1				; RFC Pin select bit1
#define PSEL0_Bit			0				; RFC Pin select bit0
;============================================================
;============================================================   
; LCDCON0  		0x18C --------- LCD Control Register 0
;------------------------------------------------------------ 
;Bit[7] : LCD Enable
#define C_LCD_En			0x80			; Enable LCD Function
#define C_LCD_Dis			0x00			; Disable LCD Function
;Bit[6:2] : Reserved
;Bit[1:0] : 1/2 VDD Current Select
#define C_LCD_8uA			0x00
#define C_LCD_16uA			0x01
#define C_LCD_50uA			0x02
#define C_LCD_100uA			0x03
;--------------------------------------------
#define LCDEB_Bit			7				; LCD Function Enable bit
#define LCDRS1_Bit			1				; LCD current select bit1
#define LCDRS0_Bit			0				; RFC current select bit0
;============================================================
;============================================================   
; LCDCON1  		0x18D --------- LCD Control Register 1
;------------------------------------------------------------  
#define	C_P7COM_En			0x80			; PC5 1/2 VDD
#define	C_P6COM_En			0x40			; PC4 1/2 VDD
#define	C_P5COM_En			0x20			; PC3 1/2 VDD
#define	C_P4COM_En			0x10			; PC2 1/2 VDD
#define	C_P3COM_En			0x08			; PB7 1/2 VDD
#define	C_P2COM_En			0x04			; PB6 1/2 VDD
#define	C_P1COM_En			0x02			; PB5 1/2 VDD
#define	C_P0COM_En			0x01			; PB4 1/2 VDD
;--------------------------------------------
#define P7COM_Bit			7				; PC5 1/2 VDD select bit
#define P6COM_Bit			6				; PC4 1/2 VDD select bit
#define P5COM_Bit			5				; PC3 1/2 VDD select bit
#define P4COM_Bit			4				; PC2 1/2 VDD select bit
#define P3COM_Bit			3				; PB7 1/2 VDD select bit
#define P2COM_Bit			2				; PB6 1/2 VDD select bit
#define P1COM_Bit			1				; PB5 1/2 VDD select bit
#define P0COM_Bit			0				; PB4 1/2 VDD select bit
;------------------------------------------------------------  
;============================================================
;============================================================ 

ENDIF
