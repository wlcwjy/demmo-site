﻿;--------------- FILE INCLUDE ---------------------------------------------
#include		"NY8BM84A.H"						; The Header File 

;--------------- VARIABLE DEFINITION --------------------------------------
V_ACC			            EQU		0x20				; Store ACC value
V_STATUS		            EQU		0x21				; Store Status value

V_DELAY_COUNT1              EQU		0x22
V_DELAY_COUNT2              EQU		0x23
V_LED_MODE_NUMBER			EQU		0x24
V_SYSTEM_STATUS				EQU		0x25
V_BUTTON_IN_DELAY			EQU		0x26
V_GAME_RANDOM_ADDR			EQU		0x27
V_I							EQU		0x28
V_RUN_LOOP					EQU		0x29
V_RUN_SUB_LOOP              EQU		0x2A    
V_PORTB                     EQU		0x2B
V_PORTC                     EQU		0x2C
V_BREATE_AL1				EQU		0x2D    
V_BREATE_BL1				EQU		0x2E  
V_BREATE_COUNT				EQU		0x2F 
V_BREATE_DELAY				EQU		0x30  
V_BREATE_AL2				EQU		0x31    
V_BREATE_BL2				EQU		0x32 
V_BREATE_PERIOD 			EQU		0x33
V_BREATHE_RANDOM_ADDR		EQU		0x34
V_PORTA0					EQU		0x35
V_PORTA1					EQU		0x36
V_PORTA2					EQU		0x37
V_PORTA3					EQU		0x38
V_PORTB0					EQU		0x39
V_PORTB1					EQU		0x3A
V_PORTB2					EQU		0x3B
V_PORTB3					EQU		0x3C
V_BUTTON_IN_DELAY_HIGH	    EQU		0x3D    
  
V_DELAY_T0_COUNT			EQU		0x40  
V_DELAY_T0_NMS				EQU		0x41 
V_DELAY_T0_TEMP				EQU		0x42
V_DELAY_T0_20MS				EQU		0x43 
V_DELAY_T0_30MS				EQU		0x44 
V_DELAY_T0_35MS				EQU		0x45 
V_DELAY_T0_45MS				EQU		0x46 
V_DELAY_T0_55MS				EQU		0x47 
V_DELAY_T0_10MS				EQU		0x48 

V_CTRL_LED_NUM              EQU		0x50  
;--------------- CONSTANT DEFINITION --------------------------------------
C_OSH_BPIN 					EQU 	1
C_BUTTON_BPIN				EQU 	0

C_LED1_ACTRL				EQU 	01111111B
C_LED2_ACTRL				EQU 	10111111B
C_LED3_ACTRL				EQU 	11011111B
C_LED4_ACTRL				EQU 	11101111B
C_LED5_BCTRL				EQU 	11110111B
C_LED6_BCTRL				EQU 	11111011B
C_LED7_CCTRL				EQU 	11111110B
C_LED8_CCTRL				EQU 	11111101B
C_LED9_BCTRL				EQU 	01111111B
C_LED10_BCTRL				EQU 	10111111B
C_LED11_BCTRL				EQU 	11011111B
C_LED12_BCTRL				EQU 	11101111B
C_LED13_ACTRL				EQU 	11111110B
C_LED14_ACTRL				EQU 	11111101B
C_LED15_ACTRL				EQU 	11111011B
C_LED16_ACTRL				EQU 	11110111B
C_LED17_CCTRL				EQU 	11111011B
C_LED18_CCTRL				EQU 	11110111B
C_LED19_CCTRL				EQU 	11101111B
C_LED20_CCTRL				EQU 	11011111B

C_ALED_ALL_ON				EQU 	00000000B
C_BLED_ALL_ON				EQU 	00000011B
C_CLED_ALL_ON				EQU 	00000000B
C_ALED_ALL_OFF				EQU 	11111111B
C_BLED_ALL_OFF				EQU 	11111111B
C_CLED_ALL_OFF				EQU 	11111111B

C_STATUS_IS_POWER_ON		EQU		0  
C_STATUS_BUTTON_SHORT_PRESS	EQU		1  
C_STATUS_LED_MODE			EQU		2  
C_STATUS_BUTTON_LONG_PRESS	EQU		3 
C_STATUS_GAME_KEY   	    EQU		4 

C_BUTTON_SHORT_DELAY		EQU		3
C_BUTTON_LONG_DELAY		    EQU		200     ; 5ms*200=1000ms=1s
C_BREATHE_PERIOD			EQU		50
C_GAME_RANDOM_ADDR_HIGH     EQU		0x00
C_GAME_RANDOM_ADDR_START    EQU		0x10
C_GAME_RANDOM_ADDR_END      EQU		0xE8

C_BREATHE_RANDOM_ADDR_HIGH  EQU		0x01
C_BREATHE_RANDOM_ADDR_START EQU		0x00
C_BREATHE_RANDOM_ADDR_END   EQU		0x80
;--------------- VECTOR VDEFINITION ----------------------------------------
		ORG		0x000
		LGOTO	F_MAIN
		
		ORG		0x004
		LGOTO	ISR_INT
		
;--------------- CODE START -----------------------------------------------
		ORG		0x010

F_MAIN:
; INITIALIZE GPIO 	
        CLRR	INTCON

        ;00:Input Floating,Output Push Pull
        ;01:Input Pull-Low, 
        ;10:Input Pull-High,Output Open Drain,
        ;11:Input Pull-High + Pull-Low
        MOVIA	C_Portx3_PP|C_Portx2_PP|C_Portx1_PP|C_Portx0_PP                                  
        MOVAR	PORTACON30
        MOVIA	C_Portx7_PP|C_Portx6_PP|C_Portx5_PP|C_Portx4_PP
        MOVAR   PORTACON74
        MOVIA	C_PA_Output
        MOVAR   IOSTA

        ;PORTB all Output Push Pull
        MOVIA	C_Portx3_PP|C_Portx2_PP|C_Portx1_PH|C_Portx0_PH
        MOVAR	PORTBCON30
        MOVIA	C_Portx7_PP|C_Portx6_PP|C_Portx5_PP|C_Portx4_PP
        MOVAR   PORTBCON74
        MOVIA	C_PB0_Input|C_PB1_Input|C_PB2_Output|C_PB3_Output|C_PB4_Output|C_PB5_Output|C_PB6_Output|C_PB7_Output
        MOVAR   IOSTB

        ;PORTC all Output Push Pull
        MOVIA	C_Portx3_PP|C_Portx2_PP|C_Portx1_PP|C_Portx0_PP
        MOVAR	PORTCCON30
        MOVIA	C_Portx7_PP|C_Portx6_PP|C_Portx5_PP|C_Portx4_PP
        MOVAR	PORTCCON74
        MOVIA	C_PC_Output                            ;1:INPUT,0:OUTPUT
        MOVAR   IOSTC
        
        MOVIA   11111111B
 		MOVAR   PORTA								;PORTB output high
 		MOVAR   PORTB								;PORTB output high
        MOVAR   PORTC								;PORTB output high

        ; INITIALIZE Timer0
        MOVIA   C_TMR0_LowClk|C_TMR0_En|C_TMR0_Clk|C_PS0_Div16;
        MOVAR	T0MD 
        MOVIA	0
        MOVAR	TMR0

        MOVIA   4
		MOVAR	TBHP
        MOVIA	C_GAME_RANDOM_ADDR_START
		MOVAR	V_GAME_RANDOM_ADDR

        ; INITIALIZE Timer1
		MOVIA	0x01
		MOVAR	SELCON
      	MOVIA	0x00
		MOVAR	TMRxH                         	; TMR1[9:8]=01
        MOVIA	0xFF
		MOVAR	TMRxL                         	; TMR1[7:0]=FFh 
		MOVIA	0x00
		MOVAR   TxCR1	
		MOVAR   TxCR2	
        
		;MOVIA   C_TMRx_Reload | C_TMRx_En
        ;MOVAR   TxCR1							; Enable Timer1, Initial value reloaded from TMR1, Non-stop mode       
        ;MOVIA   C_TMRx_ClkSrc_Inst
        ;MOVAR   TxCR2							; Enable Prescaler1, Prescaler1 dividing rate = 1:4, Timer1 clock source is instruction clock

        LCALL	F_TIMER_CALIBRATION
        
        ;Setting Interrupt Enable Register
        ;MOVIA	C_INTE_T1IE
        ;MOVAR	PIE1
;Enable Timer0 & Global interrupt bit 
        ;BSR		INTCON,GIE_Bit
        ;BSR		INTCON,PEIE_Bit

        CLRR 	V_LED_MODE_NUMBER
		BSR 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		BCR 	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		CLRR	V_BUTTON_IN_DELAY
;--------------------------------------------------------------		
SUB_MAIN_LOOP:		
        CLRWDT										; Clear WatchDog
		LCALL 	F_SYSTEM_SLEEP
		LCALL	F_RUN_LED_MODE
		LGOTO	SUB_MAIN_LOOP
;;---------------------------- Delay ms ----------------------------------
;DELAY_MS:
;		CLRWDT	
;		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
;		GOTO	DELAY_MS
;		RET
;---------------------------- DELAY_MS_HCLK ----------------------------------
F_DELAY_MS_HCLK:
		CLRWDT	
		MOVIA	166
        MOVAR	V_DELAY_COUNT2
SUB_DELAY_MS_HCLK_LOOP:   
		DECRSZ  V_DELAY_COUNT2,C_SaveToReg
		LGOTO	SUB_DELAY_MS_HCLK_LOOP
		DECRSZ  V_DELAY_COUNT1,C_SaveToReg
		LGOTO	F_DELAY_MS_HCLK
		RET  
;---------------------- TIMER_CALIBRATION--------------------------------
;-------------------------------------------------------------------------- 
F_TIMER_CALIBRATION:
		BCR		INTCON,GIE_Bit
        BCR		INTCON,PEIE_Bit
        ; Slow mode into Normal mode
        MOVIA   C_FHOSC_Sel							; OSCCR[0]=1 , FOSC is high-frequency oscillation (FHOSC)
        MOVAR   OSCCR                        		; OSCCR: Oscillation Control Register 
        NOP
        NOP
        
		MOVIA   C_TMR0_LowClk|C_TMR0_En|C_TMR0_Clk|C_PS0_Div16;
		MOVAR	T0MD 
        MOVIA	0
        MOVAR	TMR0
		
   		;BCR   	PORTB,6	
        MOVIA	5
        MOVAR	V_DELAY_COUNT1
        LCALL	F_DELAY_MS_HCLK
        ;BSR   	PORTB,6

        MOVR	TMR0,C_SaveToAcc
        MOVAR	V_DELAY_T0_NMS
		
		MOVAR	V_DELAY_T0_COUNT
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_10MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_10MS,C_SaveToReg

		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
        ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_20MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_20MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
		MOVAR  	V_DELAY_T0_30MS
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_30MS,C_SaveToReg

		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
       	ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
       	MOVIA	11111111B
        MOVAR 	V_DELAY_T0_35MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_35MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_45MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_45MS,C_SaveToReg
       	INCR	V_DELAY_T0_45MS,C_SaveToReg
		
		MOVR	V_DELAY_T0_NMS,C_SaveToAcc 
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		ADDAR	V_DELAY_T0_COUNT,C_SaveToReg
		MOVIA	11111111B
        MOVAR 	V_DELAY_T0_55MS
        MOVR	V_DELAY_T0_COUNT,C_SaveToAcc 
       	SUBAR	V_DELAY_T0_55MS,C_SaveToReg
       	
       	BSR		INTCON,GIE_Bit
        BSR		INTCON,PEIE_Bit

        RET
;---------------------------- F_T0_DELAY ----------------------------------
F_T0_DELAY:
		MOVR	V_DELAY_T0_COUNT,C_SaveToAcc
		MOVAR	TMR0
SUB_T0_DELAY_LOOP:
		CLRWDT
		SUBAR	TMR0,C_SaveToAcc
		BTRSC	STATUS,C_Bit
		LGOTO	SUB_T0_DELAY_LOOP
		RET	

;---------------------------- F_LED_SWITCH_OFF--------------------------------
;--------------------------------------------------------------------------  		
F_LED_SWITCH_ON_OFF:	
        ;LED1
        MOVIA   C_LED1_ACTRL
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
	   
        ;LED2 LED9
        MOVIA   C_LED2_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED9_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		

        ;LED3 LED10 LED16
        MOVIA   C_LED3_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED10_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED16_ACTRL
        ANDAR   PORTA,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;LED4 LED11 LED17
        MOVIA   C_LED4_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED11_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED17_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;LED5 LED12 LED18
        MOVIA   C_LED5_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED12_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED18_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;LED6 LED13 LED19
		MOVIA   C_LED13_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED6_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED19_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;LED7 LED14 LED20
		MOVIA   C_LED14_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED7_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVIA   C_LED20_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;LED8 LED15 
		MOVIA   C_LED15_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED8_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		
		;ALL OFF
		MOVIA   C_ALED_ALL_OFF
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_55MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		
		RET 
;---------------------------- SYSTEM_SLEEP--------------------------------
;--------------------------------------------------------------------------  
F_SYSTEM_SLEEP:
 		MOVIA   11111111B
 		MOVAR   PORTA										;PORTB output high
 		MOVAR   PORTB										;PORTB output high
        MOVAR   PORTC										;PORTB output high
		
		BTRSS	PORTB,C_BUTTON_BPIN	
		LGOTO	SUB_WAIT_BUTTON_RELEASE
		
		BTRSS	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO	SUB_SYSTEM_SLEEP_NO_BUTTON
		
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON	 	;If button in is no,return to run led mode,
		LGOTO 	SUB_SYSTEM_SLEEP_SET_POWER_OFF
SUB_SYSTEM_SLEEP_SET_POWER_ON:
		BSR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON_OFF
		CLRR	V_LED_MODE_NUMBER
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO 	F_SYSTEM_SLEEP
SUB_SYSTEM_SLEEP_SET_POWER_OFF:	
		BCR		V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		LCALL	F_LED_SWITCH_ON_OFF
		BCR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO 	F_SYSTEM_SLEEP
SUB_SYSTEM_SLEEP_NO_BUTTON:
		BTRSS	PORTB,C_OSH_BPIN						;Wait OSH PIN to be 1
		LGOTO 	F_SYSTEM_SLEEP	
		
SUB_SYSTEM_SLEEP_ENTRY:	
		LCALL   F_TIMER_CALIBRATION
		
		MOVIA   11111111B
 		MOVAR   PORTA										;PORTB output high
 		MOVAR   PORTB										;PORTB output high
        MOVAR   PORTC										;PORTB output high
		
		MOVIA	0
		MOVAR	BCDWUCON
		BTRSC 	V_SYSTEM_STATUS,C_STATUS_IS_POWER_ON
		BSR		BCDWUCON,WUPBCD1_Bit
		BSR		BCDWUCON,WUPBCD0_Bit 	
		
		MOVIA	0x00
		MOVAR   TxCR1
			
		CLRR    PIE1
		MOVIA   C_INTE_GIE|C_INTE_PEIE|C_INTE_PABCIE							;Enable PA INT
		MOVAR	INTCON
		CLRR	PCON
		
	 	SLEEP
	 	NOP
        NOP
	    BSR 	PCON, WDTEN_Bit					    ; Enable WDT
		BSR 	PCON, LVREN_Bit					    ; Enable LVR
		
		CLRR	INTCON
		
		; Normal mode into Slow mode
        MOVIA    C_FHOSC_Stop                       	; OSCCR[0]=0 , FOSC is Low-frequency oscillation (FLOSC)
        MOVAR    OSCCR                         	  	; OSCCR: Oscillation Control Register
        NOP
        NOP
		
		MOVIA   C_TMRx_Reload | C_TMRx_En
        MOVAR   TxCR1							; Enable Timer1, Initial value reloaded from TMR1, Non-stop mode       
      
        ;Setting Interrupt Enable Register
        MOVIA	C_INTE_T1IE
        MOVAR	PIE1
		;Initial Power control register
		BCR 	PCON, WDTEN_Bit					; Enable WDT
		BCR 	PCON, LVREN_Bit					; Enable LVR
		;Enable Timer0 & Global interrupt bit 
        BSR		INTCON,GIE_Bit
        BSR		INTCON,PEIE_Bit
        
		BTRSC 	PORTB,C_BUTTON_BPIN
		LGOTO	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP
		
SUB_WAIT_BUTTON_RELEASE:
		BTRSS	PORTB,C_OSH_BPIN
		LGOTO	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP
		CLRWDT
		BTRSS	PORTB,C_BUTTON_BPIN	
		LGOTO	SUB_WAIT_BUTTON_RELEASE
		MOVR    V_BUTTON_IN_DELAY,C_SaveToAcc       	; 把 V_COUNT 读进 ACC
        BTRSS   STATUS,Z_Bit            			 	; 若 ACC!=0，则继续循环
        LGOTO	SUB_WAIT_BUTTON_RELEASE                				; ACC!=0 时执行这里
        LGOTO	F_SYSTEM_SLEEP
		
SUB_SYSTEM_SLEEP_WAIT_OSH_STOP:
		CLRWDT
		BTRSS 	PORTB,C_OSH_BPIN		;if is power on enable PB0 wakeup
		LGOTO 	SUB_SYSTEM_SLEEP_WAIT_OSH_STOP	
		BTRSS	PORTB,C_BUTTON_BPIN
		RET
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		LGOTO	F_SYSTEM_SLEEP
	
		RET     
;---------------------------- F_GAME_RANDOM_ADDR_ADD ----------------------------------
F_GAME_RANDOM_ADDR_ADD:
	    INCR	V_GAME_RANDOM_ADDR,C_SaveToReg
		MOVIA	C_GAME_RANDOM_ADDR_END
        BCR     STATUS,Z_Bit    			; Clear Zero bit of Status Register
		XORAR   V_GAME_RANDOM_ADDR,C_SaveToAcc                   
		BTRSS	STATUS,Z_Bit    			; If V_GAME_RANDOM_ADDR=C_GAME_RANDOM_ADDR_END , then C bit=1
		RET
		MOVIA	C_GAME_RANDOM_ADDR_START
		MOVAR	V_GAME_RANDOM_ADDR  
        RET
;;---------------------------- F_BUTTON_CHECK_LONG_PRESS--------------------------------
;;--------------------------------------------------------------------------        
;F_BUTTON_CHECK_LONG_PRESS:
;		BTRSS	PORTA,C_BUTTON_APIN					;if(BUTTON_IN!=0) return NO;
;		LGOTO   SUB_BUTTON_CHECK_LONG_PRESS_LOOP 
		
;		CLRR	V_BUTTON_IN_DELAY_HIGH
;        RET 
;SUB_BUTTON_CHECK_LONG_PRESS_LOOP:
;		CLRWDT
;		MOVIA	C_BUTTON_LONG_DELAY
;        BCR     STATUS,C_Bit    					; Clear Zero bit of Status Register
;		SUBAR   V_BUTTON_IN_DELAY_HIGH,C_SaveToAcc                
;		BTRSC	STATUS,C_Bit    			; If V_BUTTON_IN_DELAY_HIGH>C_BUTTON_LONG_DELAY , then C bit=1
;		LGOTO	SUB_BUTTON_CHECK_LONG_PRESS_EFFECT
;		INCR    V_BUTTON_IN_DELAY_HIGH,C_SaveToReg
;		RET
;SUB_BUTTON_CHECK_LONG_PRESS_EFFECT:	
;		CLRWDT
;		LCALL   F_LED_ALL_OFF
;		BSR		V_SYSTEM_STATUS,C_STATUS_BUTTON_LONG_PRESS 
;		BTRSS	PORTA,C_BUTTON_APIN	
;		LGOTO	SUB_BUTTON_CHECK_LONG_PRESS_EFFECT
;		RET 

;---------------------------- F_RUN_LED_MODE--------------------------------
F_RUN_LED_MODE:    
		MOVIA   3
		MOVAR	V_RUN_LOOP
F_RUN_LED_MODE_LOOP0:	
		;LED1
        MOVIA   C_LED1_ACTRL
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
	   
        ;LED2 LED9
        MOVIA   C_LED2_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED9_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET

        ;LED3 LED10 LED16
        MOVIA   C_LED3_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED10_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED16_ACTRL
        ANDAR   PORTA,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED4 LED11 LED17
        MOVIA   C_LED4_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED11_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED17_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED5 LED12 LED18
        MOVIA   C_LED5_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED12_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED18_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED6 LED13 LED19
		MOVIA   C_LED13_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED6_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED19_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED7 LED14 
		MOVIA   C_LED14_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED7_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED8 LED15 LED20
		MOVIA   C_LED15_ACTRL
        ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED8_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVIA   C_LED20_CCTRL
        ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
	    MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;ALL OFF
		MOVIA   C_ALED_ALL_OFF
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
	   
	    DECRSZ  V_RUN_LOOP,C_SaveToReg	
		LGOTO   F_RUN_LED_MODE_LOOP0
		
		MOVIA   3
		MOVAR	V_RUN_LOOP
F_RUN_LED_MODE_LOOP1:	

		MOVIA   C_ALED_ALL_OFF
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED1 LED2 LED3 LED4 LED5 LED6 LED7 LED8
		MOVIA   C_LED1_ACTRL
        MOVAR   PORTA
		MOVIA   C_LED2_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED3_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED4_ACTRL
		ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED5_BCTRL
        MOVAR   PORTB
		MOVIA   C_LED6_BCTRL
        ANDAR   PORTB,C_SaveToReg
        MOVIA   C_LED7_CCTRL
		MOVAR   PORTC
		MOVIA   C_LED8_CCTRL
		ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED9 LED10 LED11 LED12 LED13 LED14 LED15 
		MOVIA   C_LED13_ACTRL
        MOVAR   PORTA
		MOVIA   C_LED14_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED15_ACTRL
		ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED9_BCTRL
        MOVAR   PORTB
		MOVIA   C_LED10_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED11_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED12_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED16 LED17 LED18 LED19 LED20
		MOVIA   C_LED16_ACTRL
        MOVAR   PORTA
        MOVIA   C_BLED_ALL_OFF
        MOVAR   PORTB
		MOVIA   C_LED17_CCTRL
		MOVAR   PORTC
		MOVIA   C_LED18_CCTRL
		ANDAR   PORTC,C_SaveToReg
		MOVIA   C_LED19_CCTRL
		ANDAR   PORTC,C_SaveToReg
		MOVIA   C_LED20_CCTRL
		ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED9 LED10 LED11 LED12 LED13 LED14 LED15 
		MOVIA   C_LED13_ACTRL
        MOVAR   PORTA
		MOVIA   C_LED14_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED15_ACTRL
		ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED9_BCTRL
        MOVAR   PORTB
		MOVIA   C_LED10_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED11_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED12_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_CLED_ALL_OFF
		MOVAR   PORTC
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
		
		;LED1 LED2 LED3 LED4 LED5 LED6 LED7 LED8
		MOVIA   C_LED1_ACTRL
        MOVAR   PORTA
		MOVIA   C_LED2_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED3_ACTRL
		ANDAR   PORTA,C_SaveToReg
		MOVIA   C_LED4_ACTRL
		ANDAR   PORTA,C_SaveToReg
        MOVIA   C_LED5_BCTRL
        MOVAR   PORTB
		MOVIA   C_LED6_BCTRL
        ANDAR   PORTB,C_SaveToReg
		MOVIA   C_LED7_CCTRL
		MOVAR   PORTC
		MOVIA   C_LED8_CCTRL
		ANDAR   PORTC,C_SaveToReg
		MOVR	V_DELAY_T0_45MS,C_SaveToAcc
        MOVAR	V_DELAY_T0_COUNT
      	LCALL	F_T0_DELAY
		BTRSC	V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS
		RET
	   
	    DECRSZ  V_RUN_LOOP,C_SaveToReg	
		LGOTO   F_RUN_LED_MODE_LOOP1
		
        RET
;----------------------- FINT_BUTTON_CHECK --------------------------------
;--------------------------------------------------------------------------		
F_INT_BUTTON_CHECK:
		BTRSC	PORTB,C_BUTTON_BPIN					;if(BUTTON_IN!=0) return NO;
		LGOTO   SUB_INT_NO_BUTTON
		
		INCR    V_BUTTON_IN_DELAY,C_SaveToReg
		MOVIA   00011111B
		ANDAR   V_BUTTON_IN_DELAY,C_SaveToReg
		RET
SUB_INT_NO_BUTTON:
		MOVIA	C_BUTTON_SHORT_DELAY
        BCR     STATUS,C_Bit    			; Clear Zero bit of Status Register
		SUBAR   V_BUTTON_IN_DELAY,C_SaveToAcc                    
		BTRSC	STATUS,C_Bit    			; If V_BUTTON_IN_DELAY>C_BUTTON_SHORT_DELAY , then C bit=1
		BSR		V_SYSTEM_STATUS,C_STATUS_BUTTON_SHORT_PRESS 
		CLRR	V_BUTTON_IN_DELAY
		RET
;;--------------------------------------------------------------
ISR_INT:
		MOVAR	V_ACC						; Store ACC value                  
		SWAPR	V_ACC,C_SaveToReg
		MOVR	STATUS,C_SaveToAcc
		MOVAR	V_STATUS						; Store STATUS value
;;--------------------------------------------------------------
;;Timer1 Interrupt
ISR_SUB_TIME1_INT:                  	
		BTRSS	PIR1,T1IF_Bit					; Skip next instruction, if T1IF=1 
		LGOTO	ISR_SUB_RET
		
		LCALL	F_INT_BUTTON_CHECK
;-------------------------------------------------------------------		
ISR_SUB_RET:	 
		BCR		INTCON,C_INTF_PABCIF
		BCR   	PIR1,T1IF_Bit
		
		MOVR	V_STATUS,C_SaveToAcc
		MOVAR	STATUS							; Restore STATUS value
		SWAPR	V_ACC,C_SaveToAcc			    ; Restore ACC value	  
	    RETIE                                   ; Return from interrupt and enable interrupt globally
	
		END                                     ; End of Code	